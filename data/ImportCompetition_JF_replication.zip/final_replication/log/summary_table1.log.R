
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:31 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(skimr)
> library(stringr)
> library(brew)
> library(magrittr)
> library(glue)

Attaching package: ‘glue’

The following object is masked from ‘package:dplyr’:

    collapse

> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> 
> library(haven)
> library(statar)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # READ REGRESSION DATA
> # This corresponds to our main dataset
> dt_blps <- readRDS("./input/blps_data_reg.rds") %>% data.table()
> # This corresponds to the main ADH dataset
> dt_adh <- read_dta("./input/workfile_china.dta") %>% data.table
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # Merge both datasets
> dt_adh_sub = dt_adh[t2 == 1, 
+     .(czone, statefip, relchg_avg_hhincsum_pc_pw, relchg_avg_hhincwage_pc_pw,
+       relchg_med_hhincsum_pc_pw, relchg_med_hhincwage_pc_pw,
+       d_avg_hhincsum_pc_pw, d_med_hhincsum_pc_pw) ]
> 
> dt_blps_full <- merge(dt_blps, dt_adh_sub, by = c("czone"))
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> brew_stat <- function(dt, col_var, var=NULL){
+     dt <- dt[, col_var, with = FALSE ]
+     dt <- cbind(dt %>% skim() %>% data.table, N=nrow(dt))
+     setnames(dt, gsub("numeric.", "", colnames(dt)))
+     setnames(dt, gsub("skim_", "", colnames(dt)))
+     if (!is.null(var)){ dt[, variable := var]}
+     return(dt)
+ }
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # MAGNITUDES
> dt_stat_SC   = brew_stat(dt_blps_full, c("SC"))
> dt_stat_NTR  = brew_stat(dt_blps_full, c("NTRgap"))
> dt_stat_AADH = brew_stat(dt_blps_full, c("autor"))
> 
> dt_stat_SC[]
      type variable n_missing complete_rate       mean         sd          p0
1: numeric       SC         0             1 0.04919272 0.02328695 0.004634453
          p25        p50        p75      p100  hist   N
1: 0.03749352 0.04405465 0.05299361 0.2744259 ▇▁▁▁▁ 715
> dt_stat_NTR[]
      type variable n_missing complete_rate     mean         sd         p0
1: numeric   NTRgap         0             1 0.256169 0.05139688 0.07138813
         p25      p50       p75     p100  hist   N
1: 0.2286926 0.264269 0.2895928 0.378968 ▁▂▆▇▂ 715
> dt_stat_AADH[]
      type variable n_missing complete_rate     mean       sd         p0
1: numeric    autor         0             1 1.065995 1.057739 -0.1076635
         p25       p50      p75     p100  hist   N
1: 0.3325919 0.7755567 1.502104 8.196906 ▇▂▁▁▁ 715
> 
> dt_stat_tradeus <- rbind(
+     brew_stat(dt_adh, c("d_tradeusch_pw"), var="full"),
+     brew_stat(dt_adh[t2==0], c("d_tradeusch_pw"), var="1990"),
+     brew_stat(dt_adh[t2==1], c("d_tradeusch_pw"), var="2000")
+     )
> dt_stat_tradeus[]
      type variable n_missing complete_rate     mean       sd          p0
1: numeric     full         0             1 1.905606 2.583024 -0.62895795
2: numeric     1990         0             1 1.175688 1.782278 -0.07535083
3: numeric     2000         0             1 2.635525 3.018231 -0.62895795
         p25       p50      p75     p100  hist    N
1: 0.4339951 1.1790407 2.486520 43.08460 ▇▁▁▁▁ 1444
2: 0.2609366 0.7455029 1.414620 25.40527 ▇▁▁▁▁  722
3: 0.8793638 1.9354252 3.440197 43.08460 ▇▁▁▁▁  722
> 
> dt_stat_inc <- rbind(
+     brew_stat(dt_adh, c("relchg_avg_hhincsum_pc_pw"), var="full"),
+     brew_stat(dt_adh[t2==0], c("relchg_avg_hhincsum_pc_pw"), var="1990"),
+     brew_stat(dt_adh[t2==1], c("relchg_avg_hhincsum_pc_pw"), var="2000")
+     )
> dt_stat_inc[]
      type variable n_missing complete_rate      mean        sd         p0
1: numeric     full         0             1 11.784061 12.389586 -22.099791
2: numeric     1990         0             1 19.840108  7.843889  -5.951017
3: numeric     2000         0             1  3.728013 10.756865 -22.099791
         p25       p50       p75    p100  hist    N
1:  1.895977 12.591246 20.797338 75.5742 ▂▇▆▁▁ 1444
2: 15.257625 19.564225 24.146890 75.5742 ▁▇▂▁▁  722
3: -3.287945  1.900286  8.911055 42.8699 ▁▇▅▁▁  722
> 
> dt_stat_inc2 <- rbind(
+     brew_stat(dt_adh, c("relchg_avg_hhincwage_pc_pw"), var="full"),
+     brew_stat(dt_adh[t2==0], c("relchg_avg_hhincwage_pc_pw"), var="1990"),
+     brew_stat(dt_adh[t2==1], c("relchg_avg_hhincwage_pc_pw"), var="2000")
+     )
> dt_stat_inc2[]
      type variable n_missing complete_rate      mean        sd        p0
1: numeric     full         0             1 12.934157 12.624855 -20.78359
2: numeric     1990         0             1 20.552637  9.257051 -11.13689
3: numeric     2000         0             1  5.315677 10.819358 -20.78359
         p25       p50      p75     p100  hist    N
1:  3.509753 12.910077 21.35858 63.67167 ▂▇▇▂▁ 1444
2: 14.872691 19.855547 25.74982 63.67167 ▁▇▇▁▁  722
3: -2.073953  4.105805 10.96468 42.49784 ▂▇▇▂▁  722
> 
> brew("./input/tables/table_summary1.brew.tex", "./output/tables/table_summary_magnitudes.tex")
> # ---------------------------------------------------------------------
> 
> 
> proc.time()
   user  system elapsed 
  1.498   0.158   2.254 
