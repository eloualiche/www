
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:44 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(fst)
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(stringr)
> library(skimr)
> library(rlist)
> library(texreg)
Version:  1.37.5
Date:     2020-06-17
Author:   Philip Leifeld (University of Essex)

Consider submitting praise using the praise or praise_interactive functions.
Please cite the JSS article in your publications -- see citation("texreg").
> library(brew)
> library(lfe)
Loading required package: Matrix
> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> library(statar)
> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> dt_psid <- readRDS("./input/psid.rds") %>% data.table
> dt_reg  = dt_psid[ year == 1999 ]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
> fixed_effects_2  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
> other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
> cluster_var      = "state_residence"  
> 
> # - transform the fixed effects into factor / level variables
> dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ),
+        .SDcols = fixed_effects_2  ]       
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # SET UP THE FIRST REGRESSIONS
> # --- LABOR
> unemp_var <- paste0("f_8_unemployed")
> 
> reg0_form_unemp <- as.formula(paste0(unemp_var, " ~ SC_feenstra | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> reg1_form_unemp <- as.formula(paste0(unemp_var, " ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
> reg2_form_unemp <- as.formula(paste0(unemp_var, " ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> 
> reg0_form_inc   <- as.formula(paste0("g_f_8_labor_inc_hd ~ SC_feenstra | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> reg1_form_inc   <- as.formula(paste0("g_f_8_labor_inc_hd ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
> reg2_form_inc   <- as.formula(paste0("g_f_8_labor_inc_hd ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> 
> reg0_unemp  <- felm(reg0_form_unemp, dt_reg[unemployed==0])
> reg1_unemp  <- felm(reg1_form_unemp, dt_reg[unemployed==0])
> reg2_unemp  <- felm(reg2_form_unemp, dt_reg[unemployed==0])
> reg0_inc     <- felm(reg0_form_inc, dt_reg)
> reg1_inc     <- felm(reg1_form_inc, dt_reg)
> reg2_inc     <- felm(reg2_form_inc, dt_reg)
> 
> # for Final table we keep
> r_brew_list1 <- list(reg1_unemp, reg2_unemp, reg1_inc, reg2_inc)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # ---   TOTAL DEBT AND DTI
> reg0_form_dti <- as.formula(paste0("d_f_8_dti_all ~ SC_feenstra | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> reg1_form_dti <- as.formula(paste0("d_f_8_dti_all ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
> reg2_form_dti <- as.formula(paste0("d_f_8_dti_all ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> 
> reg0_form_debt <- as.formula(paste0("g_f_8_value_all_debt ~ SC_feenstra | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> reg1_form_debt <- as.formula(paste0("g_f_8_value_all_debt ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
> reg2_form_debt <- as.formula(paste0("g_f_8_value_all_debt ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
> 
> reg0b_dti  <- felm(reg0_form_dti, dt_reg)  # state fe no controls
> reg1b_dti  <- felm(reg1_form_dti, dt_reg)  # no state fe
> reg2b_dti  <- felm(reg2_form_dti, dt_reg)  # state fe
> reg0b_debt <- felm(reg0_form_debt, dt_reg) # state fe no controls
> reg1b_debt <- felm(reg1_form_debt, dt_reg) # no state fe
> reg2b_debt <- felm(reg2_form_debt, dt_reg) # state fe
> 
> r_brew_list2 <- list(reg1b_dti, reg2b_dti, reg1b_debt, reg2b_debt)
> # -------------------------------------------------------------------------------------------
> 
> 
> # -------------------------------------------------------------------------------------------
> # Second set of regressions: different types of debt
> # mortgage
> reg0_form_mort <- as.formula(paste0("d_f_8_dti_re ~ SC_feenstra | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
> reg1_form_mort <- as.formula(paste0("d_f_8_dti_re ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
> reg2_form_mort <- as.formula(paste0("d_f_8_dti_re ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
> # other (cc)
> reg0_form_other <- as.formula(paste0("d_f_8_dti_other ~ SC_feenstra | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
> reg1_form_other <- as.formula(paste0("d_f_8_dti_other ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
> reg2_form_other <- as.formula(paste0("d_f_8_dti_other ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
> # car
> reg0_form_car <- as.formula(paste0("d_f_8_dti_car ~ SC_feenstra | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
> reg1_form_car <- as.formula(paste0("d_f_8_dti_car ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
> reg2_form_car <- as.formula(paste0("d_f_8_dti_car ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
> 
> 
> reg0b_mort     <- felm(reg0_form_mort, dt_reg)
> reg1b_mort     <- felm(reg1_form_mort, dt_reg)
> reg2b_mort     <- felm(reg2_form_mort, dt_reg)
> reg0b_other  <- felm(reg0_form_other, dt_reg)
> reg1b_other  <- felm(reg1_form_other, dt_reg)
> reg2b_other  <- felm(reg2_form_other, dt_reg)
> reg0b_car    <- felm(reg0_form_car, dt_reg)
> reg1b_car    <- felm(reg1_form_car, dt_reg)
> reg2b_car    <- felm(reg2_form_car, dt_reg)
>    
> r_brew_list3 <- list(reg1b_mort, reg2b_mort, reg1b_other, reg2b_other, reg1b_car, reg2b_car)
> # -------------------------------------------------------------------------------------------------------------
> 
> 
> # -------------------------------------------------------------------------------------------------------------
> stargazer(r_brew_list1, type="text")

=======================================================================================
                                            Dependent variable:                        
                    -------------------------------------------------------------------
                             f_8_unemployed                  g_f_8_labor_inc_hd        
                          (1)              (2)              (3)              (4)       
---------------------------------------------------------------------------------------
SC_feenstra              -0.519           -0.501          3.997***         4.004***    
                        (0.320)          (0.382)          (1.204)          (1.311)     
                                                                                       
log_labor_inc_hd         0.005            0.006          -0.247***        -0.248***    
                        (0.006)          (0.006)          (0.040)          (0.038)     
                                                                                       
log_value_all_debt       -0.003           -0.003           0.031*           0.031*     
                        (0.004)          (0.003)          (0.017)          (0.016)     
                                                                                       
dti_all                  -0.006           -0.003          0.123***         0.110**     
                        (0.008)          (0.010)          (0.039)          (0.044)     
                                                                                       
num_family_members     -0.024***         -0.021**          0.102*           0.100*     
                        (0.009)          (0.010)          (0.056)          (0.057)     
                                                                                       
---------------------------------------------------------------------------------------
Observations              722              722              723              723       
R2                       0.043            0.082            0.197            0.234      
Adjusted R2              0.024            0.007            0.181            0.172      
Residual Std. Error 0.300 (df = 707) 0.302 (df = 667) 1.342 (df = 708) 1.349 (df = 668)
=======================================================================================
Note:                                                       *p<0.1; **p<0.05; ***p<0.01
> stargazer(r_brew_list2, type="text")

=======================================================================================
                                            Dependent variable:                        
                    -------------------------------------------------------------------
                              d_f_8_dti_all                 g_f_8_value_all_debt       
                          (1)              (2)              (3)              (4)       
---------------------------------------------------------------------------------------
SC_feenstra             -6.783**         -8.349**        -10.632**        -11.558**    
                        (2.853)          (3.462)          (4.595)          (5.071)     
                                                                                       
log_labor_inc_hd         -0.063           -0.055           0.089            0.091      
                        (0.086)          (0.081)          (0.056)          (0.058)     
                                                                                       
log_value_all_debt      0.076***         0.068**         -0.518***        -0.529***    
                        (0.025)          (0.026)          (0.049)          (0.049)     
                                                                                       
dti_all                -0.837***        -0.815***         0.271**           0.221*     
                        (0.114)          (0.122)          (0.121)          (0.121)     
                                                                                       
num_family_members       -0.122           -0.129           0.063            0.060      
                        (0.075)          (0.082)          (0.111)          (0.111)     
                                                                                       
---------------------------------------------------------------------------------------
Observations              723              723              723              723       
R2                       0.116            0.154            0.218            0.260      
Adjusted R2              0.098            0.085            0.203            0.200      
Residual Std. Error 2.487 (df = 708) 2.505 (df = 668) 3.605 (df = 708) 3.611 (df = 668)
=======================================================================================
Note:                                                       *p<0.1; **p<0.05; ***p<0.01
> stargazer(r_brew_list3, type="text")

=========================================================================================================================
                                                             Dependent variable:                                         
                    -----------------------------------------------------------------------------------------------------
                              d_f_8_dti_re                     d_f_8_dti_other                    d_f_8_dti_car          
                          (1)              (2)              (3)              (4)              (5)              (6)       
-------------------------------------------------------------------------------------------------------------------------
SC_feenstra             -7.462**         -8.156*          -2.133**         -2.659**          0.223            0.155      
                        (3.258)          (4.042)          (0.838)          (0.997)          (0.188)          (0.217)     
                                                                                                                         
log_labor_inc_hd         -0.080           -0.067           0.013            0.015            0.007*           0.007*     
                        (0.114)          (0.100)          (0.011)          (0.010)          (0.004)          (0.004)     
                                                                                                                         
log_value_all_debt      0.091***         0.087***          -0.005           -0.007         -0.009***        -0.009***    
                        (0.026)          (0.025)          (0.013)          (0.015)          (0.002)          (0.003)     
                                                                                                                         
dti_all                -0.730***        -0.704***         -0.063*          -0.066*           0.012*           0.007      
                        (0.140)          (0.151)          (0.032)          (0.037)          (0.006)          (0.008)     
                                                                                                                         
num_family_members      -0.191**         -0.203**          0.046            0.053            0.009            0.008      
                        (0.079)          (0.090)          (0.037)          (0.039)          (0.008)          (0.008)     
                                                                                                                         
-------------------------------------------------------------------------------------------------------------------------
Observations              644              644              683              683              602              602       
R2                       0.113            0.166            0.040            0.085            0.052            0.102      
Adjusted R2              0.093            0.091            0.020            0.006            0.029            0.014      
Residual Std. Error 2.296 (df = 629) 2.299 (df = 590) 0.839 (df = 668) 0.845 (df = 628) 0.187 (df = 587) 0.189 (df = 547)
=========================================================================================================================
Note:                                                                                         *p<0.1; **p<0.05; ***p<0.01
> # -------------------------------------------------------------------------------------------------------------
> 
> 
> # -------------------------------------------------------------------------------------------------------------
> brew("./input/tables/psid_main.brew.tex", "./output/tables/psid_main.tex")
> # -------------------------------------------------------------------------------------------
> 
> 
> 
> proc.time()
   user  system elapsed 
  3.524   0.246   4.895 
