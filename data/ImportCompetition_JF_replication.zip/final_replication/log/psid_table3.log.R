
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:53 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(fst)
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(stringr)
> library(glue)

Attaching package: ‘glue’

The following object is masked from ‘package:dplyr’:

    collapse

> library(skimr)
> library(haven)
> library(brew)
> library(ggplot2)

Attaching package: ‘ggplot2’

The following object is masked from ‘package:crayon’:

    %+%

> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> library(lfe)
Loading required package: Matrix
> library(purrr)
> library(pipeR)
> library(rlist)
> library(data.table)

Attaching package: ‘data.table’

The following object is masked from ‘package:purrr’:

    transpose

The following objects are masked from ‘package:dplyr’:

    between, first, last

> library(statar)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> dt_psid <- readRDS("./input/psid.rds") %>% data.table
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # GET MOBILITY
> ind_var <- colnames(dt_psid)[grep("ind", names(dt_psid))]
> dt_ind <- dt_psid[, c("unique_id", "year", "ind", "SC_feenstra"), with = F]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> ## OCCUPATIONS TRANSFER IS A GOOD MEASURE OF EXPOSURE?
> dt_mobile <- dt_psid[, .(unique_id, year, unemployed, labor_inc_hd, value_all_debt, ind, 
+   main_occ_hd_0, main_occ_hd_1, SC_feenstra)]
> 
> # Hand code transferability
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 1   & main_occ_hd_0 <= 195, `:=`(occ_mobile = 0 , occ_name = "professional")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 201 & main_occ_hd_0 <= 245, `:=`(occ_mobile = 1 , occ_name = "managers")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 260 & main_occ_hd_0 <= 285, `:=`(occ_mobile = 1 , occ_name = "sales")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 301 & main_occ_hd_0 <= 395, `:=`(occ_mobile = 1 , occ_name = "clerical")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 401 & main_occ_hd_0 <= 600, `:=`(occ_mobile = 0 , occ_name = "craftsmen")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 601 & main_occ_hd_0 <= 695, `:=`(occ_mobile = 0 , occ_name = "operatives")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 701 & main_occ_hd_0 <= 715, `:=`(occ_mobile = 1 , occ_name = "transport")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 740 & main_occ_hd_0 <= 785, `:=`(occ_mobile = 0 , occ_name = "laborers")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 801 & main_occ_hd_0 <= 802, `:=`(occ_mobile = 1 , occ_name = "farmers")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 821 & main_occ_hd_0 <= 824, `:=`(occ_mobile = 1 , occ_name = "farm-laborers")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 901 & main_occ_hd_0 <= 965, `:=`(occ_mobile = 1 , occ_name = "service")]
> dt_mobile[ year<=2001 & main_occ_hd_0 >= 980 & main_occ_hd_0 <= 984, `:=`(occ_mobile = 1 , occ_name = "hh-workers")]
> dt_mobile[ year<=2001 & main_occ_hd_0 == 999,                        `:=`(occ_mobile = NA, occ_name = "DK") ]
> dt_mobile[ year<=2001 & main_occ_hd_0 == 0,                          `:=`(occ_mobile = NA, occ_name = "not-eligible") ]
> 
> # fill in mobile by default
> dt_mobile[ year>=2003 & main_occ_hd_1<999, occ_mobile := 1 ]
> # filter the non-mobile ones separately
> dt_mobile[ year>=2003 & main_occ_hd_1 >= 700 & main_occ_hd_1 <= 762,  occ_mobile := 0 ]
> dt_mobile[ year>=2003 & main_occ_hd_1 >= 770 & main_occ_hd_1 <= 896,  occ_mobile := 0 ]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
> fixed_effects_2  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
> other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
> cluster_var      = "state_residence"  # lowers the standard errors
> 
> # REGRESSION WITH MOBILITY: INCOME RESPONSE
> dt_reg <- dt_psid[ year == 1999 ]
> dt_reg <- merge(dt_reg, 
+   dt_mobile[year==1999, .(unique_id, occ_mobile=as.factor(occ_mobile))], 
+   by = c("unique_id"))
> 
> # - transform the fixed effects into factor / level variables
> dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ),
+        .SDcols = fixed_effects_2  ]       
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> reg0_form_inc   <- paste0("g_f_8_labor_inc_hd ~ SC_feenstra | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var)
> reg1_form_inc   <- paste0("g_f_8_labor_inc_hd ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var)
> reg2_form_inc   <- paste0("g_f_8_labor_inc_hd ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var)
> 
> # ---
> reg0b_inc    <- felm(as.formula(reg0_form_inc), dt_reg[occ_mobile==0])
> reg1b_inc    <- felm(as.formula(reg1_form_inc), dt_reg[occ_mobile==0])
> reg2b_inc    <- felm(as.formula(reg2_form_inc), dt_reg[occ_mobile==0])
> reg0c_inc    <- felm(as.formula(reg0_form_inc), dt_reg[occ_mobile==1])
> reg1c_inc    <- felm(as.formula(reg1_form_inc), dt_reg[occ_mobile==1])
> reg2c_inc    <- felm(as.formula(reg2_form_inc), dt_reg[occ_mobile==1])
> 
> r_list_inc <- list(reg0b_inc, reg1b_inc, reg2b_inc, reg0c_inc, reg1c_inc, reg2c_inc)
> stargazer(r_list_inc, type="text")

=========================================================================================================================
                                                             Dependent variable:                                         
                    -----------------------------------------------------------------------------------------------------
                     reg0_form_inc    reg1_form_inc    reg2_form_inc    reg0_form_inc    reg1_form_inc    reg2_form_inc  
                          (1)              (2)              (3)              (4)              (5)              (6)       
-------------------------------------------------------------------------------------------------------------------------
SC_feenstra             7.610***         3.865**          5.184***          3.458            3.434            0.715      
                        (2.531)          (1.604)          (1.840)          (2.054)          (2.438)          (2.327)     
                                                                                                                         
log_labor_inc_hd                        -0.314***        -0.312***                         -0.202***        -0.199***    
                                         (0.057)          (0.052)                           (0.049)          (0.045)     
                                                                                                                         
log_value_all_debt                        0.012            0.009                            0.073**          0.064**     
                                         (0.020)          (0.021)                           (0.031)          (0.029)     
                                                                                                                         
dti_all                                  0.147**           0.113                             0.078*           0.090*     
                                         (0.064)          (0.072)                           (0.043)          (0.051)     
                                                                                                                         
num_family_members                       0.152**          0.150**                            -0.006           0.058      
                                         (0.066)          (0.069)                           (0.098)          (0.119)     
                                                                                                                         
-------------------------------------------------------------------------------------------------------------------------
Observations              507              507              507              215              215              215       
R2                       0.129            0.201            0.251            0.215            0.248            0.367      
Adjusted R2              0.038            0.178            0.165            0.006            0.200            0.180      
Residual Std. Error 1.442 (df = 458) 1.333 (df = 492) 1.344 (df = 454) 1.476 (df = 169) 1.324 (df = 201) 1.340 (df = 165)
=========================================================================================================================
Note:                                                                                         *p<0.1; **p<0.05; ***p<0.01
> # ---------------------------------------------------------------------
> 
> # ---------------------------------------------------------------------  
> brew("./input/tables/psid_income_occupation.brew.tex",
+      "./output/tables/psid_income_occupation.tex")
> # ---------------------------------------------------------------------
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> proc.time()
   user  system elapsed 
  2.738   0.243   3.429 
