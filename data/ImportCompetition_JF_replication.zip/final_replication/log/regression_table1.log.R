
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:33 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(skimr)
> library(stringr)
> library(lfe)
Loading required package: Matrix
> library(AER)
Loading required package: car
Loading required package: carData

Attaching package: ‘car’

The following object is masked from ‘package:dplyr’:

    recode

Loading required package: lmtest
Loading required package: zoo

Attaching package: ‘zoo’

The following objects are masked from ‘package:base’:

    as.Date, as.Date.numeric


Attaching package: ‘lmtest’

The following object is masked from ‘package:lfe’:

    waldtest

The following object is masked from ‘package:crayon’:

    reset

Loading required package: sandwich
Loading required package: survival
> library(lmtest)
> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> library(brew)
> library(magrittr)
> library(glue)

Attaching package: ‘glue’

The following object is masked from ‘package:dplyr’:

    collapse

> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> 
> library(haven)
> library(statar)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # APPEND REQUIRED PACKAGES
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # READ ADH DATA
> dt_adh <- read_dta("./input/workfile_china.dta") %>% data.table()
> # READ BLPS DATA
> dt_blps <- readRDS("./input/blps_data_reg.rds") %>% data.table()
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # variables for regressions
> control_set1 <- c(
+     "l_shind_manuf_cbp", "l_sh_popedu_c", "l_sh_popfborn",
+     "l_sh_empl_f", "l_sh_routine33", "l_task_outsource", "t2"
+ )
> control_set1p <- paste(control_set1, collapse = " + ")
> regional_set <- paste0("reg_", c("midatl", "encen", "wncen", "satl", "escen", "wscen", "mount", "pacif"))
> regional_setp <- paste(regional_set, collapse = " + ")
> 
> lhs_set <- c(
+     "relchg_avg_hhincsum_pc_pw", "relchg_avg_hhincwage_pc_pw",
+     "relchg_med_hhincsum_pc_pw", "relchg_med_hhincwage_pc_pw",
+     "d_avg_hhincsum_pc_pw", "d_avg_hhincwage_pc_pw",
+     "d_med_hhincsum_pc_pw", "d_med_hhincwage_pc_pw"
+ )
> rhs_shocks <- c("d_tradeusch_pw", "d_tradeotch_pw_lag")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # TABLE 9 PURE ADH
> r_1a_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ ", 
+     control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
> r_2a_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ ", 
+     control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
> r_3a_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ ", 
+     control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
> r_4a_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ ", 
+     control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
> 
> 
> dt_reg <- dt_adh[, c(lhs_set, rhs_shocks, control_set1, regional_set, "yr", "statefip", "timepwt48"), with = F ]
> dt_reg2 <- dt_reg[ t2 == 1 ] # only latter period
> 
> r_1a_res <- felm(r_1a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
Warning messages:
1: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
2: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_2a_res <- felm(r_2a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
Warning messages:
1: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
2: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_3a_res <- felm(r_3a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
Warning messages:
1: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
2: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_4a_res <- felm(r_4a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
Warning messages:
1: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
2: In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_list_ADH <- list(r_1a_res, r_2a_res, r_3a_res, r_4a_res)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # TABLE 9 Shipping COSTS: REDUCED FORM
> r_1b_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_2b_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_3b_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_4b_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> 
> dt_reg2 = merge(dt_adh, dt_blps[, .(czone, SC)], , by = c("czone"))
> dt_reg2 = dt_reg2[, c(lhs_set, rhs_shocks, control_set1, regional_set,
+     "SC", "czone", "yr", "statefip", "timepwt48"), with = F ]
> dt_reg2b <- dt_reg2[ t2 == 1 ] # only latter period
> 
> r_1b_res <- felm(r_1b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_2b_res <- felm(r_2b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_3b_res <- felm(r_3b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_4b_res <- felm(r_4b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_list_SC <- list(r_1b_res, r_2b_res, r_3b_res, r_4b_res)
> 
> stargazer(r_list_SC, type="text")

========================================================================================================================================
                                                                          Dependent variable:                                           
                               ---------------------------------------------------------------------------------------------------------
                               relchg_avg_hhincsum_pc_pw relchg_avg_hhincwage_pc_pw relchg_med_hhincsum_pc_pw relchg_med_hhincwage_pc_pw
                                          (1)                       (2)                        (3)                       (4)            
----------------------------------------------------------------------------------------------------------------------------------------
SC                                      47.303*                  66.730***                  52.930**                   59.050*          
                                       (24.766)                   (24.467)                  (25.587)                   (32.060)         
                                                                                                                                        
l_shind_manuf_cbp                      -0.374***                 -0.459***                  -0.390***                 -0.477***         
                                        (0.070)                   (0.075)                    (0.074)                   (0.082)          
                                                                                                                                        
l_sh_popedu_c                           -0.093                     0.060                     -0.133                     -0.152          
                                        (0.104)                   (0.126)                    (0.102)                   (0.130)          
                                                                                                                                        
l_sh_popfborn                           0.226**                   0.331**                   0.209***                   0.355***         
                                        (0.099)                   (0.141)                    (0.073)                   (0.102)          
                                                                                                                                        
l_sh_empl_f                              0.370                     0.164                      0.300                     0.423*          
                                        (0.231)                   (0.284)                    (0.196)                   (0.255)          
                                                                                                                                        
l_sh_routine33                          -0.181                     -0.354                    -0.395                     -0.511          
                                        (0.381)                   (0.339)                    (0.410)                   (0.487)          
                                                                                                                                        
l_task_outsource                       -7.103**                    -1.403                    -4.035                    -6.534**         
                                        (2.752)                   (2.954)                    (2.671)                   (3.116)          
                                                                                                                                        
t2                                      -13.088                    6.005                      1.928                     -4.582          
                                       (14.862)                   (18.313)                  (14.269)                   (18.322)         
                                                                                                                                        
reg_midatl                               1.355                     1.686                     -0.396                     -0.215          
                                        (1.572)                   (1.591)                    (1.273)                   (1.682)          
                                                                                                                                        
reg_encen                              -4.868**                  -7.445***                  -7.155***                 -8.074***         
                                        (1.981)                   (2.657)                    (2.090)                   (2.781)          
                                                                                                                                        
reg_wncen                                1.088                     -0.615                    -1.465                     -1.097          
                                        (1.337)                   (1.766)                    (1.098)                   (1.637)          
                                                                                                                                        
reg_satl                                -0.892                     -4.061                    -2.665                     -3.675          
                                        (2.334)                   (2.702)                    (2.348)                   (2.923)          
                                                                                                                                        
reg_escen                                2.697                     -0.313                    -1.846                     -2.981          
                                        (2.176)                   (2.557)                    (2.122)                   (2.565)          
                                                                                                                                        
reg_wscen                                0.848                     -2.316                    -2.893                     -2.915          
                                        (2.608)                   (2.768)                    (2.091)                   (2.257)          
                                                                                                                                        
reg_mount                                2.602                     -2.316                    -0.540                     -0.019          
                                        (1.980)                   (2.339)                    (1.689)                   (2.448)          
                                                                                                                                        
reg_pacif                               2.809*                     -3.642                     1.664                     1.259           
                                        (1.617)                   (2.344)                    (1.400)                   (1.916)          
                                                                                                                                        
Constant                                                                                                                                
                                        (0.000)                   (0.000)                    (0.000)                   (0.000)          
                                                                                                                                        
----------------------------------------------------------------------------------------------------------------------------------------
Observations                              715                       715                        715                       715            
R2                                       0.468                     0.589                      0.521                     0.536           
Adjusted R2                              0.457                     0.580                      0.511                     0.526           
Residual Std. Error (df = 699)           0.194                     0.214                      0.183                     0.230           
========================================================================================================================================
Note:                                                                                                        *p<0.1; **p<0.05; ***p<0.01
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> stargazer(c(r_list_SC, r_list_ADH),
+     keep = c("SC*", "d_tradeusch*"),
+     dep.var.labels.include = FALSE, type = "text"
+ )

=============================================================================================================================================================
                                                                                Dependent variable:                                                          
                      ---------------------------------------------------------------------------------------------------------------------------------------
                            (1)              (2)              (3)              (4)              (5)              (6)              (7)              (8)       
-------------------------------------------------------------------------------------------------------------------------------------------------------------
SC                        47.303*         66.730***         52.930**         59.050*                                                                         
                          (24.766)         (24.467)         (25.587)         (32.060)                                                                        
                                                                                                                                                             
`d_tradeusch_pw(fit)`                                                                          -0.537           -0.862           -0.575          -0.934*     
                                                                                              (0.461)          (0.547)          (0.451)          (0.554)     
                                                                                                                                                             
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Observations                715              715              715              715              722              722              722              722       
R2                         0.468            0.589            0.521            0.536            0.443            0.563            0.497            0.504      
Adjusted R2                0.457            0.580            0.511            0.526            0.432            0.553            0.486            0.494      
Residual Std. Error   0.194 (df = 699) 0.214 (df = 699) 0.183 (df = 699) 0.230 (df = 699) 0.198 (df = 706) 0.220 (df = 706) 0.187 (df = 706) 0.236 (df = 706)
=============================================================================================================================================================
Note:                                                                                                                             *p<0.1; **p<0.05; ***p<0.01
> 
> brew("./input/tables/table_ADH_comparison1.brew.tex", "./output/tables/table_ADH_comparison1.tex")
> # ---------------------------------------------------------------------
> 
> proc.time()
   user  system elapsed 
  3.051   0.221   3.940 
