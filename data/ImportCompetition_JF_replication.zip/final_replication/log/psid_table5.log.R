
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:38:00 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(fst)
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(stringr)
> library(skimr)
> library(brew)
> library(binom)
> library(texreg)
Version:  1.37.5
Date:     2020-06-17
Author:   Philip Leifeld (University of Essex)

Consider submitting praise using the praise or praise_interactive functions.
Please cite the JSS article in your publications -- see citation("texreg").
> library(gt)
> library(lfe)
Loading required package: Matrix
> library(ggplot2)

Attaching package: ‘ggplot2’

The following object is masked from ‘package:crayon’:

    %+%

> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> library(statar)
> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> dt_psid <- readRDS("./input/psid.rds") %>% data.table
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # GET THE LIST OF FIXED EFFECTS
> fixed_effects_0  = c("state_residence")
> fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
> fixed_effects_2  = c(fixed_effects_0, fixed_effects_1)
> other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> dt_reg <- dt_psid[ year == 1999 ]
> other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "num_family_members")
> dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ),
+        .SDcols = fixed_effects_2  ]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> rega_form_food   <- as.formula(paste0("g_f_8_food_total ~ SC_feenstra | ",
+     paste0(fixed_effects_0, collapse = " + "), " | 0 | state_residence "))
> regb_form_food   <- as.formula(paste0("g_f_8_food_total ~ SC_feenstra | ",
+     paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
> regc_form_food   <- as.formula(paste0("g_f_8_food_total ~ (SC_feenstra + ", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(c(fixed_effects_0, fixed_effects_1), collapse = " + "), " | 0 | state_residence "))
> regd_form_food   <- as.formula(paste0("g_f_8_food_total ~ (SC_feenstra +", 
+   paste0(other_controls, collapse = " + "), ") | ",
+   paste0(fixed_effects_0, collapse = " + "), " | 0 | state_residence "))
> 
> rega_food    <- felm(rega_form_food, dt_reg[ food_total>0])
> regb_food    <- felm(regb_form_food, dt_reg[ food_total>0])
> regc_food    <- felm(regc_form_food, dt_reg[ food_total>0])
> regd_food    <- felm(regd_form_food, dt_reg[ food_total>0])
> 
> r_list_food <- list(rega_food, regb_food, regd_food, regc_food)
> stargazer(r_list_food, type="text")

=======================================================================================
                                            Dependent variable:                        
                    -------------------------------------------------------------------
                                             g_f_8_food_total                          
                          (1)              (2)              (3)              (4)       
---------------------------------------------------------------------------------------
SC_feenstra              -1.171           -1.095           -0.694           0.181      
                        (1.774)          (1.521)          (1.792)          (1.748)     
                                                                                       
log_labor_inc_hd                                           -0.009          -0.031**    
                                                          (0.016)          (0.015)     
                                                                                       
log_value_all_debt                                        0.068***         0.030**     
                                                          (0.018)          (0.013)     
                                                                                       
num_family_members                                         -0.118          -0.172**    
                                                          (0.075)          (0.083)     
                                                                                       
---------------------------------------------------------------------------------------
Observations              699              699              699              699       
R2                       0.079            0.106            0.100            0.183      
Adjusted R2              0.021            0.093            0.040            0.116      
Residual Std. Error 1.870 (df = 657) 1.800 (df = 688) 1.852 (df = 654) 1.777 (df = 645)
=======================================================================================
Note:                                                       *p<0.1; **p<0.05; ***p<0.01
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> brew("./input/tables/psid_expenditure.brew.tex", 
+      "./output/tables/psid_expenditure.tex", )
> # ---------------------------------------------------------------------
> 
> 
> 
> proc.time()
   user  system elapsed 
  2.497   0.225   3.003 
