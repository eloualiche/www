
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:37 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(skimr)
> library(stringr)
> library(lfe)
Loading required package: Matrix
> library(AER)
Loading required package: car
Loading required package: carData

Attaching package: ‘car’

The following object is masked from ‘package:dplyr’:

    recode

Loading required package: lmtest
Loading required package: zoo

Attaching package: ‘zoo’

The following objects are masked from ‘package:base’:

    as.Date, as.Date.numeric


Attaching package: ‘lmtest’

The following object is masked from ‘package:lfe’:

    waldtest

The following object is masked from ‘package:crayon’:

    reset

Loading required package: sandwich
Loading required package: survival
> library(lmtest)
> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> library(fst)
> library(brew)
> library(magrittr)
> library(glue)

Attaching package: ‘glue’

The following object is masked from ‘package:dplyr’:

    collapse

> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> 
> library(haven)
> library(statar)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # APPEND REQUIRED PACKAGES
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # READ REGRESSION DATA
> dt_blps <- readRDS("./input/blps_data_reg.rds") %>% data.table
> dt_adh  <- read_dta("./input/workfile_china.dta") %>% data.table
> 
> dt_adh_sub<- dt_adh[t2 == 1, 
+     .(czone, statefip, relchg_avg_hhincsum_pc_pw, relchg_avg_hhincwage_pc_pw,
+       relchg_med_hhincsum_pc_pw, relchg_med_hhincwage_pc_pw,
+       d_avg_hhincsum_pc_pw, d_med_hhincsum_pc_pw) ]
> dt_blps_full <- merge(dt_blps, dt_adh_sub, by = c("czone"))
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # variables for regressions
> control_set1 <- c(
+     "l_shind_manuf_cbp", "l_sh_popedu_c", "l_sh_popfborn",
+     "l_sh_empl_f", "l_sh_routine33", "l_task_outsource", "t2"
+ )
> control_set1p <- paste(control_set1, collapse = " + ")
> regional_set <- paste0("reg_", c("midatl", "encen", "wncen", "satl", "escen", "wscen", "mount", "pacif"))
> regional_setp <- paste(regional_set, collapse = " + ")
> 
> lhs_set <- c(
+     "relchg_avg_hhincsum_pc_pw", "relchg_avg_hhincwage_pc_pw",
+     "relchg_med_hhincsum_pc_pw", "relchg_med_hhincwage_pc_pw",
+     "d_avg_hhincsum_pc_pw", "d_avg_hhincwage_pc_pw",
+     "d_med_hhincsum_pc_pw", "d_med_hhincwage_pc_pw"
+ )
> rhs_shocks <- c("d_tradeusch_pw", "d_tradeotch_pw_lag")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # TABLE 9 NTR REDUCED FORM
> r_1a_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_2a_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_3a_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_4a_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> 
> dt_reg2 <- merge(dt_adh, dt_blps[, .(czone, NTRgap)], by = c("czone"))
> dt_reg2 <- dt_reg2[, c(lhs_set, rhs_shocks, control_set1, regional_set,
+     "NTRgap", "czone", "yr", "statefip", "timepwt48"), with = F ]
> dt_reg2b <- dt_reg2[ t2 == 1 ] # only latter period
> 
> r_1a_res <- felm(r_1a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_2a_res <- felm(r_2a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_3a_res <- felm(r_3a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_4a_res <- felm(r_4a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> 
> r_list_NTR <- list(r_1a_res, r_2a_res, r_3a_res, r_4a_res)
> stargazer(r_list_NTR, type="text")

========================================================================================================================================
                                                                          Dependent variable:                                           
                               ---------------------------------------------------------------------------------------------------------
                               relchg_avg_hhincsum_pc_pw relchg_avg_hhincwage_pc_pw relchg_med_hhincsum_pc_pw relchg_med_hhincwage_pc_pw
                                          (1)                       (2)                        (3)                       (4)            
----------------------------------------------------------------------------------------------------------------------------------------
NTRgap                                 -28.123*                  -42.514**                   -19.370                   -33.845*         
                                       (14.898)                   (16.480)                  (13.779)                   (18.011)         
                                                                                                                                        
l_shind_manuf_cbp                      -0.331***                 -0.391***                  -0.371***                 -0.426***         
                                        (0.072)                   (0.081)                    (0.075)                   (0.082)          
                                                                                                                                        
l_sh_popedu_c                           -0.105                     0.046                     -0.152                     -0.167          
                                        (0.108)                   (0.135)                    (0.103)                   (0.134)          
                                                                                                                                        
l_sh_popfborn                           0.220**                   0.323**                   0.201***                   0.347***         
                                        (0.100)                   (0.141)                    (0.076)                   (0.103)          
                                                                                                                                        
l_sh_empl_f                              0.355                     0.142                      0.286                     0.405           
                                        (0.234)                   (0.289)                    (0.200)                   (0.260)          
                                                                                                                                        
l_sh_routine33                          -0.125                     -0.267                    -0.369                     -0.446          
                                        (0.373)                   (0.329)                    (0.395)                   (0.466)          
                                                                                                                                        
l_task_outsource                       -6.798**                    -0.925                    -3.899                    -6.175*          
                                        (2.840)                   (3.048)                    (2.775)                   (3.245)          
                                                                                                                                        
t2                                      -3.854                     19.454                    10.462                     6.758           
                                       (16.809)                   (19.736)                  (15.844)                   (19.841)         
                                                                                                                                        
reg_midatl                               1.068                     1.247                     -0.569                     -0.557          
                                        (1.559)                   (1.513)                    (1.304)                   (1.744)          
                                                                                                                                        
reg_encen                              -5.427***                 -8.306***                  -7.470***                 -8.739***         
                                        (1.920)                   (2.539)                    (2.043)                   (2.743)          
                                                                                                                                        
reg_wncen                                0.375                     -1.702                    -1.919                     -1.952          
                                        (1.334)                   (1.623)                    (1.216)                   (1.765)          
                                                                                                                                        
reg_satl                                -0.852                     -4.008                    -2.604                     -3.623          
                                        (2.347)                   (2.636)                    (2.359)                   (2.925)          
                                                                                                                                        
reg_escen                                2.405                     -0.770                    -1.978                     -3.325          
                                        (2.196)                   (2.499)                    (2.098)                   (2.541)          
                                                                                                                                        
reg_wscen                                0.620                     -2.665                    -3.035                     -3.188          
                                        (2.527)                   (2.621)                    (2.026)                   (2.225)          
                                                                                                                                        
reg_mount                                2.173                     -2.970                    -0.805                     -0.531          
                                        (2.008)                   (2.266)                    (1.715)                   (2.492)          
                                                                                                                                        
reg_pacif                                2.595                    -3.985*                     1.600                     1.010           
                                        (1.699)                   (2.327)                    (1.522)                   (2.062)          
                                                                                                                                        
Constant                                                                                                                                
                                        (0.000)                   (0.000)                    (0.000)                   (0.000)          
                                                                                                                                        
----------------------------------------------------------------------------------------------------------------------------------------
Observations                              715                       715                        715                       715            
R2                                       0.472                     0.595                      0.520                     0.539           
Adjusted R2                              0.460                     0.586                      0.509                     0.529           
Residual Std. Error (df = 699)           0.194                     0.213                      0.183                     0.229           
========================================================================================================================================
Note:                                                                                                        *p<0.1; **p<0.05; ***p<0.01
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # TABLE 9 AADH REDUCED FORM
> r_1b_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_2b_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_3b_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> r_4b_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
+     " | 0 | 0 | statefip"))
> 
> dt_reg2 <- merge(dt_adh, dt_blps[, .(czone, autor)], by = c("czone"))
> dt_reg2 <- dt_reg2[, c(lhs_set, rhs_shocks, control_set1, regional_set,
+     "autor", "czone", "yr", "statefip", "timepwt48"), with = F ]
> dt_reg2b <- dt_reg2[ t2 == 1 ] # only latter period
> 
> r_1b_res <- felm(r_1b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_2b_res <- felm(r_2b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_3b_res <- felm(r_3b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> r_4b_res <- felm(r_4b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
Warning message:
In chol.default(mat, pivot = TRUE, tol = tol) :
  the matrix is either rank-deficient or indefinite
> 
> r_list_AADH <- list(r_1b_res, r_2b_res, r_3b_res, r_4b_res)
> stargazer(r_list_AADH, type="text")

========================================================================================================================================
                                                                          Dependent variable:                                           
                               ---------------------------------------------------------------------------------------------------------
                               relchg_avg_hhincsum_pc_pw relchg_avg_hhincwage_pc_pw relchg_med_hhincsum_pc_pw relchg_med_hhincwage_pc_pw
                                          (1)                       (2)                        (3)                       (4)            
----------------------------------------------------------------------------------------------------------------------------------------
autor                                   -0.709                    -1.566*                    -0.833                     -1.436          
                                        (0.726)                   (0.843)                    (0.779)                   (0.922)          
                                                                                                                                        
l_shind_manuf_cbp                      -0.342***                 -0.370***                  -0.352***                 -0.394***         
                                        (0.099)                   (0.113)                    (0.094)                   (0.106)          
                                                                                                                                        
l_sh_popedu_c                           -0.115                     0.032                     -0.157                     -0.176          
                                        (0.110)                   (0.138)                    (0.105)                   (0.136)          
                                                                                                                                        
l_sh_popfborn                           0.221**                   0.328**                   0.204***                   0.352***         
                                        (0.099)                   (0.139)                    (0.074)                   (0.101)          
                                                                                                                                        
l_sh_empl_f                              0.350                     0.125                      0.276                     0.388           
                                        (0.239)                   (0.298)                    (0.206)                   (0.268)          
                                                                                                                                        
l_sh_routine33                          -0.243                     -0.469                    -0.467                     -0.616          
                                        (0.399)                   (0.334)                    (0.425)                   (0.490)          
                                                                                                                                        
l_task_outsource                       -7.011**                    -1.062                    -3.917                    -6.214*          
                                        (2.897)                   (3.033)                    (2.811)                   (3.221)          
                                                                                                                                        
t2                                                                                                                                      
                                        (0.000)                   (0.000)                    (0.000)                   (0.000)          
                                                                                                                                        
reg_midatl                               1.177                     1.249                     -0.608                     -0.618          
                                        (1.510)                   (1.478)                    (1.237)                   (1.662)          
                                                                                                                                        
reg_encen                              -5.252***                 -8.422***                  -7.615***                 -8.977***         
                                        (1.703)                   (2.410)                    (1.850)                   (2.536)          
                                                                                                                                        
reg_wncen                                0.760                     -1.409                    -1.855                     -1.828          
                                        (1.354)                   (1.736)                    (1.194)                   (1.691)          
                                                                                                                                        
reg_satl                                -1.033                    -4.436*                    -2.835                     -4.021          
                                        (2.230)                   (2.577)                    (2.241)                   (2.785)          
                                                                                                                                        
reg_escen                                2.719                     -0.391                    -1.828                     -3.059          
                                        (2.158)                   (2.539)                    (2.107)                   (2.545)          
                                                                                                                                        
reg_wscen                                0.423                     -3.284                    -3.395                     -3.803          
                                        (2.669)                   (2.931)                    (2.136)                   (2.381)          
                                                                                                                                        
reg_mount                                2.333                     -2.965                    -0.859                     -0.617          
                                        (2.013)                   (2.334)                    (1.763)                   (2.499)          
                                                                                                                                        
reg_pacif                                2.449                    -4.592*                     1.230                     0.379           
                                        (1.846)                   (2.514)                    (1.715)                   (2.250)          
                                                                                                                                        
Constant                                -6.202                     17.183                     9.735                     5.438           
                                       (16.819)                   (19.669)                  (16.109)                   (19.842)         
                                                                                                                                        
----------------------------------------------------------------------------------------------------------------------------------------
Observations                              715                       715                        715                       715            
R2                                       0.467                     0.591                      0.519                     0.538           
Adjusted R2                              0.455                     0.582                      0.509                     0.528           
Residual Std. Error (df = 699)           0.194                     0.214                      0.183                     0.229           
========================================================================================================================================
Note:                                                                                                        *p<0.1; **p<0.05; ***p<0.01
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> stargazer(c(r_list_NTR, r_list_AADH),
+     keep = c("NTR*", "autor*"),
+     dep.var.labels.include = FALSE, type = "text"
+ )

===================================================================================================
                                                       Dependent variable:                         
                               --------------------------------------------------------------------
                                 (1)       (2)      (3)      (4)      (5)     (6)     (7)     (8)  
---------------------------------------------------------------------------------------------------
NTRgap                         -28.123* -42.514** -19.370  -33.845*                                
                               (14.898) (16.480)  (13.779) (18.011)                                
                                                                                                   
autor                                                               -0.709  -1.566* -0.833  -1.436 
                                                                    (0.726) (0.843) (0.779) (0.922)
                                                                                                   
---------------------------------------------------------------------------------------------------
Observations                     715       715      715      715      715     715     715     715  
R2                              0.472     0.595    0.520    0.539    0.467   0.591   0.519   0.538 
Adjusted R2                     0.460     0.586    0.509    0.529    0.455   0.582   0.509   0.528 
Residual Std. Error (df = 699)  0.194     0.213    0.183    0.229    0.194   0.214   0.183   0.229 
===================================================================================================
Note:                                                                   *p<0.1; **p<0.05; ***p<0.01
> 
> brew("./input/tables/table_ADH_comparison2.brew.tex", "./output/tables/table_ADH_comparison2.tex")
There were 12 warnings (use warnings() to see them)
> # ---------------------------------------------------------------------
> 
> 
> proc.time()
   user  system elapsed 
  3.681   0.225   4.077 
