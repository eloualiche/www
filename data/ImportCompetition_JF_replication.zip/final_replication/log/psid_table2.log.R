
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:49 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(fst)
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(stringr)
> library(skimr)
> library(rlist)
> library(texreg)
Version:  1.37.5
Date:     2020-06-17
Author:   Philip Leifeld (University of Essex)

Consider submitting praise using the praise or praise_interactive functions.
Please cite the JSS article in your publications -- see citation("texreg").
> library(brew)
> library(lfe)
Loading required package: Matrix
> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> library(statar)
> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> dt_psid <- readRDS("./input/psid.rds") %>% data.table
> dt_reg  = dt_psid[ year == 1999 ]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> fixed_effects  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
> other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
> cluster_var      = "state_residence"  # lowers the standard errors
> 
> # - transform the fixed effects into factor / level variables
> dt_reg[, paste0(fixed_effects) := lapply(.SD, function(x) as.factor(x) ),
+        .SDcols = fixed_effects  ]       
> # ---------------------------------------------------------------------
> 
> 
> 
> # --------------------------------------------------------------------
> dt_reg %>% skim(g_f_8_labor_inc_hd)
── Data Summary ────────────────────────
                           Values    
Name                       Piped data
Number of rows             5411      
Number of columns          35        
_______________________              
Column type frequency:               
  numeric                  1         
________________________             
Group variables            None      

── Variable type: numeric ──────────────────────────────────────────────────────
  skim_variable      n_missing complete_rate   mean    sd    p0    p25   p50
1 g_f_8_labor_inc_hd      1624         0.700 0.0364  1.67 -3.53 -0.153 0.248
    p75  p100 hist 
1 0.601  4.03 ▂▁▇▁▁
> 
> unemp_var    = "cum_f_8_unemp"
> cluster_var  = "state_residence"  
> # --------------------------------------------------------------------
> 
> 
> # --------------------------------------------------------------------
> # --- GROWTH RATE
> reg3_iv_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ", 
+         "cum_f_8_labor_inc_hd +  log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+         "state_residence + race_hd + gender_hd + marital_status_hd | ",
+         "0 | ", cluster_var) ) 
> reg4_iv_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ", 
+         unemp_var, " +  log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+         "state_residence + race_hd + gender_hd + marital_status_hd | ",
+         "0 | ", cluster_var) ) 
> 
> # IV REGRESSIONS: Instrument is income growth
> reg5_iv1_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
+   "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+       " race_hd + gender_hd + marital_status_hd | ",
+       "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", cluster_var) )
> reg5b_iv1_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
+   "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+       "state_residence + race_hd + gender_hd + marital_status_hd | ",
+       "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", cluster_var) )
> # INSTRUMENT IS NOW THE UNEMPLOYMENT SPELL
> reg5_iv2_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
+   "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+         " race_hd + gender_hd + marital_status_hd | ",
+         "(", unemp_var,  " ~ SC_feenstra) | ",
+         cluster_var) )
> reg5b_iv2_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
+   "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+         "state_residence + race_hd + gender_hd + marital_status_hd | ",
+         "(", unemp_var,  " ~ SC_feenstra) | ",
+         cluster_var) )
> 
> reg3_iv_debt  <- felm(reg3_iv_debt_form, dt_reg)
> reg3b_iv_debt <- felm(reg3_iv_debt_form, dt_reg[ !is.na(SC_feenstra) ])
> reg4_iv_debt  <- felm(reg4_iv_debt_form, dt_reg)
> reg4b_iv_debt <- felm(reg4_iv_debt_form, dt_reg[ !is.na(SC_feenstra) ])
> 
> reg5_iv1_debt  <- felm(reg5_iv1_debt_form, dt_reg)
> reg5b_iv1_debt <- felm(reg5b_iv1_debt_form, dt_reg)
> reg5_iv2_debt  <- felm(reg5_iv2_debt_form, dt_reg)
> reg5b_iv2_debt <- felm(reg5b_iv2_debt_form, dt_reg)
> 
> r_iv_list1 <- list(reg3_iv_debt, reg3b_iv_debt, 
+                    reg4_iv_debt, reg4b_iv_debt, 
+                    reg5_iv1_debt, reg5b_iv1_debt, 
+                    reg5_iv2_debt, reg5b_iv2_debt)
> 
> stargazer(r_iv_list1, type="text")

=====================================================================================================================================================================
                                                                                       Dependent variable:                                                           
                            -----------------------------------------------------------------------------------------------------------------------------------------
                                                                                      g_f_8_value_all_debt                                                           
                                   (1)              (2)               (3)              (4)              (5)              (6)              (7)              (8)       
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
cum_f_8_labor_inc_hd            0.120***          0.141***                                                                                                           
                                 (0.011)          (0.043)                                                                                                            
                                                                                                                                                                     
cum_f_8_unemp                                                      -0.450***        -0.610***                                                                        
                                                                    (0.075)          (0.201)                                                                         
                                                                                                                                                                     
log_labor_inc_hd                0.334***          0.424***          0.061**          0.156**          -2.361*           -2.652           -0.001           -0.018     
                                 (0.043)          (0.139)           (0.023)          (0.061)          (1.371)          (1.755)          (0.158)          (0.181)     
                                                                                                                                                                     
log_value_all_debt              -0.545***        -0.522***         -0.541***        -0.517***        -0.366***        -0.377***         -0.315**         -0.306*     
                                 (0.019)          (0.051)           (0.018)          (0.049)          (0.103)          (0.123)          (0.136)          (0.167)     
                                                                                                                                                                     
dti_all                          0.052*            0.120           0.063***           0.204*           0.878            0.901            0.324            0.212      
                                 (0.027)          (0.135)           (0.022)          (0.119)          (0.634)          (0.671)          (0.297)          (0.330)     
                                                                                                                                                                     
num_family_members               -0.019            0.028            -0.040            0.037            0.392            0.326            0.769            0.744      
                                 (0.059)          (0.098)           (0.054)          (0.104)          (0.365)          (0.370)          (0.602)          (0.628)     
                                                                                                                                                                     
`cum_f_8_labor_inc_hd(fit)`                                                                           -1.115*           -1.243                                       
                                                                                                      (0.643)          (0.801)                                       
                                                                                                                                                                     
`cum_f_8_unemp(fit)`                                                                                                                     9.971            10.850     
                                                                                                                                        (6.106)          (7.445)     
                                                                                                                                                                     
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Observations                      3,532             701              3,787             723              701              701              723              723       
R2                                0.271            0.264             0.264            0.256            -1.699           -1.821           -3.775           -4.082     
Adjusted R2                       0.258            0.205             0.251            0.198            -1.746           -2.048           -3.856           -4.477     
Residual Std. Error         3.673 (df = 3469) 3.613 (df = 648) 3.715 (df = 3724) 3.616 (df = 670) 6.715 (df = 688) 7.074 (df = 648) 8.899 (df = 710) 9.450 (df = 670)
=====================================================================================================================================================================
Note:                                                                                                                                     *p<0.1; **p<0.05; ***p<0.01
> # for the F-statistics
> # screenreg(r_iv_list1, include.fstatistic = T)
> # --------------------------------------------------------------------
> 
> 
> # --------------------------------------------------------------------
> ## DTI: IV regressions
> reg3_iv_dti_form <- as.formula(paste0("g_f_8_dti_all ~ cum_f_8_labor_inc_hd",
+           "+ log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+           "state_residence + race_hd + gender_hd + marital_status_hd | ",
+           "0 | ", cluster_var)    )
> reg4_iv_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ", unemp_var,
+           "+ log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+           "state_residence + race_hd + gender_hd + marital_status_hd | ",
+           "0 | ", cluster_var)    )
> reg5_iv1_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
+            "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+            " race_hd + gender_hd + marital_status_hd | ",
+            "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", "state_residence")    )
> reg5b_iv1_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
+            "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+            "state_residence + race_hd + gender_hd + marital_status_hd | ",
+            "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", "state_residence")    )
> reg5_iv2_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
+            "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+            "race_hd + gender_hd + marital_status_hd | ",
+            "(", unemp_var, " ~ SC_feenstra) | ", "state_residence")    )
> reg5b_iv2_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
+            "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
+            "state_residence +  race_hd + gender_hd + marital_status_hd | ",
+            "(", unemp_var, " ~ SC_feenstra) | ", "state_residence")    )
> 
> reg3_iv_dti   <- felm(reg3_iv_dti_form, dt_reg)
> reg3b_iv_dti  <- felm(reg3_iv_dti_form, dt_reg[ !is.na(SC_feenstra) ])
> reg4_iv_dti   <- felm(reg4_iv_dti_form, dt_reg)
> reg4b_iv_dti  <- felm(reg4_iv_dti_form, dt_reg[ !is.na(SC_feenstra) ])
> reg5_iv1_dti   <- felm(reg5_iv1_dti_form, dt_reg)
> reg5b_iv1_dti  <- felm(reg5b_iv1_dti_form, dt_reg)
> reg5_iv2_dti   <- felm(reg5_iv2_dti_form, dt_reg)
> reg5b_iv2_dti  <- felm(reg5b_iv2_dti_form, dt_reg)
> 
> r_iv_list2 <- list(reg3_iv_dti, reg3b_iv_dti, 
+                    reg4_iv_dti, reg4b_iv_dti, 
+                    reg5_iv1_dti, reg5b_iv1_dti, 
+                    reg5_iv2_dti, reg5b_iv2_dti)
> 
> stargazer(r_iv_list2, type="text")

=====================================================================================================================================================================
                                                                                       Dependent variable:                                                           
                            -----------------------------------------------------------------------------------------------------------------------------------------
                                                                                          g_f_8_dti_all                                                              
                                   (1)              (2)               (3)              (4)              (5)              (6)              (7)              (8)       
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
cum_f_8_labor_inc_hd            -0.009***         -0.008*                                                                                                            
                                 (0.003)          (0.005)                                                                                                            
                                                                                                                                                                     
cum_f_8_unemp                                                       0.033*           0.096**                                                                         
                                                                    (0.016)          (0.038)                                                                         
                                                                                                                                                                     
log_labor_inc_hd                -0.020**           -0.011           0.009**          -0.0001           -0.230           -0.320           -0.019           -0.023     
                                 (0.008)          (0.015)           (0.004)          (0.009)          (0.165)          (0.242)          (0.019)          (0.025)     
                                                                                                                                                                     
log_value_all_debt              -0.017***          0.006           -0.018***          0.007            0.017*           0.020            0.027            0.034      
                                 (0.003)          (0.007)           (0.003)          (0.007)          (0.010)          (0.015)          (0.017)          (0.024)     
                                                                                                                                                                     
dti_all                         -0.131***        -0.248***         -0.123***        -0.251***        -0.187***         -0.170*         -0.239***        -0.250***    
                                 (0.008)          (0.033)           (0.008)          (0.029)          (0.071)          (0.086)          (0.032)          (0.033)     
                                                                                                                                                                     
num_family_members              -0.025**           -0.024          -0.024**           -0.015           0.012            0.006            0.066            0.076      
                                 (0.012)          (0.019)           (0.011)          (0.019)          (0.037)          (0.040)          (0.072)          (0.087)     
                                                                                                                                                                     
`cum_f_8_labor_inc_hd(fit)`                                                                            -0.107           -0.148                                       
                                                                                                      (0.078)          (0.111)                                       
                                                                                                                                                                     
`cum_f_8_unemp(fit)`                                                                                                                     1.195            1.578      
                                                                                                                                        (0.859)          (1.198)     
                                                                                                                                                                     
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Observations                      3,532             701              3,787             723              701              701              723              723       
R2                                0.237            0.245             0.231            0.243            -0.340           -0.662           -1.632           -2.840     
Adjusted R2                       0.223            0.184             0.218            0.184            -0.363           -0.796           -1.676           -3.138     
Residual Std. Error         0.628 (df = 3469) 0.558 (df = 648) 0.638 (df = 3724) 0.560 (df = 670) 0.722 (df = 688) 0.828 (df = 648) 1.014 (df = 710) 1.260 (df = 670)
=====================================================================================================================================================================
Note:                                                                                                                                     *p<0.1; **p<0.05; ***p<0.01
> # screenreg(r_iv_list2, include.fstatistic = T) # for the F-statistics
> # --------------------------------------------------------------------------------
> 
> 
> # --------------------------------------------------------------------------------
> brew("./input/tables/psid_iv_main.brew.tex", "./output/tables/psid_iv_main.tex")
> # --------------------------------------------------------------------------------
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> proc.time()
   user  system elapsed 
  3.677   0.253   4.812 
