
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:41 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(fst)
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(skimr)
> library(brew)
> library(gt)
> library(kableExtra)

Attaching package: ‘kableExtra’

The following object is masked from ‘package:dplyr’:

    group_rows

> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> library(statar)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> dt_psid <- readRDS("./input/psid.rds") %>% data.table
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> summary_var <- c("SC_feenstra", 
+ 	"unemployed", "labor_inc_hd", "dti_all", "value_all_debt",
+ 	"cons_total", "food_total", "house_val",
+ 	paste0("f_8_unemployed"),
+ 	paste0("g_f_8", c("_labor_inc_hd", "_dti_all", "_value_all_debt")) ,
+ 	paste0("g_f_8", c("_cons_total", "_food_total")) )
> 
> dt_psid[, summary_var, with = F]
        SC_feenstra unemployed labor_inc_hd   dti_all value_all_debt cons_total
     1:          NA      FALSE         5000 1.3253012          11000         NA
     2:          NA      FALSE         3552 1.2124151          10000         NA
     3:          NA      FALSE         4500 0.8741259          10000         NA
     4:          NA      FALSE         5762 0.7529553          10000         NA
     5:          NA      FALSE         8000 0.0000000              0         NA
    ---                                                                        
225320:          NA      FALSE        37000 0.1531250          12250      11060
225321:          NA      FALSE        54000 0.4951720          26769      13040
225322:          NA      FALSE        43952 0.0000000              0       3620
225323:          NA      FALSE        20260 0.0000000              0      14020
225324:          NA      FALSE        14790 0.0000000              0       7580
        food_total house_val f_8_unemployed g_f_8_labor_inc_hd g_f_8_dti_all
     1:         NA     12000          FALSE           1.053485    -0.6793849
     2:         NA     14000          FALSE           1.443386    -0.7476587
     3:         NA     15000          FALSE           1.413525    -0.6281424
     4:         NA     15500             NA                 NA            NA
     5:         NA      6000             NA                 NA            NA
    ---                                                                     
225320:       9360         0             NA                 NA            NA
225321:       6240         0             NA                 NA            NA
225322:       3120         0             NA                 NA            NA
225323:      13520         0             NA                 NA            NA
225324:       7280         0             NA                 NA            NA
        g_f_8_value_all_debt g_f_8_cons_total g_f_8_food_total
     1:            -3.238654               NA               NA
     2:            -3.941813               NA               NA
     3:            -4.853570               NA               NA
     4:                   NA               NA               NA
     5:                   NA               NA               NA
    ---                                                       
225320:                   NA               NA               NA
225321:                   NA               NA               NA
225322:                   NA               NA               NA
225323:                   NA               NA               NA
225324:                   NA               NA               NA
> dt_psid[ year == 1999 & !is.na(SC_feenstra) ][, summary_var, with = F] %>% skim
── Data Summary ────────────────────────
                           Values    
Name                       Piped data
Number of rows             948       
Number of columns          14        
_______________________              
Column type frequency:               
  logical                  2         
  numeric                  12        
________________________             
Group variables            None      

── Variable type: logical ──────────────────────────────────────────────────────
  skim_variable  n_missing complete_rate    mean count            
1 unemployed             0         1     0.00527 FAL: 943, TRU: 5 
2 f_8_unemployed       225         0.763 0.102   FAL: 649, TRU: 74

── Variable type: numeric ──────────────────────────────────────────────────────
   skim_variable        n_missing complete_rate        mean          sd
 1 SC_feenstra                  0         1          0.0500      0.0349
 2 labor_inc_hd                 0         1      38020.      32096.    
 3 dti_all                      0         1          0.848       1.22  
 4 value_all_debt               0         1      45592.      62547.    
 5 cons_total                 948         0        NaN          NA     
 6 food_total                   0         1       7519.       5712.    
 7 house_val                    0         1     170361.     967644.    
 8 g_f_8_labor_inc_hd         225         0.763     -0.106       1.48  
 9 g_f_8_dti_all              225         0.763      0.107       0.620 
10 g_f_8_value_all_debt       225         0.763      0.0774      4.04  
11 g_f_8_cons_total           948         0        NaN          NA     
12 g_f_8_food_total           225         0.763     -0.0186      2.23  
          p0        p25        p50         p75        p100 hist   
 1   0.00693     0.0190     0.0454      0.0590       0.210 "▇▅▂▁▁"
 2   0       21000      32000       46000       400000     "▇▁▁▁▁"
 3   0           0.0811     0.497       1.16        13.6   "▇▁▁▁▁"
 4   0        2875      21000       65000       644700     "▇▁▁▁▁"
 5  NA          NA         NA          NA           NA     " "    
 6   0        4420       6240        9100        40300     "▇▃▁▁▁"
 7   0           0      60000      110000      9999999     "▇▁▁▁▁"
 8  -3.53       -0.184      0.204       0.485        4.03  "▂▁▇▁▁"
 9  -2.35       -0.189      0           0.328        3.03  "▁▃▇▁▁"
10  -9.52       -0.496      0.134       1.09         9.89  "▁▁▇▁▁"
11  NA          NA         NA          NA           NA     " "    
12 -10.6        -0.223      0.151       0.540       10.6   "▁▁▇▁▁"
> dt_psid[ year == 1999 ][, summary_var, with = F] %>% skim
── Data Summary ────────────────────────
                           Values    
Name                       Piped data
Number of rows             5411      
Number of columns          14        
_______________________              
Column type frequency:               
  logical                  2         
  numeric                  12        
________________________             
Group variables            None      

── Variable type: logical ──────────────────────────────────────────────────────
  skim_variable  n_missing complete_rate   mean count              
1 unemployed             0         1     0.0845 FAL: 4954, TRU: 457
2 f_8_unemployed      1624         0.700 0.123  FAL: 3322, TRU: 465

── Variable type: numeric ──────────────────────────────────────────────────────
   skim_variable        n_missing complete_rate        mean          sd
 1 SC_feenstra               4463         0.175      0.0500      0.0349
 2 labor_inc_hd                 0         1      32298.      36907.    
 3 dti_all                      0         1          1.09        2.67  
 4 value_all_debt               0         1      43348.      64977.    
 5 cons_total                5411         0        NaN          NA     
 6 food_total                   0         1       7723.       7275.    
 7 house_val                    0         1     174993.     993311.    
 8 g_f_8_labor_inc_hd        1624         0.700      0.0364      1.67  
 9 g_f_8_dti_all             1624         0.700      0.116       0.722 
10 g_f_8_value_all_debt      1624         0.700      0.390       4.29  
11 g_f_8_cons_total          5411         0        NaN          NA     
12 g_f_8_food_total          1624         0.700      0.119       2.64  
          p0        p25        p50         p75        p100 hist   
 1   0.00693     0.0190     0.0454      0.0590       0.210 "▇▅▂▁▁"
 2   0       12000      28000       42000       850000     "▇▁▁▁▁"
 3   0           0          0.411       1.30        26.9   "▇▁▁▁▁"
 4   0         400      15000       65797      1525000     "▇▁▁▁▁"
 5  NA          NA         NA          NA           NA     " "    
 6   0        3640       6240        9308        40300     "▇▃▁▁▁"
 7   0           0      48000      120000      9999999     "▇▁▁▁▁"
 8  -3.53       -0.153      0.248       0.601        4.03  "▂▁▇▁▁"
 9  -3.03       -0.210      0           0.397        3.03  "▁▁▇▂▁"
10  -9.52       -0.410      0.182       1.52         9.89  "▁▁▇▁▁"
11  NA          NA         NA          NA           NA     " "    
12 -10.6        -0.201      0.182       0.628       10.6   "▁▁▇▁▁"
> 
> dt_sum_stats1 <- dt_psid[ year == 1999 & !is.na(SC_feenstra) & !is.na(g_f_8_labor_inc_hd),
+ 	c("unique_id", summary_var), with = F]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------	
> build_sum_table <- function(dt_sum_stats, summary_var,	title, label){
+ 
+ 	Nrow = nrow(dt_sum_stats[, c(summary_var), with=F] )
+ 	dt_sum <- dt_sum_stats[, c(summary_var), with=F] %>% skim %>% data.table
+ 	dt_sum_logical <- dt_sum[ skim_type == "logical" ]
+ 	dt_sum_numeric <- dt_sum[ skim_type == "numeric" ]
+ 
+ 	setnames(dt_sum_logical, gsub("logical.", "", colnames(dt_sum_logical)) )
+ 	setnames(dt_sum_numeric, gsub("numeric.", "", colnames(dt_sum_numeric)) )
+ 	no_keep <- colnames(dt_sum_numeric)[grep("logical", colnames(dt_sum_numeric))]
+ 	dt_sum_numeric[, (no_keep) := NULL ]
+ 	no_keep <- c("count", colnames(dt_sum_logical)[grep("numeric", colnames(dt_sum_logical))])
+ 	dt_sum_logical[, (no_keep) := NULL ]
+ 	dt_sum_logical
+ 
+ 	dt_sum <- rbind(dt_sum_logical, dt_sum_numeric, fill = T)
+ 	dt_sum[, c("skim_type") := NULL ]
+ 	setnames(dt_sum, "skim_variable", "variable")
+ 	dt_sum[, complete := Nrow - n_missing ]
+ 
+ 	setcolorder(dt_sum, c("variable", "complete", "mean", "sd", "p25", "p50", "p75"))
+ 	setnames(dt_sum, "complete", "n")
+ 	dt_sum <- dt_sum[, 1:7 ]
+ 	dt_sum_fwd <- dt_sum[ grep("f_8", dt_sum[["variable"]]) ]
+ 	dt_sum_now <- dt_sum[ !grep("f_8", dt_sum[["variable"]]) ]
+ 	dt_sum_fwd <- dt_sum_fwd[ c(2, 1, 6, 4, 3)]
+ 	dt_sum_now <- dt_sum_now[ c(2, 8, 3, 1, 7, 5, 4) ]
+ 
+ 	var_names = c(
+ 		"Income (Head)",
+ 		"Unemployed",
+ 		"Food Expenditures",
+ 		"Total Debt",
+ 		"Debt to Income ratio")
+ 
+ 	dt_sum_fwd[, variable_name := var_names ]
+ 	dt_sum_fwd[, group         := paste0("Growth rate: ", 1999, "-", 2007) ]
+ 	dt_sum_now[, variable_name := c("Shipping Costs", "House value", var_names) ]
+ 	dt_sum_now[, group         := paste0("Level in: ", 1999) ]
+ 	dt_sum_all <- rbind(dt_sum_now, dt_sum_fwd)
+ 
+ 	dt_sum_all[, c("mean", "sd", "p25", "p50", "p75") := lapply(.SD, prettyNum), .SDcols = c("mean", "sd", "p25", "p50", "p75")] 
+ 
+ 	return(dt_sum_all)
+ 
+   	}
> # ------------------------------------------------------------------------------------------
> 
> 
> 
> # ------------------------------------------------------------------------------------------
> dt_sum1 <- build_sum_table(dt_sum_stats1, summary_var, 
+   title="PSID Summary Statistics: Restricted Sample", label = "table:summary:psid:1")
> dt_sum1[]
                variable   n        mean         sd        p25        p50
 1:          SC_feenstra 723   0.0496448 0.03271323 0.02006653 0.04539009
 2:            house_val 723    147606.1   828494.1          0      65000
 3:         labor_inc_hd 723    39346.66   32965.53      21550      32100
 4:           unemployed 723 0.001383126         NA         NA         NA
 5:           food_total 723    7951.685   6122.141       4680       6500
 6:       value_all_debt 723    47656.97   62113.86       3000      26000
 7:              dti_all 723   0.8398538   1.123222 0.09059374  0.5503333
 8:   g_f_8_labor_inc_hd 723   -0.105652   1.483215 -0.1836995   0.203596
 9:       f_8_unemployed 723   0.1023513         NA         NA         NA
10:     g_f_8_food_total 723 -0.01862677   2.228667 -0.2231083  0.1507916
11: g_f_8_value_all_debt 723  0.07736961   4.038062 -0.4958499  0.1339143
12:        g_f_8_dti_all 723   0.1072031  0.6195723 -0.1891419          0
           p75        variable_name                  group
 1: 0.05829357       Shipping Costs         Level in: 1999
 2:     114500          House value         Level in: 1999
 3:    49871.5        Income (Head)         Level in: 1999
 4:         NA           Unemployed         Level in: 1999
 5:       9360    Food Expenditures         Level in: 1999
 6:      70000           Total Debt         Level in: 1999
 7:   1.217845 Debt to Income ratio         Level in: 1999
 8:   0.484545        Income (Head) Growth rate: 1999-2007
 9:         NA           Unemployed Growth rate: 1999-2007
10:  0.5402614    Food Expenditures Growth rate: 1999-2007
11:   1.090657           Total Debt Growth rate: 1999-2007
12:   0.328439 Debt to Income ratio Growth rate: 1999-2007
> # ------------------------------------------------------------------------------------------
> 
> 
> # ------------------------------------------------------------------------------------------
> brew("./input/tables/psid_summary_stats.brew.tex", 
+ 	   "./output/tables/psid_summary_stats.tex")
> # ------------------------------------------------------------------------------------------
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> proc.time()
   user  system elapsed 
  1.944   0.187   2.285 
