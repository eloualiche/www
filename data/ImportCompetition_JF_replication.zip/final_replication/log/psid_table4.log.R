
R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
Copyright (C) 2020 The R Foundation for Statistical Computing
Platform: x86_64-apple-darwin17.0 (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # ---------------------------------------------------------------------
> message("Log file for code executed at\n")
Log file for code executed at

> message(format(Sys.time(), "%a %b %d %X %Y"))
Thu May 27 14:37:57 2021
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> library(crayon)
> library(devtools)
Loading required package: usethis
> 
> library(fst)
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> library(stringr)
> library(glue)

Attaching package: ‘glue’

The following object is masked from ‘package:dplyr’:

    collapse

> library(texreg)
Version:  1.37.5
Date:     2020-06-17
Author:   Philip Leifeld (University of Essex)

Consider submitting praise using the praise or praise_interactive functions.
Please cite the JSS article in your publications -- see citation("texreg").
> library(brew)
> library(lfe)
Loading required package: Matrix
> library(data.table)

Attaching package: ‘data.table’

The following objects are masked from ‘package:dplyr’:

    between, first, last

> library(statar)
> library(stargazer)

Please cite as: 

 Hlavac, Marek (2018). stargazer: Well-Formatted Regression and Summary Statistics Tables.
 R package version 5.2.2. https://CRAN.R-project.org/package=stargazer 

> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> source("./src/star_builder.R")
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # LOAD THE DATA
> dt_psid <- readRDS("./input/psid.rds") %>% data.table
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> # GET THE LIST OF FIXED EFFECTS
> fixed_effects_0  = c("state_residence")
> fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
> fixed_effects_2  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
> other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
> # ---------------------------------------------------------------------
> 
> 
> 
> 
> # ---------------------------------------------------------------------
> reg_form_generic <- function(delta, diff_t, extract_var, fixed_effects, controls){
+   as.formula(paste0(delta, "f_", diff_t, "_", extract_var, " ~ (", 
+     paste0(stringi::stri_remove_empty(c("SC_feenstra", controls)), collapse = " + "), ") | ",
+     paste0(fixed_effects, collapse = " + "), " | 0 | state_residence "))
+ }  
> 
> reg_form_iv1_extract <- function(delta, diff_t, extract_var){
+   as.formula(paste0(delta, "f_", diff_t, "_", extract_var, " ~ (g_f_", diff_t, "_labor_inc_hd + ", 
+     paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
+ }
> reg_form_iv2_extract <- function(delta, diff_t, extract_var){
+   as.formula(paste0(delta, "f_", diff_t, "_", extract_var, " ~ (", 
+     paste0(other_controls, collapse = " + "), ") | ",
+     paste0(fixed_effects_2, collapse = " + "), " | ",
+     "(g_f_", diff_t, "_labor_inc_hd ~ SC_feenstra) | state_residence "))
+ }
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> diff_t     <- 8
> extract_var_bk <- "eq_extract_bk_alt" # or "eq_extract_bk"
> delta <- "g_" # for growth
> 
> dt_reg <- dt_psid[ year == 1999 ]
> dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ), .SDcols = fixed_effects_2  ]
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> r0_formula = paste("g_f_8_eq_extract_bk_alt ~ (SC_feenstra) |",
+                    "educ + race_hd + gender_hd + marital_status_hd + state_residence | 0 | state_residence")
> r1_formula = paste("g_f_8_eq_extract_bk_alt ~ (SC_feenstra + log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members) |",
+                    "educ + race_hd + gender_hd + marital_status_hd + state_residence | 0 | state_residence")
> r2_formula = paste("g_f_8_eq_extract_bk_alt ~ (SC_feenstra + log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members) |",
+                    "educ + race_hd + gender_hd + marital_status_hd | 0 | state_residence")
> 
> r1_iv_formula = paste("g_f_8_eq_extract_bk_alt ~ (cum_f_8_labor_inc_hd + log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members)",
+                       "| educ + race_hd + gender_hd + marital_status_hd + state_residence | 0 | state_residence")
> r2_iv_formula = paste("g_f_8_eq_extract_bk_alt ~ (log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members)",
+                       "| educ + race_hd + gender_hd + marital_status_hd + state_residence | (cum_f_8_labor_inc_hd ~ SC_feenstra) | state_residence")
> 
> r0_extract = felm(as.formula(r0_formula), dt_reg)
> r1_extract = felm(as.formula(r1_formula), dt_reg)
> r2_extract = felm(as.formula(r2_formula), dt_reg)
> 
> r1_iv_extract = felm(as.formula(r1_iv_formula), dt_reg[ !is.na(SC_feenstra)])
> r2_iv_extract = felm(as.formula(r2_iv_formula), dt_reg)
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> r_l_extract = list(r0_extract, r1_extract, r2_extract, 
+                    r1_iv_extract, r2_iv_extract)
> stargazer(r_l_extract, type="text")

================================================================================================================
                                                            Dependent variable:                                 
                            ------------------------------------------------------------------------------------
                               r0_formula       r1_formula       r2_formula     r1_iv_formula    r2_iv_formula  
                                  (1)              (2)              (3)              (4)              (5)       
----------------------------------------------------------------------------------------------------------------
SC_feenstra                    -11.052**         -10.558*          -7.512                                       
                                (4.787)          (5.322)          (4.921)                                       
                                                                                                                
cum_f_8_labor_inc_hd                                                                0.038                       
                                                                                   (0.041)                      
                                                                                                                
log_labor_inc_hd                                  -0.015           -0.024           0.114            -2.134     
                                                 (0.057)          (0.048)          (0.121)          (1.450)     
                                                                                                                
log_value_all_debt                                0.020            -0.003           0.032            0.107      
                                                 (0.041)          (0.039)          (0.043)          (0.088)     
                                                                                                                
dti_all                                          -0.469**         -0.396**        -0.567***          -0.004     
                                                 (0.182)          (0.164)          (0.171)          (0.472)     
                                                                                                                
num_family_members                                -0.149           -0.133           -0.195           -0.023     
                                                 (0.129)          (0.124)          (0.129)          (0.260)     
                                                                                                                
`cum_f_8_labor_inc_hd(fit)`                                                                          -0.947     
                                                                                                    (0.629)     
                                                                                                                
----------------------------------------------------------------------------------------------------------------
Observations                      723              723              723              701              701       
R2                               0.063            0.074            0.026            0.074            -0.707     
Adjusted R2                      -0.007           -0.001           0.007            -0.003           -0.850     
Residual Std. Error         4.688 (df = 672) 4.674 (df = 668) 4.656 (df = 708) 4.651 (df = 646) 6.316 (df = 646)
================================================================================================================
Note:                                                                                *p<0.1; **p<0.05; ***p<0.01
> # ---------------------------------------------------------------------
> 
> 
> # ---------------------------------------------------------------------
> brew("./input/tables/psid_extraction.brew.tex", "./output/tables/psid_extraction.tex")
> # ---------------------------------------------------------------------
> 
> 
> 
> proc.time()
   user  system elapsed 
  2.800   0.216   3.311 
