# Replication files for Import Competition and Household Debt

This folder includes replication files and data for the paper *Import Competition and Household Debt* by Barrot, Loualiche, Plosser, & Sauvagnat.

The folder is structured in three folders:
  1. `input` includes the main input datasets used for regressions
  2. `src` includes all of the source code (`R` and `stata`)
  3. `output` includes all of the generated latex tables (`output/tables`) and a pdf document with all generated tables: `output/replication.pdf`

To run the code you can simply use the makefile and run `make all` inside of the folder (make sure to adjust your stata path in the `Makefile`). 
You will need to have stata and R installed. 


## Details of the folder structure

+ Main paper tables (and appendix) are generated in `main_tables.do`
+ Replication and extension of Autor, Dorn, and Hanson (2013) are in `summary_table.R`, `regression_table1.R` and `regression_table2.R`
+ The set of PSID tables are in `psid_summary.R`, `psid_table1.R`, `psid_table2.R`, `psid_table3.R`, `psid_table4.R`, and `psid_table5.R`.
