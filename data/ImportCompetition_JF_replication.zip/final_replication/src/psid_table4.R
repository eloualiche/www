# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(fst)
library(dplyr)
library(stringr)
library(glue)
library(texreg)
library(brew)
library(lfe)
library(data.table)
library(statar)
library(stargazer)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
source("./src/star_builder.R")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# LOAD THE DATA
dt_psid <- readRDS("./input/psid.rds") %>% data.table
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# GET THE LIST OF FIXED EFFECTS
fixed_effects_0  = c("state_residence")
fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
fixed_effects_2  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
# ---------------------------------------------------------------------




# ---------------------------------------------------------------------
reg_form_generic <- function(delta, diff_t, extract_var, fixed_effects, controls){
  as.formula(paste0(delta, "f_", diff_t, "_", extract_var, " ~ (", 
    paste0(stringi::stri_remove_empty(c("SC_feenstra", controls)), collapse = " + "), ") | ",
    paste0(fixed_effects, collapse = " + "), " | 0 | state_residence "))
}  

reg_form_iv1_extract <- function(delta, diff_t, extract_var){
  as.formula(paste0(delta, "f_", diff_t, "_", extract_var, " ~ (g_f_", diff_t, "_labor_inc_hd + ", 
    paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
}
reg_form_iv2_extract <- function(delta, diff_t, extract_var){
  as.formula(paste0(delta, "f_", diff_t, "_", extract_var, " ~ (", 
    paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_2, collapse = " + "), " | ",
    "(g_f_", diff_t, "_labor_inc_hd ~ SC_feenstra) | state_residence "))
}
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
diff_t     <- 8
extract_var_bk <- "eq_extract_bk_alt" # or "eq_extract_bk"
delta <- "g_" # for growth

dt_reg <- dt_psid[ year == 1999 ]
dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ), .SDcols = fixed_effects_2  ]
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
r0_formula = paste("g_f_8_eq_extract_bk_alt ~ (SC_feenstra) |",
                   "educ + race_hd + gender_hd + marital_status_hd + state_residence | 0 | state_residence")
r1_formula = paste("g_f_8_eq_extract_bk_alt ~ (SC_feenstra + log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members) |",
                   "educ + race_hd + gender_hd + marital_status_hd + state_residence | 0 | state_residence")
r2_formula = paste("g_f_8_eq_extract_bk_alt ~ (SC_feenstra + log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members) |",
                   "educ + race_hd + gender_hd + marital_status_hd | 0 | state_residence")

r1_iv_formula = paste("g_f_8_eq_extract_bk_alt ~ (cum_f_8_labor_inc_hd + log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members)",
                      "| educ + race_hd + gender_hd + marital_status_hd + state_residence | 0 | state_residence")
r2_iv_formula = paste("g_f_8_eq_extract_bk_alt ~ (log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members)",
                      "| educ + race_hd + gender_hd + marital_status_hd + state_residence | (cum_f_8_labor_inc_hd ~ SC_feenstra) | state_residence")

r0_extract = felm(as.formula(r0_formula), dt_reg)
r1_extract = felm(as.formula(r1_formula), dt_reg)
r2_extract = felm(as.formula(r2_formula), dt_reg)

r1_iv_extract = felm(as.formula(r1_iv_formula), dt_reg[ !is.na(SC_feenstra)])
r2_iv_extract = felm(as.formula(r2_iv_formula), dt_reg)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
r_l_extract = list(r0_extract, r1_extract, r2_extract, 
                   r1_iv_extract, r2_iv_extract)
stargazer(r_l_extract, type="text")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
brew("./input/tables/psid_extraction.brew.tex", "./output/tables/psid_extraction.tex")
# ---------------------------------------------------------------------


