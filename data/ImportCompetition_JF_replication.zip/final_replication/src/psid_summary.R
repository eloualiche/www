# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(fst)
library(dplyr)
library(skimr)
library(brew)
library(gt)
library(kableExtra)
library(data.table)
library(statar)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
dt_psid <- readRDS("./input/psid.rds") %>% data.table
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
summary_var <- c("SC_feenstra", 
	"unemployed", "labor_inc_hd", "dti_all", "value_all_debt",
	"cons_total", "food_total", "house_val",
	paste0("f_8_unemployed"),
	paste0("g_f_8", c("_labor_inc_hd", "_dti_all", "_value_all_debt")) ,
	paste0("g_f_8", c("_cons_total", "_food_total")) )

dt_psid[, summary_var, with = F]
dt_psid[ year == 1999 & !is.na(SC_feenstra) ][, summary_var, with = F] %>% skim
dt_psid[ year == 1999 ][, summary_var, with = F] %>% skim

dt_sum_stats1 <- dt_psid[ year == 1999 & !is.na(SC_feenstra) & !is.na(g_f_8_labor_inc_hd),
	c("unique_id", summary_var), with = F]
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------	
build_sum_table <- function(dt_sum_stats, summary_var,	title, label){

	Nrow = nrow(dt_sum_stats[, c(summary_var), with=F] )
	dt_sum <- dt_sum_stats[, c(summary_var), with=F] %>% skim %>% data.table
	dt_sum_logical <- dt_sum[ skim_type == "logical" ]
	dt_sum_numeric <- dt_sum[ skim_type == "numeric" ]

	setnames(dt_sum_logical, gsub("logical.", "", colnames(dt_sum_logical)) )
	setnames(dt_sum_numeric, gsub("numeric.", "", colnames(dt_sum_numeric)) )
	no_keep <- colnames(dt_sum_numeric)[grep("logical", colnames(dt_sum_numeric))]
	dt_sum_numeric[, (no_keep) := NULL ]
	no_keep <- c("count", colnames(dt_sum_logical)[grep("numeric", colnames(dt_sum_logical))])
	dt_sum_logical[, (no_keep) := NULL ]
	dt_sum_logical

	dt_sum <- rbind(dt_sum_logical, dt_sum_numeric, fill = T)
	dt_sum[, c("skim_type") := NULL ]
	setnames(dt_sum, "skim_variable", "variable")
	dt_sum[, complete := Nrow - n_missing ]

	setcolorder(dt_sum, c("variable", "complete", "mean", "sd", "p25", "p50", "p75"))
	setnames(dt_sum, "complete", "n")
	dt_sum <- dt_sum[, 1:7 ]
	dt_sum_fwd <- dt_sum[ grep("f_8", dt_sum[["variable"]]) ]
	dt_sum_now <- dt_sum[ !grep("f_8", dt_sum[["variable"]]) ]
	dt_sum_fwd <- dt_sum_fwd[ c(2, 1, 6, 4, 3)]
	dt_sum_now <- dt_sum_now[ c(2, 8, 3, 1, 7, 5, 4) ]

	var_names = c(
		"Income (Head)",
		"Unemployed",
		"Food Expenditures",
		"Total Debt",
		"Debt to Income ratio")

	dt_sum_fwd[, variable_name := var_names ]
	dt_sum_fwd[, group         := paste0("Growth rate: ", 1999, "-", 2007) ]
	dt_sum_now[, variable_name := c("Shipping Costs", "House value", var_names) ]
	dt_sum_now[, group         := paste0("Level in: ", 1999) ]
	dt_sum_all <- rbind(dt_sum_now, dt_sum_fwd)

	dt_sum_all[, c("mean", "sd", "p25", "p50", "p75") := lapply(.SD, prettyNum), .SDcols = c("mean", "sd", "p25", "p50", "p75")] 

	return(dt_sum_all)

  	}
# ------------------------------------------------------------------------------------------



# ------------------------------------------------------------------------------------------
dt_sum1 <- build_sum_table(dt_sum_stats1, summary_var, 
  title="PSID Summary Statistics: Restricted Sample", label = "table:summary:psid:1")
dt_sum1[]
# ------------------------------------------------------------------------------------------


# ------------------------------------------------------------------------------------------
brew("./input/tables/psid_summary_stats.brew.tex", 
	   "./output/tables/psid_summary_stats.tex")
# ------------------------------------------------------------------------------------------









