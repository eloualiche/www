# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(dplyr)
library(skimr)
library(stringr)
library(brew)
library(magrittr)
library(glue)
library(data.table)

library(haven)
library(statar)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# READ REGRESSION DATA
# This corresponds to our main dataset
dt_blps <- readRDS("./input/blps_data_reg.rds") %>% data.table()
# This corresponds to the main ADH dataset
dt_adh <- read_dta("./input/workfile_china.dta") %>% data.table
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# Merge both datasets
dt_adh_sub = dt_adh[t2 == 1, 
    .(czone, statefip, relchg_avg_hhincsum_pc_pw, relchg_avg_hhincwage_pc_pw,
      relchg_med_hhincsum_pc_pw, relchg_med_hhincwage_pc_pw,
      d_avg_hhincsum_pc_pw, d_med_hhincsum_pc_pw) ]

dt_blps_full <- merge(dt_blps, dt_adh_sub, by = c("czone"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
brew_stat <- function(dt, col_var, var=NULL){
    dt <- dt[, col_var, with = FALSE ]
    dt <- cbind(dt %>% skim() %>% data.table, N=nrow(dt))
    setnames(dt, gsub("numeric.", "", colnames(dt)))
    setnames(dt, gsub("skim_", "", colnames(dt)))
    if (!is.null(var)){ dt[, variable := var]}
    return(dt)
}
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# MAGNITUDES
dt_stat_SC   = brew_stat(dt_blps_full, c("SC"))
dt_stat_NTR  = brew_stat(dt_blps_full, c("NTRgap"))
dt_stat_AADH = brew_stat(dt_blps_full, c("autor"))

dt_stat_SC[]
dt_stat_NTR[]
dt_stat_AADH[]

dt_stat_tradeus <- rbind(
    brew_stat(dt_adh, c("d_tradeusch_pw"), var="full"),
    brew_stat(dt_adh[t2==0], c("d_tradeusch_pw"), var="1990"),
    brew_stat(dt_adh[t2==1], c("d_tradeusch_pw"), var="2000")
    )
dt_stat_tradeus[]

dt_stat_inc <- rbind(
    brew_stat(dt_adh, c("relchg_avg_hhincsum_pc_pw"), var="full"),
    brew_stat(dt_adh[t2==0], c("relchg_avg_hhincsum_pc_pw"), var="1990"),
    brew_stat(dt_adh[t2==1], c("relchg_avg_hhincsum_pc_pw"), var="2000")
    )
dt_stat_inc[]

dt_stat_inc2 <- rbind(
    brew_stat(dt_adh, c("relchg_avg_hhincwage_pc_pw"), var="full"),
    brew_stat(dt_adh[t2==0], c("relchg_avg_hhincwage_pc_pw"), var="1990"),
    brew_stat(dt_adh[t2==1], c("relchg_avg_hhincwage_pc_pw"), var="2000")
    )
dt_stat_inc2[]

brew("./input/tables/table_summary1.brew.tex", "./output/tables/table_summary_magnitudes.tex")
# ---------------------------------------------------------------------

