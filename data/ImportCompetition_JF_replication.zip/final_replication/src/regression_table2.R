# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(dplyr)
library(skimr)
library(stringr)
library(lfe)
library(AER)
library(lmtest)
library(stargazer)
library(fst)
library(brew)
library(magrittr)
library(glue)
library(data.table)

library(haven)
library(statar)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# APPEND REQUIRED PACKAGES
source("./src/star_builder.R")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# READ REGRESSION DATA
dt_blps <- readRDS("./input/blps_data_reg.rds") %>% data.table
dt_adh  <- read_dta("./input/workfile_china.dta") %>% data.table

dt_adh_sub<- dt_adh[t2 == 1, 
    .(czone, statefip, relchg_avg_hhincsum_pc_pw, relchg_avg_hhincwage_pc_pw,
      relchg_med_hhincsum_pc_pw, relchg_med_hhincwage_pc_pw,
      d_avg_hhincsum_pc_pw, d_med_hhincsum_pc_pw) ]
dt_blps_full <- merge(dt_blps, dt_adh_sub, by = c("czone"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# variables for regressions
control_set1 <- c(
    "l_shind_manuf_cbp", "l_sh_popedu_c", "l_sh_popfborn",
    "l_sh_empl_f", "l_sh_routine33", "l_task_outsource", "t2"
)
control_set1p <- paste(control_set1, collapse = " + ")
regional_set <- paste0("reg_", c("midatl", "encen", "wncen", "satl", "escen", "wscen", "mount", "pacif"))
regional_setp <- paste(regional_set, collapse = " + ")

lhs_set <- c(
    "relchg_avg_hhincsum_pc_pw", "relchg_avg_hhincwage_pc_pw",
    "relchg_med_hhincsum_pc_pw", "relchg_med_hhincwage_pc_pw",
    "d_avg_hhincsum_pc_pw", "d_avg_hhincwage_pc_pw",
    "d_med_hhincsum_pc_pw", "d_med_hhincwage_pc_pw"
)
rhs_shocks <- c("d_tradeusch_pw", "d_tradeotch_pw_lag")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# TABLE 9 NTR REDUCED FORM
r_1a_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_2a_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_3a_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_4a_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ NTRgap + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))

dt_reg2 <- merge(dt_adh, dt_blps[, .(czone, NTRgap)], by = c("czone"))
dt_reg2 <- dt_reg2[, c(lhs_set, rhs_shocks, control_set1, regional_set,
    "NTRgap", "czone", "yr", "statefip", "timepwt48"), with = F ]
dt_reg2b <- dt_reg2[ t2 == 1 ] # only latter period

r_1a_res <- felm(r_1a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_2a_res <- felm(r_2a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_3a_res <- felm(r_3a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_4a_res <- felm(r_4a_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])

r_list_NTR <- list(r_1a_res, r_2a_res, r_3a_res, r_4a_res)
stargazer(r_list_NTR, type="text")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# TABLE 9 AADH REDUCED FORM
r_1b_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_2b_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_3b_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_4b_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ autor + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))

dt_reg2 <- merge(dt_adh, dt_blps[, .(czone, autor)], by = c("czone"))
dt_reg2 <- dt_reg2[, c(lhs_set, rhs_shocks, control_set1, regional_set,
    "autor", "czone", "yr", "statefip", "timepwt48"), with = F ]
dt_reg2b <- dt_reg2[ t2 == 1 ] # only latter period

r_1b_res <- felm(r_1b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_2b_res <- felm(r_2b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_3b_res <- felm(r_3b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_4b_res <- felm(r_4b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])

r_list_AADH <- list(r_1b_res, r_2b_res, r_3b_res, r_4b_res)
stargazer(r_list_AADH, type="text")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
stargazer(c(r_list_NTR, r_list_AADH),
    keep = c("NTR*", "autor*"),
    dep.var.labels.include = FALSE, type = "text"
)

brew("./input/tables/table_ADH_comparison2.brew.tex", "./output/tables/table_ADH_comparison2.tex")
# ---------------------------------------------------------------------

