# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(fst)
library(dplyr)
library(stringr)
library(skimr)
library(rlist)
library(texreg)
library(brew)
library(lfe)
library(data.table)
library(statar)
library(stargazer)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
source("./src/star_builder.R")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
dt_psid <- readRDS("./input/psid.rds") %>% data.table
dt_reg  = dt_psid[ year == 1999 ]
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
fixed_effects_2  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
cluster_var      = "state_residence"  

# - transform the fixed effects into factor / level variables
dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ),
       .SDcols = fixed_effects_2  ]       
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# SET UP THE FIRST REGRESSIONS
# --- LABOR
unemp_var <- paste0("f_8_unemployed")

reg0_form_unemp <- as.formula(paste0(unemp_var, " ~ SC_feenstra | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
reg1_form_unemp <- as.formula(paste0(unemp_var, " ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
reg2_form_unemp <- as.formula(paste0(unemp_var, " ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))

reg0_form_inc   <- as.formula(paste0("g_f_8_labor_inc_hd ~ SC_feenstra | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
reg1_form_inc   <- as.formula(paste0("g_f_8_labor_inc_hd ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
reg2_form_inc   <- as.formula(paste0("g_f_8_labor_inc_hd ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))

reg0_unemp  <- felm(reg0_form_unemp, dt_reg[unemployed==0])
reg1_unemp  <- felm(reg1_form_unemp, dt_reg[unemployed==0])
reg2_unemp  <- felm(reg2_form_unemp, dt_reg[unemployed==0])
reg0_inc     <- felm(reg0_form_inc, dt_reg)
reg1_inc     <- felm(reg1_form_inc, dt_reg)
reg2_inc     <- felm(reg2_form_inc, dt_reg)

# for Final table we keep
r_brew_list1 <- list(reg1_unemp, reg2_unemp, reg1_inc, reg2_inc)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# ---   TOTAL DEBT AND DTI
reg0_form_dti <- as.formula(paste0("d_f_8_dti_all ~ SC_feenstra | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
reg1_form_dti <- as.formula(paste0("d_f_8_dti_all ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
reg2_form_dti <- as.formula(paste0("d_f_8_dti_all ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))

reg0_form_debt <- as.formula(paste0("g_f_8_value_all_debt ~ SC_feenstra | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))
reg1_form_debt <- as.formula(paste0("g_f_8_value_all_debt ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_1, collapse = " + "), " | 0 | ", cluster_var))
reg2_form_debt <- as.formula(paste0("g_f_8_value_all_debt ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
    paste0(fixed_effects_2, collapse = " + "), " | 0 | ", cluster_var))

reg0b_dti  <- felm(reg0_form_dti, dt_reg)  # state fe no controls
reg1b_dti  <- felm(reg1_form_dti, dt_reg)  # no state fe
reg2b_dti  <- felm(reg2_form_dti, dt_reg)  # state fe
reg0b_debt <- felm(reg0_form_debt, dt_reg) # state fe no controls
reg1b_debt <- felm(reg1_form_debt, dt_reg) # no state fe
reg2b_debt <- felm(reg2_form_debt, dt_reg) # state fe

r_brew_list2 <- list(reg1b_dti, reg2b_dti, reg1b_debt, reg2b_debt)
# -------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------
# Second set of regressions: different types of debt
# mortgage
reg0_form_mort <- as.formula(paste0("d_f_8_dti_re ~ SC_feenstra | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
reg1_form_mort <- as.formula(paste0("d_f_8_dti_re ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
reg2_form_mort <- as.formula(paste0("d_f_8_dti_re ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
# other (cc)
reg0_form_other <- as.formula(paste0("d_f_8_dti_other ~ SC_feenstra | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
reg1_form_other <- as.formula(paste0("d_f_8_dti_other ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
reg2_form_other <- as.formula(paste0("d_f_8_dti_other ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
# car
reg0_form_car <- as.formula(paste0("d_f_8_dti_car ~ SC_feenstra | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))
reg1_form_car <- as.formula(paste0("d_f_8_dti_car ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
reg2_form_car <- as.formula(paste0("d_f_8_dti_car ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_2, collapse = " + "), " | 0 | state_residence "))


reg0b_mort     <- felm(reg0_form_mort, dt_reg)
reg1b_mort     <- felm(reg1_form_mort, dt_reg)
reg2b_mort     <- felm(reg2_form_mort, dt_reg)
reg0b_other  <- felm(reg0_form_other, dt_reg)
reg1b_other  <- felm(reg1_form_other, dt_reg)
reg2b_other  <- felm(reg2_form_other, dt_reg)
reg0b_car    <- felm(reg0_form_car, dt_reg)
reg1b_car    <- felm(reg1_form_car, dt_reg)
reg2b_car    <- felm(reg2_form_car, dt_reg)
   
r_brew_list3 <- list(reg1b_mort, reg2b_mort, reg1b_other, reg2b_other, reg1b_car, reg2b_car)
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
stargazer(r_brew_list1, type="text")
stargazer(r_brew_list2, type="text")
stargazer(r_brew_list3, type="text")
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
brew("./input/tables/psid_main.brew.tex", "./output/tables/psid_main.tex")
# -------------------------------------------------------------------------------------------


