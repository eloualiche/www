# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(dplyr)
library(skimr)
library(stringr)
library(lfe)
library(AER)
library(lmtest)
library(stargazer)
library(brew)
library(magrittr)
library(glue)
library(data.table)

library(haven)
library(statar)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# APPEND REQUIRED PACKAGES
source("./src/star_builder.R")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# READ ADH DATA
dt_adh <- read_dta("./input/workfile_china.dta") %>% data.table()
# READ BLPS DATA
dt_blps <- readRDS("./input/blps_data_reg.rds") %>% data.table()
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# variables for regressions
control_set1 <- c(
    "l_shind_manuf_cbp", "l_sh_popedu_c", "l_sh_popfborn",
    "l_sh_empl_f", "l_sh_routine33", "l_task_outsource", "t2"
)
control_set1p <- paste(control_set1, collapse = " + ")
regional_set <- paste0("reg_", c("midatl", "encen", "wncen", "satl", "escen", "wscen", "mount", "pacif"))
regional_setp <- paste(regional_set, collapse = " + ")

lhs_set <- c(
    "relchg_avg_hhincsum_pc_pw", "relchg_avg_hhincwage_pc_pw",
    "relchg_med_hhincsum_pc_pw", "relchg_med_hhincwage_pc_pw",
    "d_avg_hhincsum_pc_pw", "d_avg_hhincwage_pc_pw",
    "d_med_hhincsum_pc_pw", "d_med_hhincwage_pc_pw"
)
rhs_shocks <- c("d_tradeusch_pw", "d_tradeotch_pw_lag")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# TABLE 9 PURE ADH
r_1a_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ ", 
    control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
r_2a_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ ", 
    control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
r_3a_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ ", 
    control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))
r_4a_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ ", 
    control_set1p, " + ", regional_setp, " | 0 | (d_tradeusch_pw ~ d_tradeotch_pw_lag) | statefip"))


dt_reg <- dt_adh[, c(lhs_set, rhs_shocks, control_set1, regional_set, "yr", "statefip", "timepwt48"), with = F ]
dt_reg2 <- dt_reg[ t2 == 1 ] # only latter period

r_1a_res <- felm(r_1a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
r_2a_res <- felm(r_2a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
r_3a_res <- felm(r_3a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
r_4a_res <- felm(r_4a_felm, data = dt_reg2, weights = dt_reg2[["timepwt48"]])
r_list_ADH <- list(r_1a_res, r_2a_res, r_3a_res, r_4a_res)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# TABLE 9 Shipping COSTS: REDUCED FORM
r_1b_felm <- as.formula(paste("relchg_avg_hhincsum_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_2b_felm <- as.formula(paste("relchg_avg_hhincwage_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_3b_felm <- as.formula(paste("relchg_med_hhincsum_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))
r_4b_felm <- as.formula(paste("relchg_med_hhincwage_pc_pw ~ SC + ", control_set1p, " + ", regional_setp,
    " | 0 | 0 | statefip"))

dt_reg2 = merge(dt_adh, dt_blps[, .(czone, SC)], , by = c("czone"))
dt_reg2 = dt_reg2[, c(lhs_set, rhs_shocks, control_set1, regional_set,
    "SC", "czone", "yr", "statefip", "timepwt48"), with = F ]
dt_reg2b <- dt_reg2[ t2 == 1 ] # only latter period

r_1b_res <- felm(r_1b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_2b_res <- felm(r_2b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_3b_res <- felm(r_3b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_4b_res <- felm(r_4b_felm, data = dt_reg2b, weights = dt_reg2b[["timepwt48"]])
r_list_SC <- list(r_1b_res, r_2b_res, r_3b_res, r_4b_res)

stargazer(r_list_SC, type="text")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
stargazer(c(r_list_SC, r_list_ADH),
    keep = c("SC*", "d_tradeusch*"),
    dep.var.labels.include = FALSE, type = "text"
)

brew("./input/tables/table_ADH_comparison1.brew.tex", "./output/tables/table_ADH_comparison1.tex")
# ---------------------------------------------------------------------
