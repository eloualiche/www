# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(fst)
library(dplyr)
library(stringr)
library(skimr)
library(rlist)
library(texreg)
library(brew)
library(lfe)
library(data.table)
library(statar)
library(stargazer)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
source("./src/star_builder.R")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
dt_psid <- readRDS("./input/psid.rds") %>% data.table
dt_reg  = dt_psid[ year == 1999 ]
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
fixed_effects  = c("educ", "race_hd", "gender_hd", "marital_status_hd", "state_residence")
other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
cluster_var      = "state_residence"  # lowers the standard errors

# - transform the fixed effects into factor / level variables
dt_reg[, paste0(fixed_effects) := lapply(.SD, function(x) as.factor(x) ),
       .SDcols = fixed_effects  ]       
# ---------------------------------------------------------------------



# --------------------------------------------------------------------
dt_reg %>% skim(g_f_8_labor_inc_hd)

unemp_var    = "cum_f_8_unemp"
cluster_var  = "state_residence"  
# --------------------------------------------------------------------


# --------------------------------------------------------------------
# --- GROWTH RATE
reg3_iv_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ", 
        "cum_f_8_labor_inc_hd +  log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
        "state_residence + race_hd + gender_hd + marital_status_hd | ",
        "0 | ", cluster_var) ) 
reg4_iv_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ", 
        unemp_var, " +  log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
        "state_residence + race_hd + gender_hd + marital_status_hd | ",
        "0 | ", cluster_var) ) 

# IV REGRESSIONS: Instrument is income growth
reg5_iv1_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
  "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
      " race_hd + gender_hd + marital_status_hd | ",
      "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", cluster_var) )
reg5b_iv1_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
  "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
      "state_residence + race_hd + gender_hd + marital_status_hd | ",
      "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", cluster_var) )
# INSTRUMENT IS NOW THE UNEMPLOYMENT SPELL
reg5_iv2_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
  "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
        " race_hd + gender_hd + marital_status_hd | ",
        "(", unemp_var,  " ~ SC_feenstra) | ",
        cluster_var) )
reg5b_iv2_debt_form <- as.formula(paste0("g_f_8_value_all_debt ~ ",
  "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
        "state_residence + race_hd + gender_hd + marital_status_hd | ",
        "(", unemp_var,  " ~ SC_feenstra) | ",
        cluster_var) )

reg3_iv_debt  <- felm(reg3_iv_debt_form, dt_reg)
reg3b_iv_debt <- felm(reg3_iv_debt_form, dt_reg[ !is.na(SC_feenstra) ])
reg4_iv_debt  <- felm(reg4_iv_debt_form, dt_reg)
reg4b_iv_debt <- felm(reg4_iv_debt_form, dt_reg[ !is.na(SC_feenstra) ])

reg5_iv1_debt  <- felm(reg5_iv1_debt_form, dt_reg)
reg5b_iv1_debt <- felm(reg5b_iv1_debt_form, dt_reg)
reg5_iv2_debt  <- felm(reg5_iv2_debt_form, dt_reg)
reg5b_iv2_debt <- felm(reg5b_iv2_debt_form, dt_reg)

r_iv_list1 <- list(reg3_iv_debt, reg3b_iv_debt, 
                   reg4_iv_debt, reg4b_iv_debt, 
                   reg5_iv1_debt, reg5b_iv1_debt, 
                   reg5_iv2_debt, reg5b_iv2_debt)

stargazer(r_iv_list1, type="text")
# for the F-statistics
# screenreg(r_iv_list1, include.fstatistic = T)
# --------------------------------------------------------------------


# --------------------------------------------------------------------
## DTI: IV regressions
reg3_iv_dti_form <- as.formula(paste0("g_f_8_dti_all ~ cum_f_8_labor_inc_hd",
          "+ log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
          "state_residence + race_hd + gender_hd + marital_status_hd | ",
          "0 | ", cluster_var)    )
reg4_iv_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ", unemp_var,
          "+ log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
          "state_residence + race_hd + gender_hd + marital_status_hd | ",
          "0 | ", cluster_var)    )
reg5_iv1_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
           "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
           " race_hd + gender_hd + marital_status_hd | ",
           "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", "state_residence")    )
reg5b_iv1_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
           "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
           "state_residence + race_hd + gender_hd + marital_status_hd | ",
           "(cum_f_8_labor_inc_hd ~ SC_feenstra) | ", "state_residence")    )
reg5_iv2_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
           "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
           "race_hd + gender_hd + marital_status_hd | ",
           "(", unemp_var, " ~ SC_feenstra) | ", "state_residence")    )
reg5b_iv2_dti_form <- as.formula(paste0("g_f_8_dti_all ~ ",
           "log_labor_inc_hd + log_value_all_debt + dti_all + num_family_members | ",
           "state_residence +  race_hd + gender_hd + marital_status_hd | ",
           "(", unemp_var, " ~ SC_feenstra) | ", "state_residence")    )

reg3_iv_dti   <- felm(reg3_iv_dti_form, dt_reg)
reg3b_iv_dti  <- felm(reg3_iv_dti_form, dt_reg[ !is.na(SC_feenstra) ])
reg4_iv_dti   <- felm(reg4_iv_dti_form, dt_reg)
reg4b_iv_dti  <- felm(reg4_iv_dti_form, dt_reg[ !is.na(SC_feenstra) ])
reg5_iv1_dti   <- felm(reg5_iv1_dti_form, dt_reg)
reg5b_iv1_dti  <- felm(reg5b_iv1_dti_form, dt_reg)
reg5_iv2_dti   <- felm(reg5_iv2_dti_form, dt_reg)
reg5b_iv2_dti  <- felm(reg5b_iv2_dti_form, dt_reg)

r_iv_list2 <- list(reg3_iv_dti, reg3b_iv_dti, 
                   reg4_iv_dti, reg4b_iv_dti, 
                   reg5_iv1_dti, reg5b_iv1_dti, 
                   reg5_iv2_dti, reg5b_iv2_dti)

stargazer(r_iv_list2, type="text")
# screenreg(r_iv_list2, include.fstatistic = T) # for the F-statistics
# --------------------------------------------------------------------------------


# --------------------------------------------------------------------------------
brew("./input/tables/psid_iv_main.brew.tex", "./output/tables/psid_iv_main.tex")
# --------------------------------------------------------------------------------















