# ---------------------------------------------------------------------
message("Log file for code executed at\n")
message(format(Sys.time(), "%a %b %d %X %Y"))
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
library(crayon)
library(devtools)

library(fst)
library(dplyr)
library(stringr)
library(skimr)
library(brew)
library(binom)
library(texreg)
library(gt)
library(lfe)
library(ggplot2)
library(data.table)
library(statar)
library(stargazer)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
source("./src/star_builder.R")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
dt_psid <- readRDS("./input/psid.rds") %>% data.table
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# GET THE LIST OF FIXED EFFECTS
fixed_effects_0  = c("state_residence")
fixed_effects_1  = c("educ", "race_hd", "gender_hd", "marital_status_hd")
fixed_effects_2  = c(fixed_effects_0, fixed_effects_1)
other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "dti_all", "num_family_members")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
dt_reg <- dt_psid[ year == 1999 ]
other_controls   = c("log_labor_inc_hd", "log_value_all_debt", "num_family_members")
dt_reg[, paste0(fixed_effects_2) := lapply(.SD, function(x) as.factor(x) ),
       .SDcols = fixed_effects_2  ]
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
rega_form_food   <- as.formula(paste0("g_f_8_food_total ~ SC_feenstra | ",
    paste0(fixed_effects_0, collapse = " + "), " | 0 | state_residence "))
regb_form_food   <- as.formula(paste0("g_f_8_food_total ~ SC_feenstra | ",
    paste0(fixed_effects_1, collapse = " + "), " | 0 | state_residence "))
regc_form_food   <- as.formula(paste0("g_f_8_food_total ~ (SC_feenstra + ", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(c(fixed_effects_0, fixed_effects_1), collapse = " + "), " | 0 | state_residence "))
regd_form_food   <- as.formula(paste0("g_f_8_food_total ~ (SC_feenstra +", 
  paste0(other_controls, collapse = " + "), ") | ",
  paste0(fixed_effects_0, collapse = " + "), " | 0 | state_residence "))

rega_food    <- felm(rega_form_food, dt_reg[ food_total>0])
regb_food    <- felm(regb_form_food, dt_reg[ food_total>0])
regc_food    <- felm(regc_form_food, dt_reg[ food_total>0])
regd_food    <- felm(regd_form_food, dt_reg[ food_total>0])

r_list_food <- list(rega_food, regb_food, regd_food, regc_food)
stargazer(r_list_food, type="text")
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
brew("./input/tables/psid_expenditure.brew.tex", 
     "./output/tables/psid_expenditure.tex", )
# ---------------------------------------------------------------------


