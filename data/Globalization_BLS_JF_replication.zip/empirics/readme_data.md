# THE GLOBALIZATION RISK PREMIUM
  Barrot, Loualiche & Sauvagnat

This is the readme file for *The Globalization Risk Premium* data files.


## Data Sets
Datasets are stored under the `./data/` directory. We use the following datasets:


### Included datasets

  + `/brodaweinstein_sic.dta`: demand elasticities from *Broda & Weinstein (2006), "Globalization and the Gains From Variety,"; QJE:121 (2)*
  + `exchangerateUSDfrombankofenglandeurodolmonthly.dta`, `exchangerateUSDfrombankofenglandmonthly2.dta` contain monthly spot exchange rates data from the Bank of England
  + `ff5europe.dta`, `ff5f.dta`: Fama & French five factors downloaded from Ken French data library
  + `gdpdeflatorbea.dta`: GDP deflator from the [BEA](https://www.bea.gov/national/index.htm#gdp)
  + `sic5811.dta`: NBER-CES Manufacturing Industry Database available at http://www.nber.org/nberces/
  + `tariffs.dta`: list of tariffs downloaded from the [Center for International Data at UC Davis](http://cid.econ.ucdavis.edu/)
  + `trade_country_census.csv`: trade data available from the [US Census](https://www.census.gov/foreign-trade/data/index.html)
  + `xm_sic87_72_105_20120424.dta`: from Peter Schott website http://faculty.som.yale.edu/peterschott/sub_international.htm


### Datasets not included  

  + The data under the folder  `./TradeDataSchottHS/` are available directly from Peter Schott's data library [here](http://faculty.som.yale.edu/peterschott/sub_international.htm), originally from the US Census. The folder is not included because its full size is 9.7Gb
    + `./TradeDataSchottHS/exp_detl_yearly_YYn.dta` where `YY` goes from 89 to 115: Export data
    + `./TradeDataSchottHS/imp_detl_yearly_YYn.dta` where `YY` goes from 89 to 115: Import data

  + Standard files from WRDS (Compustat and CRSP monthly files):
    + `betaCRSP.dta`
    + `compsic.dta`
    + `compustatnew.dta`
    + `crspcomp.dta`
    + `crspm_1926.dta`
    + `crspm_v2.dta`
    + `EACompustat2016.dta`

  + Files from EUROFIDAI on stock market data in Europe
    + `EUROFIDAI_Stocks_Daily_TimesSeries.csv`
    + `EUROFIDAI_Stocks_Monthly_Returns.csv`
    + `EUROFIDAI_Stocks_Reference_Data.csv`

  + Earnings forecasts from I/B/E/S under folder `./IBES/` (merged with CRSP daily files)
    + `actual.dta`
    + `forecast.dta`
    + `dailycrsp.dta`
    + `dailyff5.dta`



## Analysis
Both `do` files are in the `./prog/` directory.

  + `ConstructDatabases.do`: prepares the database for analysis
  + `Tables.do`: generates the tables in the paper
