#! /usr/bin/R
#
# read_dynare.R
#
# (c) Barrot, Loualiche & Sauvagnat
#
# Routines that reads dynare models and files into R
#
#
# Created on     Dec.   1st 2017
# Last modified  Dec.   1st 2017
#
########################################


read_dynare <- function(path_to_simul)
{

  res_dynare <- readMat(path_to_simul)

  dt_simul_original <- res_dynare$oo.
  dt_other          <- res_dynare$M.

  # parameters
  param = data.table(t(dt_other[,,1]$params))
  setnames(param, sapply(dt_other[,,1]$param.names, function(x) gsub(" ", "", x)) %>% as.vector)

  # simulation
  dt_simul_exo  <- data.table(dt_simul_original[,,1]$exo.simul)               # shocks simulation path
  dt_simul_endo <- data.table(t(dt_simul_original[,,1]$endo.simul))
  dt_simul_irf  <- data.table(t(dt_simul_original[,,1]$irfs[,,1]))[, lapply(.SD, unlist), .SD]

  setnames(dt_simul_exo,  sapply(dt_other[,,1]$exo.names, function(x) gsub(" ", "", x)) %>% as.vector)
  setnames(dt_simul_endo, sapply(dt_other[,,1]$endo.names, function(x) gsub(" ", "", x)) %>% as.vector)
  setnames(dt_simul_irf,  names(dt_simul_original[,,1]$irfs[,,1]) )

  dt_simul <- cbind(time=seq(1:nrow(dt_simul_exo)), dt_simul_exo, dt_simul_endo)

  return( list(param, dt_simul, dt_simul_irf) )

}
