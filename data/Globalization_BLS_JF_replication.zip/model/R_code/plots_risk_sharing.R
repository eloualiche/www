#! /usr/bin/R
#
# risk_sharing_plots.R
#
# (c) Barrot, Loualiche & Sauvagnat
#
# Analyze model solved in julia + dynare -- > plots
#
#
# Created on     August 2016
# Last modified  June   2018
#
#
########################################


# load relevant libraries
library(tikzDevice);
library(ggplot2);
library(ggthemes);
library(wesanderson);
library(scales);
library(ggpubr);
library(gridExtra)
library(dplyr); library(tidyr)
library(data.table)
library(statar)
library(here)


# --------------------------------------------------------------------------------
## setwd("~/Dropbox/TRADE/erik_trade/trade_model/")
setwd(here::here()); getwd()


# ------------------------------------------------------------------------------
latex_percent <- function (x) {
    x <- plyr::round_any(x, scales:::precision(x)/100)
    stringr::str_c(comma(x * 100), "\\%")
}
wes_pal_col <- wes_palette("Zissou1")[c(5,1)]
# ------------------------------------------------------------------------------


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# --- PLOTS



# ------------------------------------------------------------------
# --- FIGURE 3:
# --- Figure 3a: Risk premia with different degrees of risk sharing
# --- Figure 3b: Consumption response with ...

## --- 1. to generate the data: run the model for various levels of risk sharing and backout
##     a. cons. response b. risk premium

# a. elasticity
dt_rs <- data.table()
for (alpha_rs in c(0, 0.5, 0.75, 0.85, 0.9, 0.95, 1)){

  dt_tmp <- readRDS(paste0("./output/simul_rs_", 100*alpha_rs, ".rds"))
  r3 <- lm(cons ~ epsastar, dt_tmp)
  dt_tmp[, cons_elas := coefficients(r3)[2] ]

  dt_rs <- rbind(dt_rs, dt_tmp)

}
dt_rs[]

# --- clean up for plot
dt_rs_plot <- dt_rs[, .(alpha_rs, rf, ret1D_ex, ret2D_ex, cons_elas) ]
dt_rs_plot <- dt_rs_plot[, lapply(.SD, mean), by = .(alpha_rs) ]
dt_rs_plot[]

dt_rs_plot <- dt_rs_plot[, .(alpha_rs, cons_elas, rf=4*rf, ret1D=4*(rf+ret1D_ex), ret2D=4*(rf+ret2D_ex)) ] %>%
    gather(ret_type, ret, -alpha_rs) %>% data.table
dt_rs_plot
dt_rs_plot[ ret_type != "cons_elas", ret_type_alt := "ret" ][ ret_type == "cons_elas", ret_type_alt := "cons" ]


# --- PLOT
dt_rs_plot <- dt_rs_save[, .(alpha_rs, cons_elas, rf=4*rf, ret1D=4*(rf+ret1D_ex), ret2D=4*(rf+ret2D_ex)) ] %>%
    gather(ret_type, ret, -alpha_rs) %>% data.table
dt_rs_plot[ ret_type != "cons_elas", ret_type_alt := "ret" ][ ret_type == "cons_elas", ret_type_alt := "cons" ]

p1_rs_plot <-
  dt_rs_plot %>% filter( ret_type_alt == "ret" ) %>%
  ggplot(aes(alpha_rs, ret, colour = ret_type)) + geom_point(shape = 1) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Degree of Risk Sharing") + theme( axis.title.x  = element_text(size = 7) ) +
  ylab("") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(0.0, +0.06)) + scale_x_continuous(limits = c(0., 1)) +
  theme( legend.position=c(0.4, 0.25), legend.text=element_text(size=8), legend.title=element_text(size=9) ) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = c(wes_pal_col, "black"), labels= c("High Trade Exposure",
                                                                 "Low Trade Exposure", "Risk-Free Rate"),
                     guide_legend(title = "Returns",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) )

p2_rs_plot <-
  dt_rs_plot %>% filter( ret_type_alt == "cons" ) %>%
  ggplot(aes(alpha_rs, ret )) + geom_point(colour = "black") +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Degree of Risk Sharing") + theme( axis.title.x  = element_text(size = 7) ) +
  ylab("") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(limits = c(-0.3, +0.05)) + scale_x_continuous(limits = c(0., 1)) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)


## p_rs_plot <- grid.arrange(p1_rs_plot, p2_rs_plot, nrow = 1)
## p_arrange_rs_plot <- ggarrange(p1_rs_plot, p2_rs_plot, labels = c("3a", "3b"))
## ggexport(p_arrange_rs_plot, filename = "./output/figure3.pdf")
## embed_fonts("./output/figure3.pdf")

# --- save plots
ggsave("./output/figure3a.pdf", p1_rs_plot, width = 3.3, height = 3)
embed_fonts("./output/figure3a.pdf")
ggsave("./output/figure3b.pdf", p2_rs_plot, width = 3.3, height = 3)
embed_fonts("./output/figure3b.pdf")
## ggsave("./output/figure3.pdf", p_rs_plot, width = 7, height = 3)
