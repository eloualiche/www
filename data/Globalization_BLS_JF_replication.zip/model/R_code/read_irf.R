#! /usr/bin/R
#
# GML2_plots.R
#
# (c) Barrot, Loualiche & Sauvagnat
#
# Analyze model solved in julia + dynare -- > plots
#
#
# Created on     August  2nd  2016
# Last modified  May          2018
#
#
########################################


# load relevant libraries
library(R.matlab);
library(dplyr); library(tidyr)
library(data.table)
library(statar)
library(here)

# --------------------------------------------------------------------------------
setwd(here::here()); getwd()

# ------------------------------------------------------------------------------
source("./R_code/read_dynare.R")



# ------------------------------------------------------------------------------
# ----- LOAD DYNARE results from simulation with NO RISK SHARING (benchmark)
res_dynare <- read_dynare("./dynare_code/GML2_nors/GML2_results.mat")
## res_dynare <- read_dynare("/Users/loulou/Desktop/misc/globalization/trade-model/dynare_code/GML2_dynare/GML2_dynare_results.mat")

param    <- res_dynare[[1]]
dt_simul <- res_dynare[[2]]
dt_simul_irf <- res_dynare[[3]]

# --------------------------------------------------------------------------------
# get IRF
dt_simul_irf[, t_period := seq(1, .N) ]
dt_simul_irf <- dt_simul_irf %>% filter(t_period < 100) %>%
    gather(irf_var, irf_value, -t_period) %>% data.table
dt_simul_irf[]

dt_simul_irf[ grep("epsastar", irf_var),  `:=`(shock = "astar", irf_var = gsub(".epsastar", "", irf_var)) ]
dt_simul_irf[ is.na(shock), `:=`(shock = "a", irf_var = gsub(".epsa", "", irf_var)) ]
dt_simul_irf[ grep("1", irf_var), sector := as.factor(1) ]
dt_simul_irf[ grep("2", irf_var), sector := as.factor(2) ]
dt_simul_irf[, irf_var_alt := gsub("1", "", irf_var) ][, irf_var_alt := gsub("2", "", irf_var_alt) ] # just alternative name, harmonized across sectors
## dt_simul_irf[ t_period == 1]

# --- save IRF for later use
saveRDS(dt_simul_irf, "./output/irf_nors.rds")
# --------------------------------------------------------------------------------



# ------------------------------------------------------------------------------
# ----- LOAD DYNARE results from simulation with FULL RISK SHARING
res_dynare <- read_dynare("./dynare_code/GML2_fullrs/GML2_results.mat")
## res_dynare <- read_dynare("/Users/loulou/Desktop/misc/globalization/trade-model/dynare_code/GML2_dynare/GML2_dynare_results.mat")

param    <- res_dynare[[1]]
dt_simul <- res_dynare[[2]]
dt_simul_irf <- res_dynare[[3]]

# --------------------------------------------------------------------------------
# get IRF
dt_simul_irf[, t_period := seq(1, .N) ]
dt_simul_irf <- dt_simul_irf %>% filter(t_period < 100) %>%
    gather(irf_var, irf_value, -t_period) %>% data.table
dt_simul_irf[]

dt_simul_irf[ grep("epsastar", irf_var),  `:=`(shock = "astar", irf_var = gsub(".epsastar", "", irf_var)) ]
dt_simul_irf[ is.na(shock), `:=`(shock = "a", irf_var = gsub(".epsa", "", irf_var)) ]
dt_simul_irf[ grep("1", irf_var), sector := as.factor(1) ]
dt_simul_irf[ grep("2", irf_var), sector := as.factor(2) ]
dt_simul_irf[, irf_var_alt := gsub("1", "", irf_var) ][, irf_var_alt := gsub("2", "", irf_var_alt) ] # just alternative name, harmonized across sectors
dt_simul_irf[ t_period == 1]

# --- save IRF for later use
saveRDS(dt_simul_irf, "./output/irf_fullrs.rds")
# --------------------------------------------------------------------------------





# ------------------------------------------------------------------------------
# ----- LOAD DYNARE results from simulation with various levels of  RISK SHARING
res_dynare <- read_dynare("./dynare_code/GML2_some_rs/GML2_results.mat")
## res_dynare <- read_dynare("/Users/loulou/Desktop/misc/globalization/trade-model/dynare_code/GML2_dynare/GML2_dynare_results.mat")

param    <- res_dynare[[1]]
dt_simul <- res_dynare[[2]]

dt_simul[, alp_rs := param$alpha_rs ]
dt_simul <- dt_simul[, .(alpha_rs = param$alpha_rs, rf, cons, log_cons,
                         ret1D_ex = ret1D - rf, ret2D_ex = ret2D - rf,
                         Ashock, Astarshock, epsa, epsastar) ]

# --- save IRF for later use
message("# Saving for risk sharing parameter alpha = ", param$alpha_rs)
saveRDS(dt_simul, paste0("./output/simul_rs_", 100*param$alpha_rs, ".rds"))

# --------------------------------------------------------------------------------



# ------------------------------------------------------------------------------
# ----- LOAD DYNARE results WITH BONDS
res_dynare <- read_dynare("./dynare_code/GML2_bonds/GML2b_results.mat")

param    <- res_dynare[[1]]
dt_simul <- res_dynare[[2]]
dt_simul_irf <- res_dynare[[3]]

# --------------------------------------------------------------------------------
# get IRF
dt_simul_irf[, t_period := seq(1, .N) ]
dt_simul_irf <- dt_simul_irf %>% filter(t_period < 100) %>%
    gather(irf_var, irf_value, -t_period) %>% data.table
dt_simul_irf[]

dt_simul_irf[ grep("epsastar", irf_var),  `:=`(shock = "astar", irf_var = gsub(".epsastar", "", irf_var)) ]
dt_simul_irf[ is.na(shock), `:=`(shock = "a", irf_var = gsub(".epsa", "", irf_var)) ]
dt_simul_irf[ grep("1", irf_var), sector := as.factor(1) ]
dt_simul_irf[ grep("2", irf_var), sector := as.factor(2) ]
dt_simul_irf[, irf_var_alt := gsub("1", "", irf_var) ][, irf_var_alt := gsub("2", "", irf_var_alt) ] # just alternative name, harmonized across sectors
dt_simul_irf[ t_period == 1]

# --- save IRF for later use
saveRDS(dt_simul_irf, "./output/irf_bonds.rds")
# --------------------------------------------------------------------------------
