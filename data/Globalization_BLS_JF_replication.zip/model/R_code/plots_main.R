#! /usr/bin/R
#
# main_plots.R
#
# (c) Barrot, Loualiche & Sauvagnat
#
# Analyze model solved in julia + dynare -- > plots
#
#
# Created on     August    2nd  2016
# Last modified  June           2018
#
#
########################################

library(tikzDevice);
library(ggplot2);
library(ggthemes);
library(wesanderson);
library(scales);
library(latex2exp)
library(extrafont);
library(fontcm)

library(dplyr); library(tidyr)
library(data.table)
library(statar)
library(here)


# --------------------------------------------------------------------------------
# load the fonts: you must have New Century Schoolbook installed
font_import(pattern="NewCenturySchoolbook", prompt = F)

# --------------------------------------------------------------------------------
setwd(here::here()); getwd()


# ------------------------------------------------------------------------------
## latex_percent <- function (x) {
##     x <- plyr::round_any(x, scales:::precision(x)/100)
##     stringr::str_c(comma(x * 100), "\\%")
## }
latex_percent <- function (x) {
    x <- plyr::round_any(x, scales:::precision(x)/100)
    stringr::str_c(comma(x * 100), "%")
}
wes_pal_col <- wes_palette("Zissou1")[c(5,1)]
# ------------------------------------------------------------------------------


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# --- PLOTS

# ------------------------------------------------------------------
# --- FIGURE 1: Respone to Astar of:
# --- -- 1a: Domestic Consumption; -- 1b: Asset prices; -- 1c: Returns

# --- read the no risk sharing IRF:
dt_simul_irf <- readRDS("./output/irf_nors.rds")
## dt_simul_irf %>% tab(irf_var_alt)

mf_labeller_1a <- as_labeller(c(`cons`  = "Domestic Consumption",
                                `log.cons` = "Domestic Consumption",
                                `valueD` = "Asset Prices",
                                `retD`   = "Returns"))

dt_plot <- dt_simul_irf[ shock == "astar" ][
  irf_var_alt %in% c("cons", "valueD", "retD") ][
    is.na(sector), sector := "agg" ]
dt_plot[, irf_var_alt := factor(irf_var_alt, levels = c("cons", "valueD", "retD")) ]
## dt_plot[]

p1_no_rs <- dt_plot  %>%
  ggplot(aes(t_period, irf_value, colour = sector, linetype = sector)) +
  geom_line() +
  facet_grid( . ~ irf_var_alt, scales = "free_x", labeller=mf_labeller_1a) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") + theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.03, +0.005)) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)  +
  theme(legend.position=c(0.15, 0.25), legend.text=element_text(size=6), legend.title=element_text(size=7),
        text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = c(wes_pal_col, "black"),
                     labels= c("High Trade Exposure", "Low Trade Exposure", "Aggregate"),
                     guide_legend(title = "Industries",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) ) +
  scale_linetype_manual(values = c("dotdash", "solid", "solid"),
                        labels= c("High Trade Exposure", "Low Trade Exposure", "Aggregate"),
                        guide_legend(title = "Industries",
                                     title.theme = element_text(size = 5),
                                     title.hjust = -5,
                                     keywidth = unit(1.5, "cm") ) )

ggsave("./output/figure1a.pdf", p1_no_rs, width = 7, height = 3)
embed_fonts("./output/figure1a.pdf")
# ------------------------------------------------------------------


# ------------------------------------------------------------------
# --- FIGURE 1b: with full risk sharing (for comparison)
dt_simul_irf <- readRDS("./output/irf_fullrs.rds") # --- read the full risk sharing IRF:

dt_plot <- dt_simul_irf[ shock == "astar" ][
  irf_var_alt %in% c("cons", "valueD", "retD") ][
  is.na(sector), sector := "agg" ]
dt_plot[, irf_var_alt := factor(irf_var_alt, levels = c("cons", "valueD", "retD")) ]
dt_plot[ t_period == 1 ]

p1_rs <-
  dt_plot  %>%
  ggplot(aes(t_period, irf_value, colour = sector, linetype = sector)) +
  geom_line() +
  facet_grid( . ~ irf_var_alt, scales = "free_x", labeller=mf_labeller_1a) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") + theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.03, +0.005)) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)  +
  theme( legend.position=c(0.15, 0.25), legend.text=element_text(size=6), legend.title=element_text(size=7),
        text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = c(wes_pal_col, "black"), labels= c("High Trade Exposure", "Low Trade Exposure", "Aggregate"),
                     guide_legend(title = "Industries",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) ) +
  scale_linetype_manual(values = c("dotdash", "solid", "solid"),
                        labels= c("High Trade Exposure", "Low Trade Exposure", "Aggregate"),
                        guide_legend(title = "Industries",
                                     title.theme = element_text(size = 5),
                                     title.hjust = -5,
                                     keywidth = unit(1.5, "cm") ) )
## p1_rs
## tikz("~/Dropbox/TRADE/paper_common/drawing/irf_astar_valuation_rs.tex", width = 7, height = 3.)
## p5_rs
## dev.off()
ggsave("./output/figure1b.pdf", p1_rs, width = 7, height = 3)
embed_fonts("./output/figure1b.pdf")
# ------------------------------------------------------------------




# ------------------------------------------------------------------
# --- FIGURE 2: Response to Astar
# --- -- 2a: Astar; -- 2b: Dom. Consumption;  2c: Foreign Consumption
# --- -- 2d: Import Pen.; -- 2e: Exporter Fraction; -- 2f: Dom. profits

dt_simul_irf <- readRDS("./output/irf_nors.rds") # --- read the no risk sharing IRF:

dt_plot <- dt_simul_irf[ shock == "astar" ] %>%
    filter( irf_var_alt %in% c("Astarshock", "cons", "consstar") ) %>% data.table
dt_plot$irf_var2 <- factor(dt_plot$irf_var,
                           labels = c(TeX("$A^{*}$"), TeX("Domestic Consumption"), TeX("Foreign Consumption") ) )
dt_plot[ t_period %in% c(1, 99) ]

p2a_no_rs <-
  dt_plot %>%
  ggplot(aes(t_period, irf_value)) + geom_line() +
  facet_grid(  ~ irf_var2, scales = "free", labeller= label_parsed) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") +  theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.025, 0.1)) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)

## p2a_no_rs
ggsave("./output/figure2a.pdf", p2a_no_rs, width = 7, height = 3)
embed_fonts("./output/figure2a.pdf")


# ---
# Imports and stuff
mf_labeller_2b <- as_labeller(c(`import.pen`   = "Import Penetration",
                               `zetastar`     = "Fraction of Exporters",
                               `log.profitD`  = "Domestic Profits"))

dt_plot <- dt_simul_irf[ shock == "astar" ] %>%
  filter( irf_var_alt %in% c("import.pen", "zetastar", "log.profitD") )

p2b_no_rs <-
  dt_plot %>%
  mutate( irf_var_alt = factor(irf_var_alt, levels = c("import.pen", "zetastar", "log.profitD")) ) %>%
  ggplot(aes(t_period, irf_value, colour = sector, linetype = sector)) +
  geom_line() +
  facet_grid( . ~ irf_var_alt, scales = "free_x", labeller=mf_labeller_2b) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") + theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.075, +0.165)) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)  +
  theme( legend.position=c(0.15, 0.8), legend.text=element_text(size=8), legend.title=element_text(size=9),
        text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = wes_pal_col, labels=c("High Trade Exposure", "Low Trade Exposure"),
                     guide_legend(title = "Industries",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) ) +
  scale_linetype_manual(values = c("dotdash", "solid"),
                        labels= c("High Trade Exposure", "Low Trade Exposure"),
                        guide_legend(title = "Industries",
                                     title.theme = element_text(size = 5),
                                     title.hjust = -5,
                                     keywidth = unit(1.5, "cm") ) )
## p2b_no_rs

ggsave("./output/figure2b.pdf", p2b_no_rs, width = 7, height = 3)
embed_fonts("./output/figure2b.pdf")
