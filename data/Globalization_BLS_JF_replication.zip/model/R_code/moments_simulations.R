#! /usr/bin/R
#
# moments_simulation.R
#
# (cc) Barrot, Loualiche & Sauvagnat
#
# Analyze model solved in julia + dynare
#
# Created on     July   25th 2016
# Last modified  June  2018
#
########################################


# ------------------------------------------------------------------------------
# --- libraries
library(devtools)
library(foreign); library(R.matlab); library(stargazer);
library(dplyr); library(tidyr); library(stringr);
library(data.table)
library(statar)

# ------------------------------------------------------------------------------
setwd(here::here()); getwd()


# -----------------------------------------------------------------------------
# ----- LOAD DYNARE results from simulation
source("./R_code/read_dynare.R")

res_dynare <- read_dynare("./dynare_code/GML2_some_rs/GML2_results.mat")
param      <- res_dynare[[1]]
dt_simul   <- res_dynare[[2]]

saveRDS(dt_simul, "./output/simul_nors_1mn.rds")
## dt_simul <- readRDS("./output/simul_nors_1mn.rds")


# ------------------------------------------------------------------------------------
# --- IMPORT PENETRATION BY SECTORS
dt_simul[, .(import_pen1, import_pen2) ]
dt_simul  %>% skimr::skim(import_pen1, import_pen2)

# basic statistics:
dt_simul[, .(avg_import_pen1 = mean(import_pen1), avg_import_pen2 = mean(import_pen2),
             sd_import_pen1  = sd(import_pen1),   sd_import_pen1  = sd(import_pen2)) ]

# elasticities
r_imp1_astar = lm( import_pen1 ~ Astarshock, dt_simul)
r_imp2_astar = lm( import_pen2 ~ Astarshock, dt_simul)
r_imp1_a     = lm( import_pen1 ~ Ashock, dt_simul)
r_imp2_a     = lm( import_pen2 ~ Ashock, dt_simul)
stargazer(r_imp1_astar, r_imp2_astar, r_imp1_a, r_imp2_a,
          type="text")


# -------------------------------------------------------------------------------------
# --- DOMESTIC PROFITS BY SECTORS
# elasticities
r_profit1D_astar        = lm( log(profit1D) ~ Astarshock, dt_simul)
r_profit2D_astar        = lm( log(profit2D) ~ Astarshock, dt_simul)
r_profit1D_a            = lm( log(profit1D) ~ Ashock, dt_simul)
r_profit2D_a            = lm( log(profit2D) ~ Ashock, dt_simul)
stargazer(r_profit1D_astar, r_profit2D_astar, r_profit1D_a, r_profit2D_a,
          type="text")


# --------------------------------------------------------------------------------------------------
# --- AVERAGE EXPORTERS
dt_simul[, .(avg_zeta1 = mean(zeta1), avg_zeta2 = mean(zeta2)) ]


# --------------------------------------------------------------------------------------------------
# --- AGGREGATE QUANTITIES

# a. consumption
dt_simul[, .(sd_cons = sd(cons)) ]
# elasticities
r_cons_astar = lm( cons ~ Astarshock, dt_simul)
r_cons_a     = lm( cons ~ Ashock, dt_simul)
stargazer(r_cons_astar, r_cons_a,
          type = "text")

# b. risk-free rate:
dt_simul[, .(avg_rf = 400*mean(rf), sd_rf = 400*sd(rf)) ]
# elasticities
r_rf_astar = lm( rf ~ Astarshock, dt_simul[, .(rf = 400*rf, Astarshock) ])
r_rf_a     = lm( rf ~ Ashock,     dt_simul[, .(rf = 400*rf, Ashock) ])
stargazer(r_rf_astar, r_rf_a, type = "text")


# --------------------------------------------------------------------------------------------------
# --- RETURNS

# a. domestic firms
# basic statistics:
dt_simul[, lapply(.SD, function(x) 400*mean(x-rf)), .SDcols = c("ret1D", "ret2D") ]
dt_simul[, lapply(.SD, function(x) 400*sd(x-rf)),   .SDcols = c("ret1D", "ret2D") ]

r_ret1D_astar = lm( ret1D_ex ~ epsastar, dt_simul[, .(ret1D_ex = 4*(ret1D-rf), epsastar) ])
r_ret2D_astar = lm( ret2D_ex ~ epsastar, dt_simul[, .(ret2D_ex = 4*(ret2D-rf), epsastar) ])
r_ret1D_a     = lm( ret1D_ex ~ epsa, dt_simul[, .(ret1D_ex = 4*(ret1D-rf), epsa) ])
r_ret2D_a     = lm( ret2D_ex ~ epsa, dt_simul[, .(ret2D_ex = 4*(ret2D-rf), epsa) ])

stargazer(r_ret1D_astar, r_ret2D_astar, r_ret1D_a, r_ret2D_a, type = "text")


# b. avg. exporters
dt_simul[, `:=`(ret1_avgexp = (value1D_avgexp * ret1D + value1X_avgexp * ret1X) / (value1D_avgexp + value1X_avgexp),
                ret2_avgexp = (value2D_avgexp * ret2D + value2X_avgexp * ret2X) / (value2D_avgexp + value2X_avgexp) ) ]
## dt_simul[, `:=`(ret1_avgexp_ex = ret1_avgexp - rf, ret2_avgexp_ex = ret2_avgexp - rf) ]

dt_simul[, lapply(.SD, function(x) 400*mean(x-rf)), .SDcols = c("ret1_avgexp", "ret2_avgexp") ]
dt_simul[, lapply(.SD, function(x) 400*sd(x-rf)),   .SDcols = c("ret1_avgexp", "ret2_avgexp") ]

r_ret1_avgexp_astar = lm( ret1_avgexp_ex ~ epsastar, dt_simul[, .(ret1_avgexp_ex = 4*(ret1_avgexp - rf), epsastar) ])
r_ret2_avgexp_astar = lm( ret2_avgexp_ex ~ epsastar, dt_simul[, .(ret2_avgexp_ex = 4*(ret2_avgexp - rf), epsastar) ])
r_ret1_avgexp_a     = lm( ret1_avgexp_ex ~ epsa, dt_simul[, .(ret1_avgexp_ex = 4*(ret1_avgexp - rf), epsa) ])
r_ret2_avgexp_a     = lm( ret2_avgexp_ex ~ epsa, dt_simul[, .(ret2_avgexp_ex = 4*(ret2_avgexp - rf), epsa) ])

stargazer(r_ret1_avgexp_astar, r_ret2_avgexp_astar, r_ret1_avgexp_a, r_ret2_avgexp_a, type = "text")
