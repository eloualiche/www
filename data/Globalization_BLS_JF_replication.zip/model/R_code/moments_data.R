#! /usr/bin/R
#
# moments_data.R
#
# (cc) Barrot, Loualiche & Sauvagnat
#
# Analyze model solved in julia + dynare
#
# Created on     July   25th 2016
# Last modified  June  2018
#
########################################


library(devtools)
library(haven);
library(readxl);
library(skimr);
library(lubridate);
library(here)
library(stargazer);
library(stringr);
library(tidyr);
library(dplyr)
library(data.table)
library(statar)
library(RcppRoll)

# --------------------------------------------------------------------------------
setwd(here::here()); getwd()


# --------------------------------------------------------------------------------
# ----- Ratio of GDP per Capita (from World Bank Developments Indicators)
# downloaded from worldbank: http://data.worldbank.org/indicator/NY.GDP.MKTP.CD
dt_wbgdp <- readRDS("./R_data/worldbank_gdp.rds") %>% data.table
setnames(dt_wbgdp, sapply(names(dt_wbgdp), function(x) gsub(" ", "", x)) )
dt_wbgdp <- t(dt_wbgdp[ CountryCode %in% c("USA", "CHN") ])
dt_wbgdp <- cbind(date_y = row.names(dt_wbgdp), dt_wbgdp) %>% data.table
dt_wbgdp <- dt_wbgdp[, lapply(.SD, as.numeric) ][ !is.na(date_y) ]
dt_wbgdp <- dt_wbgdp[, .(date_y, gdp_chn = V2, gdp_usa = V3, log_gdp_chn = log(V2), log_gdp_usa = log(V3)) ]

dt_ageratio <- readRDS("./R_data/worldbank_age_ratio.rds") %>% data.table
dt_pop      <- readRDS("./R_data/worldbank_pop.rds") %>% data.table
setnames(dt_ageratio, sapply(names(dt_ageratio), function(x) gsub(" ", "", x)) )
dt_ageratio <- t(dt_ageratio[ CountryCode %in% c("USA", "CHN") ])
dt_ageratio <- cbind(date_y = row.names(dt_ageratio), dt_ageratio) %>% data.table
dt_ageratio <- dt_ageratio[, lapply(.SD, as.numeric) ][ !is.na(date_y) ]
setnames(dt_pop, sapply(names(dt_pop), function(x) gsub(" ", "", x)) )
dt_pop <- t(dt_pop[ CountryCode %in% c("USA", "CHN") ])
dt_pop <- cbind(date_y = row.names(dt_pop), dt_pop) %>% data.table
dt_pop <- dt_pop[, lapply(.SD, as.numeric) ][ !is.na(date_y) ]

dt_pop <- cbind(dt_pop[, .(date_y, pop_chn = V2, pop_usa = V3) ],
                dt_ageratio[, .(ageratio_chn = V2, ageratio_usa = V3) ] )
dt_pop[, `:=`(working_pop_chn = pop_chn * ageratio_chn, working_pop_usa = pop_usa * ageratio_usa) ]
dt_pop[ date_y >= 1974, .(chn = mean(working_pop_chn), usa = mean(working_pop_usa),
                          ratio = mean(working_pop_usa) / mean(working_pop_chn) ) ]
dt_gdp <- cbind(dt_wbgdp, dt_pop) %>% data.table
dt_gdp[, `:=`(gdp_cap_usa = gdp_usa / pop_usa, gdp_cap_chn = gdp_chn / pop_chn) ]

# --- average results
year_ref = 2015
dt_pop[ date_y == year_ref, .(ratio_working_pop = mean(working_pop_usa) / mean(working_pop_chn) ) ]
##    ratio_working_pop
## 1:          0.326246

dt_gdp[ date_y == year_ref, .(ratio_gdp_cap = mean(gdp_cap_usa) / mean(gdp_cap_chn)) ]
##    ratio_gdp_cap
## 1:       7.04596



# --------------------------------------------------------------------------------
# ----- GDP (from FRED)
dt_gdp <- readRDS("./R_data/gdp.rds") %>% data.table
dt_gdp <- dt_gdp[ year(dateq) >= 1974 ]
dt_gdp[, log_gdp := log(GDP) ]
r1 = lm(log_gdp ~ lag(log_gdp, 4), dt_gdp)
coefficients(r1)[2]
## lag(log_gdp, 4)
##       0.9689045


# --------------------------------------------------------------------------------
# ----- CONSUMPTION: (from FRED NIPA PCE)
dt_cons <- readRDS("./R_data/cons.rds")
dt_cons[, cons_g := log(cons / lag(cons, 4)) ]
dt_cons <- dt_cons[ year(date) >= 1974 ]
dt_cons[, .(sd_cons = 100*sd(dt_cons$cons_g)) ]
##     sd_cons
## 1: 2.715668

# --------------------------------------------------------------------------------
# ----- Risk-free rate: (from FRED NIPA PCE)
dt_rf <- readRDS("./R_data/rf.rds")
dt_rf <- dt_rf[ year(date) >= 1973 ]
dt_rf[, rf_log := log(1+rf/100) ]
dt_rf[, rf_q := exp(roll_sum(rf_log, 3, align = "right", fill = NA)) - 1 ]
dt_rf <- dt_rf[ year(date) >= 1974 ]
dt_rf[, .(avg_rf = 400*mean(rf_q), sd_rf = 400*sd(rf_q)) ]
##      avg_rf    sd_rf
## 1: 4.782325 3.452601


# --------------------------------------------------------------------------------
# ----- IMPORT PENETRATION (from Robert Feenstra's website)
dt_pen <- readRDS("./R_data/feenstra_import_sic4.rds")
setorder(dt_pen, sic, year)
dt_pen[, d_penetration := penetration - tlag(penetration, time=year), by = .(sic) ]
dt_pen[, `:=`(avg_pen = mean(penetration, na.rm=T),
              sd_pen   = sd(penetration, na.rm=T),
              sd_d_pen = sd(d_penetration, na.rm=T) ),
       by = .(sic) ]

dt_stat <- dt_pen[, .(sd_pen, sd_d_pen, avg_pen, sic) ] %>% unique
dt_stat[, q_pen := xtile( avg_pen, 2) ]
dt_stat <- dt_stat[ !is.na(q_pen) ]
setorder(dt_stat, q_pen)
dt_stat[, lapply(.SD, function(x) mean(x, na.rm =T)), .SDcols = c("avg_pen", "sd_pen"), by = .(q_pen) ]
##    q_pen    avg_pen     sd_pen
## 1:     1 0.04874216 0.02917724
## 2:     2 0.27207173 0.12619549


# --------------------------------------------------------------------------------
# ----- CENSUS IMPORTS
# this procedure requires that you have installed the X13 binaries on your computer
# make sure to specify the path where the binaries are installed
library(seasonal); library(seasonalview)
Sys.setenv(X13_PATH = "/path/to/x13ashtmlsrc_V1.1_B39") # load x13 binaries

dt_trade_census <- readRDS("./R_data/trade_census.rds") %>% data.table
dt_trade_CHN    <-  dt_trade_census[ CTYNAME == "China" ]
dt_trade_CHN    <- dt_trade_CHN %>% gather(month, import, IJAN:IDEC) %>% data.table
dt_trade_CHN    <- dt_trade_CHN[, .(year, import_year = IYR, import, month = substr(month,2,4)) ]
dt_trade_CHN[, date  := as.Date(paste0("01", "-", month, "-", year), "%d-%b-%Y")  ]
dt_trade_CHN[, datem := as.monthly(date) ]
dt_trade_CHN <- dt_trade_CHN[ import > 0 ]
dt_trade_CHN[, log_import := log(import) ]
setorder(dt_trade_CHN, datem)

# remove strong seasonality
dt_tmp <- dt_trade_CHN[, .(date, date_y=year, month=month(datem), log_import, import) ]
dt_tmp[]
year_start = dt_tmp[1]$date_y[1]; month_start = dt_tmp[1]$month[1]
year_end   = dt_tmp[.N]$date_y[1]; month_end  = dt_tmp[.N]$month[1]
t2 <- ts(dt_tmp$log_import,
         start=c(year_start, month_start), end=c(year_end, month_end), frequency=12)
t2_x13 = seas(t2)

dt_sa <-
  data.table(date = dt_tmp$date, datem = dt_tmp$date,
             log_import = dt_tmp$log_import,
             log_import_sa = data.table(final(t2_x13)) %>% as.vector)
setnames(dt_sa, c("date", "datem", "log_import", "log_import_sa"))
setorder(dt_sa, datem)
dt_sa[, l4_log_import_sa  := lag(as.numeric(log_import_sa), 4) ]
## saveRDS(dt_sa, "./R_data/trade_census_sa.rds")

dt_sa <- readRDS("./R_data/trade_census_sa.rds")
r1 <- lm(log_import_sa ~ l4_log_import_sa, dt_sa)
stargazer(r1, type="text")
dt_sa[, .(sd_import_shock =  sd(log_import_sa - 0.98*l4_log_import_sa, na.rm=T)) ]
## sd_import_shock 1: 0.07465742
