#! /usr/bin/R
#
# plots_appendix.R
#
# (c) Barrot, Loualiche & Sauvagnat
#
# Analyze model solved in julia + dynare -- > plots
#
#
# Created on     August    2016
# Last modified  June      2018
#
#
########################################


# load relevant libraries
library(tikzDevice);
library(ggplot2);
library(ggthemes);
library(wesanderson);
library(scales);
library(latex2exp)
library(extrafont);
library(fontcm)
library(dplyr); library(tidyr)
library(data.table)
library(statar)
library(here)


# --------------------------------------------------------------------------------
setwd(here::here()); getwd()

# load the fonts: you must have New Century Schoolbook installed
font_import(pattern="NewCenturySchoolbook", prompt = F)


# ------------------------------------------------------------------------------
## latex_percent <- function (x) {
##     x <- plyr::round_any(x, scales:::precision(x)/100)
##     stringr::str_c(comma(x * 100), "\\%")
## }
latex_percent <- function (x) {
    x <- plyr::round_any(x, scales:::precision(x)/100)
    stringr::str_c(comma(x * 100), "%")
}
wes_pal_col <- wes_palette("Zissou1")[c(5,1)]
# ------------------------------------------------------------------------------



# --------------------------------------------------------------------------------
# ------------------------------------------------------------------
# --- FIGURE A.1: -- A1a: Astar; -- A1b: Dom. Consumption; A1c: Foreign Consumption
#                 -- A1d: Import Pen.; -- A1e: Exporter Fraction; -- A1f: Dom. profits

dt_simul_irf <- readRDS("./output/irf_nors.rds")

dt_plot <- dt_simul_irf[ shock == "a" ] %>%
  filter( irf_var_alt %in% c("Ashock", "cons", "consstar") )
dt_plot$irf_var2 <- factor(dt_plot$irf_var,
                           labels = c(TeX("$A$"), TeX("Domestic Consumption"), TeX("Foreign Consumption") ) )

pA1a_no_rs <-
  dt_plot %>%
  ggplot(aes(t_period, irf_value)) + geom_line() +
  facet_grid(  ~ irf_var2, scales = "free", labeller = label_parsed) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") +  theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.0, +0.016)) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)

ggsave("./output/figureA1a.pdf", pA1a_no_rs, width = 7, height = 3)
embed_fonts("./output/figureA1a.pdf")


# ---
# Imports and stuff
mf_labeller_a2 <- as_labeller(c(`import.pen`  = "Import Penetration",
                                `zetastar`     = "Fraction of Exporters",
                                `log.profitD`  = "Domestic Profits"))

pA1b_no_rs <-
dt_simul_irf[ shock == "a" ] %>%
  filter( irf_var_alt %in% c("import.pen", "zetastar", "log.profitD") ) %>%
  mutate( irf_var_alt = factor(irf_var_alt, levels = c("import.pen", "zetastar", "log.profitD")) ) %>%
  ggplot(aes(t_period, irf_value, colour = sector, linetype = sector)) +
  geom_line() +
  facet_grid( . ~ irf_var_alt, scales = "free_x", labeller=mf_labeller_2b) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") + theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.004, +0.004)) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5)  +
  theme( legend.position=c(0.15, 0.8), legend.text=element_text(size=8), legend.title=element_text(size=9) ) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = wes_pal_col, labels=c("High Trade Exposure", "Low Trade Exposure"),
                     guide_legend(title = "Industries",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) ) +
  scale_linetype_manual(values = c("dotdash", "solid"),
                        labels= c("High Trade Exposure", "Low Trade Exposure"),
                        guide_legend(title = "Industries",
                                     title.theme = element_text(size = 5),
                                     title.hjust = -5,
                                     keywidth = unit(1.5, "cm") ) )

ggsave("./output/figureA1b.pdf", pA1b_no_rs, width = 7, height = 3)
embed_fonts("./output/figureA1b.pdf")



# --------------------------------------------------------------------------------
# ------------------------------------------------------------------
# --- FIGURE A.2: EXCHANGE RATES

# --- read the no risk sharing IRF:
dt_simul_irf <- readRDS("./output/irf_nors.rds")

mf_labeller_a2 <- as_labeller(c(`forex.tradable` = "Exchange rate (tradables)",
                                `forex.agg`      = "Real exchange rate"))

dt_plot <- dt_simul_irf %>%
    filter( irf_var_alt %in% c("forex.agg", "forex.tradable") ) %>% data.table

dt_plot[ t_period %in% c(1, 99) ]

pA2 <- dt_plot %>%
  ggplot(aes(t_period, irf_value, colour = shock)) + geom_line() +
  facet_grid(  ~ irf_var, scales = "free", labeller=mf_labeller_a2) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") +  theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.02, +0.001)) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5) +
  theme( legend.position=c(0.2, 0.2), legend.text=element_text(size=8), legend.title=element_text(size=9) ) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = c(wes_pal_col), labels= c("Domestic shock $A$", "Foreign Shock $A^{\\star}$"),
                     guide_legend(title = "Productivity shocks",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) )

ggsave("./output/figureA2.pdf", pA2, width = 7, height = 3)
embed_fonts("./output/figureA2.pdf")



# --------------------------------------------------------------------------------
# ------------------------------------------------------------------
# --- FIGURE A.3: EQUILIBRIUM BOND TRADING
dt_simul_irf <- readRDS("./output/irf_bonds.rds")

# ----- response to astar
dt_plot <- dt_simul_irf %>% #[ shock == "astar" ] %>%
    filter( irf_var_alt %in% c("BD", "BDstar", "BX", "BXstar") ) %>% data.table
## dt_plot[, irf_value := irf_value / 100 ]

dt_plot$irf_var2 <- factor(dt_plot$irf_var_alt,
                           labels = c(TeX("$B_D$"), TeX("$B_D^{*}$"), TeX("$B_X$"), TeX("$B_X^{*}$")) )
dt_plot[t_period == 1]

pA3a <-
  dt_plot  %>%
  ggplot(aes(t_period, irf_value, colour = shock, linetype = shock)) + geom_line() +
  facet_grid( . ~ irf_var2, scales = "free", labeller= label_parsed) +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") +  theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.11, +0.11)) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5) +
  theme( legend.position=c(0.125, 0.2), legend.text=element_text(size=8), legend.title=element_text(size=9) ) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = c(wes_pal_col), labels= c("Domestic shock", "Foreign shock"),
                     guide_legend(title = "Productivity shocks",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) ) +
  scale_linetype_manual(values = c("solid", "dotdash"),
                        labels= c("Domestic shock", "Foreign shock"),
                        guide_legend(title = "Productivity shocks",
                                     title.theme = element_text(size = 5),
                                     title.hjust = -5,
                                     keywidth = unit(1.5, "cm") ) )


## pA3a
ggsave("./output/figureA3a.pdf", pA3a, width = 7, height = 3)
embed_fonts("./output/figureA3a.pdf")


## -----
dt_plot <-  dt_simul_irf %>% # [ shock == "astar" ] %>%
    filter( irf_var_alt %in% c("curracct", "curracctstar") ) %>% data.table
dt_plot$irf_var2 <- factor(dt_plot$irf_var_alt,
                           labels = c("Domestic Balance", "Foreign Balance") )
dt_plot[t_period == 1]

pA3b <-
  dt_plot %>% # [ shock == "astar" ] %>%
  ggplot(aes(t_period, irf_value, colour = shock, linetype = shock)) + geom_line() +
  facet_grid( . ~ irf_var2, scales = "free") +
  theme_bw() + theme(strip.background = element_blank()) +
  xlab("Horizon -- quarters") +  theme( axis.title.x  = element_text(size = 7) ) +
  ylab("Log deviation from steady state") + theme( axis.title.y  = element_text(angle=90, size = 7) ) +
  scale_y_continuous(labels=latex_percent, limits = c(-0.27, +0.27) ) +
  geom_hline(aes(yintercept=0), colour="red", linetype="dotted", size = 0.5) +
  theme( legend.position=c(0.15, 0.2), legend.text=element_text(size=8), legend.title=element_text(size=9) ) +
  theme(  text = element_text(family = "NewCenturySchoolbook") ) +
  scale_color_manual(values = c(wes_pal_col), labels= c("Domestic shock", "Foreign shock"),
                     guide_legend(title = "Productivity shocks",
                                  title.theme = element_text(size = 5),
                                  title.hjust = -5,
                                  keywidth = unit(1.5, "cm") ) ) +
  scale_linetype_manual(values = c("solid", "dotdash"),
                        labels= c("Domestic shock", "Foreign shock"),
                        guide_legend(title = "Productivity shocks",
                                     title.theme = element_text(size = 5),
                                     title.hjust = -5,
                                     keywidth = unit(1.5, "cm") ) )


ggsave("./output/figureA3b.pdf", pA3b, width = 7, height = 3)
embed_fonts("./output/figureA3b.pdf")
