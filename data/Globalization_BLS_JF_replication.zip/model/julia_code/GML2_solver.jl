#! /usr/bin/julia
#
# GML2_solver.jl
#
# Solve a Ghironi-Melitz type model with homogeneous good
# Number of firms is fixed (Chaney) and homogeneous goods helps to interpret productivity shocks
#
# created           July 22nd 2016
# last modified     June 11th 2018
#
# (c) Loualiche
#
#
#######################################################################################


module GML2_solver


######################################################################################
# ----- Which packages are necessary in this module
using GML2_constants: GML2_Parameters
using GML2_routines

using DataFrames
using BlackBoxOptim

######################################################################################
# ----- Functions to EXPORT
export solve_GML2_model



######################################################################################
# ----- overall  function
function solve_GML2_model(
    alpha_rs::Real,    # parameter for risk sharing
    sim::Integer,      # is the model written for simulation or impulse response,
    dyn::Integer,      # do we also simulate the model
    path_to::String;
    dyn_path = "/Applications/Dynare/4.5.3/matlab",
    matlab_bin  = "/Applications/MATLAB_R2017b.app/bin/matlab"
    )

#########################################################################################
# ----- PARAMETERS FOR THE MODEL

# --- notes
# we have a few constraints on coefficients: THETA < SIGMA and GAMMA > SIGMA-1
# ----- Ghironi and Melitz, Baseline specification is 3.8
SIGMA1    = 3.8 ;        # elasticity of substitution
SIGMA2    = 3.8 ;        # elasticity of substitution

THETA     = 1.2;

a0        = 0.1;        # elasticity with the other good
a0star    = 0.6;        # benchmark 0.5

# alpha_rs  = 0;         # degree of risk sharing (0 for no, 1 for all)

PHIM1     = 0.7;       # lower bound productivity
PHIM2     = 0.7
PHIM1star = 1.;        # lower bound productivity
PHIM2star = 1.;

GAMMA1   = 3.4; # 3.4;        # Pareto tail parameter (baseline 3.4)
GAMMA2   = 3.4; # 3.4;

ETA1     = 0.5;
ETA2     = 0.5;
ETA1star = 0.5;
ETA2star = 0.5;

# --- intertemporal
NU      = 20. ;         # risk aversion
NUstar  = 2.  ;
BETA    = 0.99;           # quarterly frequency
IES     = 1.5 ;           # IES


# --- trade costs
TAU1      = 1.;        # iceberg
TAU2      = 1.5;
TAU1star  = 1.;
TAU2star  = 1.5;

F1exp     = 5E0;
F2exp     = 5E0;
F1expstar = 3E-05;
F2expstar = 3E-05;


# --- size
M1         = 1.
M2         = 1.
M1star     = 30.
M2star     = 16.

L        = 1.
Lstar    = 3.

# --- derivative constants
markup1     = SIGMA1 / (SIGMA1 - 1);
markup2     = SIGMA2 / (SIGMA2 - 1);
nu1         = ( GAMMA1 / (GAMMA1 - (SIGMA1-1)) )^(1/(SIGMA1-1));
nu2         = ( GAMMA2 / (GAMMA2 - (SIGMA2-1)) )^(1/(SIGMA2-1));
phibar1     = nu1 * PHIM1;
phibar2     = nu2 * PHIM2;
phibar1star = nu1 * PHIM1star;
phibar2star = nu2 * PHIM2star;


# --- shocks
# - AVERAGE PRODUCTIVITY IN EACH COUNTRY
MU_a     = 7.;
MU_astar = 1.;

RHO_a          = 0.968;
SIGMA_a        = 1.6 / 100;
RHO_astar      = 0.98;
SIGMA_astar    = 6 / 100 ;
CORR_a_astar   = 0.

# --- percentile: compute returns for firms with given percentile:
pct_a = 20 / 100;
pct_b = 80 / 100


# --- model parameter type
param = GML2_Parameters(NU, NUstar, IES, BETA, SIGMA1, SIGMA2, THETA, a0, a0star, alpha_rs,
                        ETA1, ETA2, ETA1star, ETA2star, PHIM1, PHIM2, PHIM1star, PHIM2star,
                        GAMMA1, GAMMA2, F1exp, F2exp, F1expstar, F2expstar,
                        TAU1, TAU2, TAU1star, TAU2star,
                        M1, M2, M1star, M2star, L, Lstar,
                        markup1, nu1, phibar1, phibar1star, markup2, nu2, phibar2, phibar2star, pct_a, pct_b,
                        MU_a, MU_astar, RHO_a, SIGMA_a, RHO_astar, SIGMA_astar, CORR_a_astar,
                        zeros(1,1), zeros(1,1) )



#-------------------------------------------------------------------------------------------------------
# ----- SOLVE THE MODEL
# --- 1. Write steady state function into matlab
search_region = [ (1., 1.), (1., 1.), (param.PHIM1, 1e01), (param.PHIM2, 1e01),
  (param.PHIM1star, 1e01), (param.PHIM2star, 1e01), (1e-02, 1e02), (1e-02, 1e02), (1., 1.) ];
ss_point = [MU_a MU_astar];

result = bboptimize(x -> GML2_routines.GML2_optimize(x[:, :], param, ss_point),
                        SearchRange = search_region,
                        OptimizationValue = 0.0,
                        Method = :adaptive_de_rand_1_bin_radiuslimited,
                        MaxSteps = 1e06, FitnessTolerance = 1e-6,
                        OptimizationValue = 0.0,
                        TraceMode=:silent, TraceInterval=10
                        );

# --- Some moments of steady state
sol_ss   = best_candidate(result);
error_ss = best_fitness(result);
GML2_routines.GML2_moments(sol_ss[:,:], param);
#-------------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------------------------------------------
# --- write a dynare file
str_variables = "Ashock  cons consstar consind1 consind2 zeta1 zeta2 profit1 profit2 profit1D profit2D profit1X profit2X import_pen1 import_pen2 domprod1 domprod2 zeta1star export1star zeta2star export2star log_profit1 log_profit2 log_profit1D log_profit2D log_profit1X log_profit2X value1 value2 value1D value2D ret1 ret2 ret1D ret2D forex_tradable forex_agg log_cons log_consstar paggstar revenuestar_tot"

if (alpha_rs == 0) & (sim == 0) # no risk sharing and IRF
  sol_full = GML2_routines.GML2_compute_model(sol_ss[:, :], param, ss_point; # - write steady state
                                write_to_matlab = string(path_to, "/dynare_code/GML2_nors/matlab_steady_GML2.m"))

  GML2_to_dynare(sol_ss[:,:], param,
                 header_file = "GML2_header.mod", model_file = "GML2_model.mod",
                 steady_file = "GML2_steady.mod", post_file = "GML2_process.mod",
                 out_file    = "./dynare_code/GML2_nors/GML2.mod",
                 simul_var    = str_variables,
                 order = 3,
                 irf = 100, replic = 2000, periods = 20000)

  GML2_m_script("./dynare_code/GML2_nors",
                script_out  = "./dynare_code/matlab_exec_dyn.m",
                dynare_path = dyn_path)

  println(string("\n# Julia wrote 2 files: \n",
                 "#  - `./dynare_code/GML2_nors/matlab_steady_GML2.m`\n",
                 "#  - `./dynare_code/GML2_nors/GML2.mod`\n\n"))

    if (dyn == 1)
      run(`$matlab_bin -nodesktop -nosplash -nojvm '<' ./dynare_code/matlab_exec_dyn.m`)
    end


elseif (alpha_rs == 1) & (sim == 0) # full risk sharing

  sol_full = GML2_routines.GML2_compute_model(sol_ss[:, :], param, ss_point; # - write steady state
                                write_to_matlab = string(path_to, "/dynare_code/GML2_fullrs/matlab_steady_GML2.m"))

    GML2_to_dynare(sol_ss[:,:], param,
                   header_file = "GML2_header.mod", model_file = "GML2_model.mod",
                   steady_file = "GML2_steady.mod", post_file = "GML2_process.mod",
                   out_file    = "./dynare_code/GML2_fullrs/GML2.mod",
                   simul_var    = str_variables,
                   order = 3,
                   irf = 100, replic = 2000, periods = 20000)

   GML2_m_script("./dynare_code/GML2_fullrs",
                 script_out  = "./dynare_code/matlab_exec_dyn.m",
                 dynare_path = dyn_path)


  println(string("\n# Julia wrote 2 files: \n",
                 "#  - `./dynare_code/GML2_fullrs/matlab_steady_GML2.m`\n",
                 "#  - `./dynare_code/GML2_fullrs/GML2.mod`\n\n"))

  if (dyn==1)
     run(`$matlab_bin -nodesktop -nosplash -nojvm '<' ./dynare_code/matlab_exec_dyn.m`)
  end

elseif (sim == 1)
    sol_full = GML2_routines.GML2_compute_model(sol_ss[:, :], param, ss_point; # - write steady state
                 write_to_matlab = string(path_to, "/dynare_code/GML2_some_rs/matlab_steady_GML2.m"))

  GML2_to_dynare(sol_ss[:,:], param,
                 header_file = "GML2_header.mod", model_file = "GML2_model.mod",
                 steady_file = "GML2_steady.mod", post_file = "GML2_process.mod",
                 out_file    = "./dynare_code/GML2_some_rs/GML2.mod",
                 simul_var    = str_variables,
                 order = 3,
                irf = 1, replic = 1, periods = 1000000)

  GML2_m_script("./dynare_code/GML2_some_rs",
                script_out  = "./dynare_code/matlab_exec_dyn.m",
                dynare_path = dyn_path)

  println(string("\n# Julia wrote 2 files: \n",
                   "#  - `./dynare_code/GML2_some_rs/matlab_steady_GML2.m`\n",
                   "#  - `./dynare_code/GML2_some_rs/GML2.mod`\n\n"))
  if (dyn==1)
    run(`$matlab_bin -nodesktop -nosplash -nojvm '<' ./dynare_code/matlab_exec_dyn.m`)
  end

end
#----------------------------------------------------------------------------

return(sol_ss)

end # end of function solve_GML2_model
#----------------------------------------------------------------------------

end # end of module GML2_solver
#----------------------------------------------------------------------------
