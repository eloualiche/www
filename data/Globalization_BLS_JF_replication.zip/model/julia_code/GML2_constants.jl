#! /usr/bin/julia
#
# GML2_constants.jl
#
# define types and model constants
#
# created           July      22nd 2016
# last modified     June           2018
#
# (c) Loualiche
#
#



module GML2_constants



#######################################################################################
# -----  TYPES

# ---- what do we export
export GML2_Parameters
export GML2_Sol

#########################
# ----- model parameters
type GML2_Parameters

# --- intertemporal preferences
    NU::Float64     # RRA
    NUstar::Float64
    IES::Float64    # IES
    BETA::Float64   # Subj. Discount


# --- elasticities of substitution
    SIGMA1::Float64
    SIGMA2::Float64

    THETA::Float64

    a0::Float64 # elasticity in the Cobb-Douglas between tradable and other
    a0star::Float64

    alpha_rs::Float64  # risk sharing coefficient 0 -> no risk sharing

# - taste parameters across sectors
    ETA1::Float64
    ETA2::Float64
    ETA1star::Float64
    ETA2star::Float64

# ---Firms: distribution and productivity
    PHIM1::Float64
    PHIM2::Float64
    PHIM1star::Float64
    PHIM2star::Float64

    GAMMA1::Float64
    GAMMA2::Float64


# --- Trade costs:
    F1exp::Float64
    F2exp::Float64
    F1expstar::Float64
    F2expstar::Float64

    TAU1::Float64
    TAU2::Float64
    TAU1star::Float64
    TAU2star::Float64

# --- Size of each economy
    M1::Float64
    M2::Float64
    M1star::Float64
    M2star::Float64

    L::Float64
    Lstar::Float64


# --- derivative constants
    markup1::Float64
    nu1::Float64
    phibar1::Float64
    phibar1star::Float64
    markup2::Float64
    nu2::Float64
    phibar2::Float64
    phibar2star::Float64

    pct_a::Float64
    pct_b::Float64

# --- Calibration of the shock (persistence and volatility)
    MU_a::Float64
    MU_astar::Float64
    RHO_a::Float64
    SIGMA_a::Float64
    RHO_astar::Float64
    SIGMA_astar::Float64
    CORR_a_astar::Float64

    M_trans::Array{Float64,2}
    Mstar_trans::Array{Float64,2}

  ## # model solving parameters
  ## MODEL_freq::Float64 # 12 for monthly

  ## # simulation parameters
  ## equilibrium_type::Symbol

  ## # prices in partial equilibrium
  ## rf_pe::Float64
  ## rp_pe::Float64

end

## # construction example
## param = GM2_Parameters(NU, BETA, SIGMA1, SIGMA2,
##                        ETA1, ETA2, ETA1star, ETA2star, PHIM1, PHIM2,
##                        GAMMA1, GAMMA2, F1exp, F2exp, F1expstar, F2expstar,
##                        TAU1, TAU2, TAU1star, TAU2star,
##                        M1, M2, M1star, M2star, L, Lstar,
##                        markup1, nu1, phibar1, markup2, nu2, phibar2,
##                        MU_a, MU_astar, RHO_a, SIGMA_a, RHO_astar, SIGMA_astar,
##                        zeros(1,1), zeros(1,1) )
##                         ## MODEL_freq, equilibrium_type, rf_pe, rp_pe );
## param



#################################
# II. model solution
immutable GML2_Sol

  controls::Array{Float64,2}

  grid::Array{Float64,2}

  objective::Array{Float64,1}
  timing::Array{Float64,1}

  param::GML2_Parameters

end















end
# end of the GML2_constants module
