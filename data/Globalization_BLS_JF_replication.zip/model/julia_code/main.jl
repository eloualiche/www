#! /usr/bin/julia
#
# main.jl
#
#
# created           June 11th   2018
# last modified     June 11th  2018
#
# (c) Barrot, Loualiche & Sauvagnat
#
#
#######################################################################################



# --- First set up your path to this folder:
my_path = "/Users/.../replication/model/"
cd(my_path)
# then this will add the subroutines to the julia search path
push!(LOAD_PATH, string(my_path, "/julia_code") ) # extend the path
# It is important to get the path of your dynare installation:
dyn_path = "/Applications/Dynare/4.5.3/matlab"
# And where you matlab executable is
matlab_bin = "/Applications/MATLAB_R2017b.app/bin/matlab"

# --- Housekeeping in the folders
run(`rm -rf ./dynare_code/GML2_nors`);    run(`mkdir ./dynare_code/GML2_nors`)
run(`rm -rf ./dynare_code/GML2_fullrs`);  run(`mkdir ./dynare_code/GML2_fullrs`);
run(`rm -rf ./dynare_code/GML2_some_rs`); run(`mkdir ./dynare_code/GML2_some_rs`);


# --- load packages  used for solving the model
using BlackBoxOptim
using QuantEcon: tauchen
using DataFrames
# use Pkg.add("package_name") if you have not installed them before

# --- load all routines where the model functions are defined
using GML2_constants
using GML2_routines
using GML2_solver


# --- create dynare files for simulation
# - 1. model with no risk sharing
solve_GML2_model(0, 0, 1, my_path, dyn_path = dyn_path, matlab_bin = matlab_bin);
# - simulate the model using matlab (already done if 1 chosen above)
# run(`$matlab_bin -nodesktop -nosplash -nojvm '<' ./dynare_code/matlab_exec_dyn.m`)

# - 2.  model with risk sharing
solve_GML2_model(1, 0, 1, my_path, dyn_path = dyn_path, matlab_bin = matlab_bin);

# - 3. model with various risk sharing levels: simulation
solve_GML2_model(0, 1, 1, my_path); # zero risk sharing. useful for calibration TAble

# 4 - other risk sharing levels
#   matlab execution mode is off.
#   run the matlab exec `./dynare_Code/matlab_exec_dyn.m`
#   run(`$matlab_bin -nodesktop -nosplash -nojvm '<' ./dynare_code/matlab_exec_dyn.m`)
#   then save the simulation in R
#   see `./R_code/read_irf.R` for savings
#   and ./R_code/plots_risk_sharing.R` where we use various levels of risk sharing
solve_GML2_model(0.50, 1, 0, my_path);
solve_GML2_model(0.75, 1, 0, my_path);
solve_GML2_model(0.85, 1, 0, my_path);
solve_GML2_model(0.90, 1, 0, my_path);
solve_GML2_model(0.95, 1, 0, my_path);
solve_GML2_model(1,    1, 0, my_path);
