#! /usr/bin/julia
#
# GML2b_routines.jl
#
# Routines for the GML2 version of the model
#
# Created        July      22nd 2016
# Last modified  June           2018
#
##
#######################################################################################



module GML2b_routines



#######################################################################################
# ----- Which packages are necessary in this module
using GML2b_constants: GML2b_Parameters

using QuantEcon: tauchen
using DataFrames


########################################################################################################
# ----- Functions to EXPORT
export GML2b_grid

export GML2b_optimize, GML2b_optimize_rs
export GML2b_compute_model
export GML2b_to_dynare
export GML2b_moments
export GML2b_save_param




########################################################################################################
# ----- Functions defining the model

# --- notes
# functions depend on:
# 1. controls: controls = [wage wagestar phi1X phi2X phi1Xstar phi2Xstar Cons Consstar fx]
# 2. parameters
# 3. shocks = [A_shock Astar_shock]

# --- debug:
## controls = [1. 1. 1. 1. 1. 1. 1. 1. 1.][:, :]
## par      = param
## shocks   = [1., 1.][:, :]


# --- define price functions
function rho1D(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.markup1 .* controls[1]  ./ (shocks[1] * par.phibar1)
end
function rho2D(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.markup2 .* controls[1]  ./ (shocks[1] * par.phibar2)
end

function rho1Dstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.markup1 .* controls[2]  ./ (shocks[2] * par.phibar1star)
end

function rho2Dstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.markup2 .* controls[2]  ./ (shocks[2] * par.phibar2star)
end


function rho1X(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.TAU1  ./ controls[9] * par.markup1 .* controls[1]   ./ (shocks[1] * par.nu1 * controls[3])
end
function rho2X(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.TAU2  ./ controls[9] * par.markup2 .* controls[1]   ./ (shocks[1] * par.nu2 * controls[4])
end

function rho1Xstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.TAU1star  * controls[9] .* par.markup1 .* controls[2]   ./ (shocks[2] * par.nu1 * controls[5])
end

function rho2Xstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.TAU2star  * controls[9] .* par.markup2 .* controls[2]   ./ (shocks[2] * par.nu2 * controls[6])
end


# --- fraction of exporters
function zeta1_exp(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( controls[3] ./ par.PHIM1 ).^(-par.GAMMA1)
end
function zeta2_exp(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( controls[4] ./ par.PHIM2 ).^(-par.GAMMA2)
end

function zeta1star_exp(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( controls[5] ./ par.PHIM1star ).^(-par.GAMMA1)
end
function zeta2star_exp(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( controls[6] ./ par.PHIM2star ).^(-par.GAMMA2)
end


# --- PRICE INDICES
# - Industry index:
function Gamind1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   ( par.M1 * ( rho1D(controls, par, shocks) )^(1-par.SIGMA1)  + par.M1star * zeta1star_exp(controls, par, shocks) * ( rho1Xstar(controls, par, shocks) )^(1-par.SIGMA1) )^(1/(1-par.SIGMA1))
end
function Gamind2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   ( par.M2 * ( rho2D(controls, par, shocks) )^(1-par.SIGMA2)  + par.M2star * zeta2star_exp(controls, par, shocks) * ( rho2Xstar(controls, par, shocks) )^(1-par.SIGMA2) )^(1/(1-par.SIGMA2))
end

function Gamind1star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   ( par.M1star * ( rho1Dstar(controls, par, shocks) )^(1-par.SIGMA1)  + par.M1 * zeta1_exp(controls, par, shocks) * ( rho1X(controls, par, shocks) )^(1-par.SIGMA1) )^(1/(1-par.SIGMA1))
end
function Gamind2star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   ( par.M2star * ( rho2Dstar(controls, par, shocks) )^(1-par.SIGMA2)  + par.M2 * zeta2_exp(controls, par, shocks) * ( rho2X(controls, par, shocks) )^(1-par.SIGMA2) )^(1/(1-par.SIGMA2))
end

# - Tradable good prices
function Ptradable(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( par.ETA1 * Gamind1(controls, par, shocks)^(1-par.THETA) + par.ETA2 * Gamind2(controls, par, shocks)^(1-par.THETA) )^(1/(1-par.THETA))
end

function Ptradablestar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( par.ETA1star * Gamind1star(controls, par, shocks)^(1-par.THETA) + par.ETA2star * Gamind2star(controls, par, shocks)^(1-par.THETA) )^(1/(1-par.THETA))
end

# - Finall agreggate good prices
function Pagg(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( Ptradable(controls, par, shocks) / par.a0 )^(par.a0) * ( 1 / (1-par.a0) )^(1-par.a0)
end

function Paggstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( Ptradablestar(controls, par, shocks) / par.a0star )^(par.a0star) * ( 1 / (1-par.a0star) )^(1-par.a0star)
end


# --- CONSUMPTION
# Tradable consumption
function constradable(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.a0 * Pagg(controls, par, shocks) / Ptradable(controls, par, shocks) * controls[7]
end

function consstartradable(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.a0star * Paggstar(controls, par, shocks) / Ptradablestar(controls, par, shocks) * controls[8]
end

#  sanity check: homogenous good consumption
function conshomogeneous(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( 1 - par.a0 ) * Pagg(controls, par, shocks) * controls[7]
end

function consstarhomogeneous(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    ( 1 - par.a0star ) * Paggstar(controls, par, shocks) * controls[8]
end

# industry level consumption?
function consind1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.ETA1 * par.a0 * ( Gamind1(controls, par, shocks) )^(-par.THETA) * ( Ptradable(controls, par, shocks) )^(par.THETA-1) * Pagg(controls, par, shocks) * controls[7]
end
function consind2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.ETA2 * par.a0 * ( Gamind2(controls, par, shocks) )^(-par.THETA) * ( Ptradable(controls, par, shocks) )^(par.THETA-1) * Pagg(controls, par, shocks) * controls[7]
end

function consstarind1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.ETA1star * par.a0star * ( Gamind1star(controls, par, shocks) )^(-par.THETA) * ( Ptradablestar(controls, par, shocks) )^(par.THETA-1) * Paggstar(controls, par, shocks) * controls[8]
end
function consstarind2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    par.ETA2star * par.a0star * ( Gamind2star(controls, par, shocks) )^(-par.THETA) * ( Ptradablestar(controls, par, shocks) )^(par.THETA-1) * Paggstar(controls, par, shocks) * controls[8]
end


# --- Profits
function profit1D(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho1D_tmp = rho1D(controls, par, shocks)
    1/par.SIGMA1 .* ( rho1D_tmp ).^(1-par.SIGMA1) .* Gamind1(controls, par, shocks)^(par.SIGMA1) * consind1(controls, par, shocks)
end
function profit2D(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho2D_tmp = rho2D(controls, par, shocks)
    1/par.SIGMA2 .* ( rho2D_tmp ).^(1-par.SIGMA2) .* Gamind2(controls, par, shocks)^(par.SIGMA2) * consind2(controls, par, shocks)
end

function profit1Dstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho1Dstar_tmp = rho1Dstar(controls, par, shocks)
    1/par.SIGMA1 .* ( rho1Dstar_tmp ).^(1-par.SIGMA1) .* Gamind1star(controls, par, shocks)^(par.SIGMA1) * consstarind1(controls, par, shocks)
end
function profit2Dstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho2Dstar_tmp = rho2Dstar(controls, par, shocks)
    1/par.SIGMA2 .* ( rho2Dstar_tmp ).^(1-par.SIGMA2) .* Gamind2star(controls, par, shocks)^(par.SIGMA2) * consstarind2(controls, par, shocks)
end


function profit1X(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho1X_tmp = rho1X(controls, par, shocks)
    1/par.SIGMA1 .* controls[9] * ( rho1X_tmp ).^(1-par.SIGMA1) .* Gamind1star(controls, par, shocks)^(par.SIGMA1)  .* consstarind1(controls, par, shocks)  - controls[1] * par.F1exp ./ shocks[1]
end
function profit2X(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho2X_tmp = rho2X(controls, par, shocks)
    1/par.SIGMA2 .* controls[9] * ( rho2X_tmp ).^(1-par.SIGMA2) .* Gamind2star(controls, par, shocks)^(par.SIGMA2)  .* consstarind2(controls, par, shocks)  - controls[1] * par.F2exp ./ shocks[1]
end

function profit1Xstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho1Xstar_tmp = rho1Xstar(controls, par, shocks)
    1/par.SIGMA1 ./ controls[9] * ( rho1Xstar_tmp ).^(1-par.SIGMA1) .* Gamind1(controls, par, shocks)^(par.SIGMA1)  .* consind1(controls, par, shocks) - controls[2] * par.F1expstar ./ shocks[2]
end
function profit2Xstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    rho2Xstar_tmp = rho2Xstar(controls, par, shocks)
    1/par.SIGMA2 ./ controls[9] * ( rho2Xstar_tmp ).^(1-par.SIGMA2) .* Gamind2(controls, par, shocks)^(par.SIGMA2)  .* consind2(controls, par, shocks) - controls[2] * par.F2expstar ./ shocks[2]
end


function profit1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   profit1D(controls, par, shocks) + zeta1_exp(controls, par, shocks) .* profit1X(controls, par, shocks)
end
function profit2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   profit2D(controls, par, shocks) + zeta2_exp(controls, par, shocks) .* profit2X(controls, par, shocks)
end

function profit1star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   profit1Dstar(controls, par, shocks) + zeta1star_exp(controls, par, shocks) .* profit1Xstar(controls, par, shocks)
end
function profit2star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   profit2Dstar(controls, par, shocks) + zeta2star_exp(controls, par, shocks) .* profit2Xstar(controls, par, shocks)
end


# ----- EXPORTS AND IMPORTS
function export1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.M1 * zeta1_exp(controls, par, shocks) * ( rho1X(controls, par, shocks) )^(1-par.SIGMA1) *
    ( Gamind1star(controls, par, shocks) )^(par.SIGMA1) * consstarind1(controls, par, shocks)
end
function export2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.M2 * zeta2_exp(controls, par, shocks) * ( rho2X(controls, par, shocks) )^(1-par.SIGMA2) *
    ( Gamind2star(controls, par, shocks) )^(par.SIGMA2) * consstarind2(controls, par, shocks)
end

function export1star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.M1star * zeta1star_exp(controls, par, shocks) * ( rho1Xstar(controls, par, shocks) )^(1-par.SIGMA1) *
    ( Gamind1(controls, par, shocks) )^(par.SIGMA1) * consind1(controls, par, shocks)
end
function export2star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   par.M2star * zeta2star_exp(controls, par, shocks) * ( rho2Xstar(controls, par, shocks) )^(1-par.SIGMA2) *
    ( Gamind2(controls, par, shocks) )^(par.SIGMA2) * consind2(controls, par, shocks)
end

# total exports
function export_tradable(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    export1(controls, par, shocks) + export2(controls, par, shocks)
end
function exportstar_tradable(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    export1star(controls, par, shocks) + export2star(controls, par, shocks)
end



# ----- FINAL OPTIMIZATION EXPRESSION
# --- cutoffs
function cutoff1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    profit1X(controls, par, shocks) - controls[1] .* par.F1exp ./ shocks[1] .* (par.SIGMA1-1)/(par.GAMMA1-(par.SIGMA1-1))
end
function cutoff2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    profit2X(controls, par, shocks) - controls[1] .* par.F2exp ./ shocks[1] .* (par.SIGMA2-1)/(par.GAMMA2-(par.SIGMA2-1))
end

function cutoff1star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    profit1Xstar(controls, par, shocks) - controls[2] * par.F1expstar ./ shocks[2] * (par.SIGMA1-1)/(par.GAMMA1-(par.SIGMA1-1))
end
function cutoff2star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    profit2Xstar(controls, par, shocks) - controls[2] * par.F2expstar ./ shocks[2] * (par.SIGMA2-1)/(par.GAMMA2-(par.SIGMA2-1))
end

# --- total revenues
function revenue_tot(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.alpha_rs * par.M1 / (par.M1 + par.M1star) * par.M1star * profit1star(controls, par, shocks) + (1 - par.alpha_rs * par.M1star / (par.M1 + par.M1star) ) * par.M1 * profit1(controls, par, shocks) + par.alpha_rs * par.M2 / (par.M2 + par.M2star) * par.M2star * profit2star(controls, par, shocks) + (1 - par.alpha_rs * par.M2star / (par.M2 + par.M2star) ) * par.M2 * profit2(controls, par, shocks)
end
function revenuestar_tot(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.alpha_rs * par.M1star / (par.M1 + par.M1star) * par.M1 * profit1(controls, par, shocks) + (1 - par.alpha_rs * par.M1 / (par.M1 + par.M1star) ) * par.M1star * profit1star(controls, par, shocks) + par.alpha_rs * par.M2star / (par.M2 + par.M2star) * par.M2 * profit2(controls, par, shocks) + (1 - par.alpha_rs * par.M2 / (par.M2 + par.M2star) ) * par.M2star * profit2star(controls, par, shocks)
end


# --- budget
function budget(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    Pagg(controls, par, shocks) * controls[7] - controls[1] * par.L - revenue_tot(controls, par, shocks)
    #par.M1 * profit1(controls, par, shocks) - par.M2 * profit2(controls, par, shocks)
end
function budgetstar(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    Paggstar(controls, par, shocks) * controls[8] - controls[2] * par.Lstar - revenuestar_tot(controls, par, shocks)
    ## par.M1star * profit1star(controls, par, shocks) - par.M2star * profit2star(controls, par, shocks)
end

# --- balanced trade
function balancedtrade(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
    exportstar_tradable(controls, par, shocks) - controls[9] * export_tradable(controls, par, shocks)
end


# --- LOCAL PRODUCTION:
function domprod1(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.M1 * ( rho1D(controls, par, shocks) )^(1-par.SIGMA1) *
    ( Gamind1(controls, par, shocks) )^(par.SIGMA1) * consind1(controls, par, shocks)
end
function domprod2(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.M2 * ( rho2D(controls, par, shocks) )^(1-par.SIGMA2) *
    ( Gamind2(controls, par, shocks) )^(par.SIGMA2) * consind2(controls, par, shocks)
end

function domprod1star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
  par.M1star * ( rho1Dstar(controls, par, shocks) )^(1-par.SIGMA1) *
    ( Gamind1star(controls, par, shocks) )^(par.SIGMA1) * consstarind1(controls, par, shocks)
end
function domprod2star(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})
   par.M2star * ( rho2Dstar(controls, par, shocks) )^(1-par.SIGMA2) *
    ( Gamind2star(controls, par, shocks) )^(par.SIGMA2) * consstarind2(controls, par, shocks)
end





# ----- Optimization summary function
function GML2b_optimize(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})

    res = zeros(6);

    res[1] = cutoff1(controls, par, shocks)
    res[2] = cutoff2(controls, par, shocks)
    res[3] = cutoff1star(controls, par, shocks)
    res[4] = cutoff2star(controls, par, shocks)

    res[5] = budget(controls, par, shocks)
    res[6] = budgetstar(controls, par, shocks)


    return( sum( abs2(res) ) )

end
# end of GML_optimize


# ----- Optimization summary function: full risk sharing
function GML2b_optimize_rs(controls::Array{Float64,2}, par::GML2b_Parameters, shocks::Array{Float64,2})

    res = zeros(6);

    res[1] = cutoff1(controls, par, shocks)
    res[2] = cutoff2(controls, par, shocks)
    res[3] = cutoff1star(controls, par, shocks)
    res[4] = cutoff2star(controls, par, shocks)

    res[5] = budget_rs(controls, par, shocks)
    res[6] = budgetstar_rs(controls, par, shocks)

    ## res[7] = balancedtrade(controls, par, shocks)

    return( sum( abs2(res) ) )

end
# end of GML_optimize




########################################################################################################
# ----- One Functions that estimates the full model
function GML2b_compute_model(controls::Array{Float64,2},
                            par::GML2b_Parameters,
                            shocks::Array{Float64,2};
                            write_to_matlab = "",
                            write_to_dynarepp = ""
                            )

# debug
## par = param
## controls = sol_ss[:, :]
## shocks   = ss_point
## string_to_matlab = string(path_to, "/dynare_code/GML_dynare/matlab_steady_GML.m")


    wage, wagestar       = controls[1], controls[2]
    phi1X, phi2X         = controls[3], controls[4]
    phi1Xstar, phi2Xstar = controls[5], controls[6]
    cons, consstar       = controls[7], controls[8]
    fx                   = controls[9]

    rho1D_ss, rho2D_ss               = rho1D(controls, par, shocks), rho2D(controls, par, shocks)
    rho1Dstar_ss, rho2Dstar_ss       = rho1Dstar(controls, par, shocks), rho2Dstar(controls, par, shocks)
    rho1X_ss, rho2X_ss               = rho1X(controls, par, shocks), rho2X(controls, par, shocks)
    rho1Xstar_ss, rho2Xstar_ss       = rho1Xstar(controls, par, shocks), rho2Xstar(controls, par, shocks)

    zeta1_ss, zeta2_ss               = zeta1_exp(controls, par, shocks), zeta2_exp(controls, par, shocks)
    zeta1star_ss, zeta2star_ss       = zeta1star_exp(controls, par, shocks), zeta2star_exp(controls, par, shocks)

    Gamind1_ss, Gamind2_ss           = Gamind1(controls, par, shocks), Gamind2(controls, par, shocks)
    Gamind1star_ss, Gamind2star_ss   = Gamind1star(controls, par, shocks), Gamind2star(controls, par, shocks)

    ptradable_ss, ptradablestar_ss   = Ptradable(controls, par, shocks), Ptradablestar(controls, par, shocks)
    pagg_ss, paggstar_ss             = Pagg(controls, par, shocks), Paggstar(controls, par, shocks)

    consind1_ss, consind2_ss         = consind1(controls, par, shocks), consind2(controls, par, shocks)
    consstarind1_ss, consstarind2_ss = consstarind1(controls, par, shocks), consstarind2(controls, par, shocks)
    constradable_ss                  = constradable(controls, par, shocks)
    consstartradable_ss              = consstartradable(controls, par, shocks)
    conshomogeneous_ss               = conshomogeneous(controls, par, shocks)
    consstarhomogeneous_ss           = consstarhomogeneous(controls, par, shocks)

    profit1D_ss, profit2D_ss         = profit1D(controls, par, shocks), profit2D(controls, par, shocks)
    profit1Dstar_ss, profit2Dstar_ss = profit1Dstar(controls, par, shocks), profit2Dstar(controls, par, shocks)
    profit1X_ss, profit2X_ss         = profit1X(controls, par, shocks), profit2X(controls, par, shocks)
    profit1Xstar_ss, profit2Xstar_ss = profit1Xstar(controls, par, shocks), profit2Xstar(controls, par, shocks)
    profit1_ss, profit2_ss           = profit1(controls, par, shocks), profit2(controls, par, shocks)
    profit1star_ss, profit2star_ss   = profit1star(controls, par, shocks), profit2star(controls, par, shocks)

    export1_ss, export2_ss           = export1(controls, par, shocks), export2(controls, par, shocks)
    export1star_ss, export2star_ss   = export1star(controls, par, shocks), export2star(controls, par, shocks)
    exporttradable_ss                = export_tradable(controls, par, shocks)
    exportstartradable_ss            = exportstar_tradable(controls, par, shocks)

    revenue_tot_ss                   = revenue_tot(controls, par, shocks)
    revenuestar_tot_ss               = revenuestar_tot(controls, par, shocks)

    import_pen1_ss                   = export1star(controls, par, shocks) / ( domprod1(controls, par, shocks) + export1star(controls, par, shocks) )
    import_pen2_ss                   = export2star(controls, par, shocks) / ( domprod2(controls, par, shocks) + export2star(controls, par, shocks) )
    importstar_pen1_ss               = export1(controls, par, shocks)     / ( domprod1star(controls, par, shocks) + export1(controls, par, shocks) )
    importstar_pen2_ss               = export2(controls, par, shocks)     / ( domprod2star(controls, par, shocks) + export2(controls, par, shocks) )

    domprod1_ss, domprod2_ss         = domprod1(controls, par, shocks), domprod2(controls, par, shocks)
    domprod1star_ss, domprod2star_ss = domprod1star(controls, par, shocks), domprod2star(controls, par, shocks)


    res = [ wage wagestar phi1X phi2X phi1Xstar phi2Xstar cons consstar fx rho1D_ss rho2D_ss rho1Dstar_ss rho2Dstar_ss rho1X_ss rho2X_ss rho1Xstar_ss rho2Xstar_ss zeta1_ss zeta2_ss zeta1star_ss zeta2star_ss Gamind1_ss Gamind2_ss Gamind1star_ss Gamind2star_ss ptradable_ss ptradablestar_ss pagg_ss paggstar_ss consind1_ss consind2_ss consstarind1_ss consstarind2_ss constradable_ss consstartradable_ss conshomogeneous_ss consstarhomogeneous_ss profit1D_ss profit2D_ss profit1Dstar_ss profit2Dstar_ss profit1X_ss profit2X_ss profit1Xstar_ss profit1Xstar_ss profit1_ss profit2_ss profit1star_ss profit2star_ss export1_ss export2_ss export1star_ss export2star_ss exporttradable_ss exportstartradable_ss revenue_tot_ss revenuestar_tot_ss import_pen1_ss import_pen2_ss importstar_pen1_ss importstar_pen2_ss domprod1_ss domprod2_ss domprod1star_ss domprod2star_ss]




    ss_assignment =
        string("\n\n",
               #"wage = ", wage, ";\nwagestar = ", wagestar, ";\n\n",
               "phi1X = ", phi1X, ";\nphi2X = ", phi2X, ";\nphi1Xstar = ", phi1Xstar, ";\nphi2Xstar = ", phi2Xstar, ";\n\n",
               "cons = ", cons, ";\nconsstar = ", consstar, ";\n\n",
               "fx = ", fx, ";\n\n\n",

               "rho1D = ", rho1D_ss, ";\nrho2D = ", rho2D_ss, ";\nrho1Dstar = ", rho1Dstar_ss, ";\nrho2Dstar = ", rho2Dstar_ss, ";\n\n",
               "rho1X = ", rho1X_ss, ";\nrho2X = ", rho2X_ss, ";\nrho1Xstar = ", rho1Xstar_ss, ";\nrho2Xstar = ", rho2Xstar_ss, ";\n\n",
               "zeta1 = ", zeta1_ss, ";\nzeta2 = ", zeta2_ss, ";\nzeta1star = ", zeta1star_ss, ";\nzeta2star = ", zeta2star_ss, ";\n\n",

               "Gamind1 = ", Gamind1_ss, ";\nGamind2 = ", Gamind2_ss, ";\nGamind1star = ", Gamind1star_ss, ";\nGamind2star = ", Gamind2star_ss, ";\n\n",
               "ptradable = ", ptradable_ss, ";\nptradablestar = ", ptradablestar_ss, ";\n",
               "pagg = ", pagg_ss, ";\npaggstar = ", paggstar_ss, ";\n\n",

               "consind1 = ", consind1_ss, ";\nconsind2 = ", consind2_ss, ";\nconsstarind1 = ", consstarind1_ss, ";\nconsstarind2 = ", consstarind2_ss, ";\n\n",
               "constradable = ", constradable_ss, ";\nconsstartradable = ", consstartradable_ss, ";\n",
               "conshomogeneous = ", conshomogeneous_ss, ";\nconsstarhomogeneous = ", consstarhomogeneous_ss, ";\n\n",

               "profit1D = ", profit1D_ss, ";\nprofit2D = ", profit2D_ss, ";\nprofit1Dstar = ", profit1Dstar_ss, ";\nprofit2Dstar = ", profit2Dstar_ss, ";\n\n",
               "profit1X = ", profit1X_ss, ";\nprofit2X = ", profit2X_ss, ";\nprofit1Xstar = ", profit1Xstar_ss, ";\nprofit2Xstar = ", profit2Xstar_ss, ";\n\n",
               "profit1 = ", profit1_ss, ";\nprofit2 = ", profit2_ss, ";\nprofit1star = ", profit1star_ss, ";\nprofit2star = ", profit2star_ss, ";\n\n",

               # "export1 = ", export1_ss, ";\nexport2 = ", export2_ss, ";\nexport1star = ", export1star_ss, ";\nexport2star = ", export2star_ss, ";\n\n",
               # "export_tradable = ", exporttradable_ss, ";\nexportstar_tradable = ", exportstartradable_ss, ";\n\n",

               "revenue_tot     = ", revenue_tot_ss, ";\nrevenuestar_tot = ", revenuestar_tot_ss, ";\n\n",
               # "import_pen1 = ", import_pen1_ss, ";\nimport_pen2 = ", import_pen2_ss,
               # ";\nimportstar_pen1 = ", importstar_pen1_ss, ";\nimportstar_pen2 = ", importstar_pen2_ss, ";\n\n",
               # "domprod1 = ", domprod1_ss, ";\ndomprod2 = ", domprod2_ss,
               # ";\ndomprod1star = ", domprod1star_ss, ";\ndomprod2star = ", domprod2star_ss,  ";\n\n"
               );


    if (write_to_dynarepp != "" )

        f = open(write_to_dynarepp, "w");
        write(f, ss_assignment);
        close(f);

    end

    if (write_to_matlab != "" )

        m_file = string(write_to_matlab)

        preamble = string("\n%%%%%%%%%%%%%%%%",
                          "\n%% Steady State file for Barrot, Loualiche & Sauvagnat model (JF): version with bond trading",
                          "\n%% To be used with dynare",
                          "\n%% This file is automatically generated from julia: see `GML2b_solver.jl` and `GML2b_routines.jl` for more information",
                          "\n%% Created on ", Libc.strftime(time()), "\n\n")

        m_function = string("function [ phi1X, phi2X, phi1Xstar, phi2Xstar, cons, consstar, fx, rho1D, rho2D, rho1Dstar, rho2Dstar, rho1X, rho2X, rho1Xstar, rho2Xstar, zeta1, zeta2, zeta1star, zeta2star, Gamind1, Gamind2, Gamind1star, Gamind2star, ptradable, ptradablestar, pagg, paggstar, consind1, consind2, consstarind1, consstarind2, constradable, consstartradable, conshomogeneous, consstarhomogeneous, profit1D, profit2D, profit1Dstar, profit2Dstar, profit1X, profit2X, profit1Xstar, profit2Xstar, profit1, profit2, profit1star, profit2star, " ,
          # "export1, export2, export1star, export2star, export_tradable, exportstar_tradable, "
          "revenue_tot, revenuestar_tot",
          # ", import_pen1, import_pen2, importstar_pen1, importstar_pen2 domprod1 domprod2 domprod1star domprod2star"
          " ] = matlab_steady_GML2b(tmp)", "\n\n")

        f = open(m_file, "w");
        write(f, string(preamble, m_function, ss_assignment, "end\n"));
        close(f);

    end

    return( res )

end
# end of compute_model







########################################################################################################
# ----- One Functions that estimates the full model
function GML2b_moments(controls::Array{Float64,2},
                      par::GML2b_Parameters
                      )



# debug
## par = param
## controls = sol_ss[:, :]


    shocks = [par.MU_a par.MU_astar][:, :]

    wage, wagestar       = controls[1], controls[2]
    phi1X, phi2X         = controls[3], controls[4]
    phi1Xstar, phi2Xstar = controls[5], controls[6]
    cons, consstar       = controls[7], controls[8]
    fx                   = controls[9]

    rho1D_ss, rho2D_ss               = rho1D(controls, par, shocks), rho2D(controls, par, shocks)
    rho1Dstar_ss, rho2Dstar_ss       = rho1Dstar(controls, par, shocks), rho2Dstar(controls, par, shocks)
    rho1X_ss, rho2X_ss               = rho1X(controls, par, shocks), rho2X(controls, par, shocks)
    rho1Xstar_ss, rho2Xstar_ss       = rho1Xstar(controls, par, shocks), rho2Xstar(controls, par, shocks)

    zeta1_ss, zeta2_ss               = zeta1_exp(controls, par, shocks), zeta2_exp(controls, par, shocks)
    zeta1star_ss, zeta2star_ss       = zeta1star_exp(controls, par, shocks), zeta2star_exp(controls, par, shocks)

    Gamind1_ss, Gamind2_ss           = Gamind1(controls, par, shocks), Gamind2(controls, par, shocks)
    Gamind1star_ss, Gamind2star_ss   = Gamind1star(controls, par, shocks), Gamind2star(controls, par, shocks)

    ptradable_ss, ptradablestar_ss   = Ptradable(controls, par, shocks), Ptradablestar(controls, par, shocks)
    pagg_ss, paggstar_ss             = Pagg(controls, par, shocks), Paggstar(controls, par, shocks)

    consind1_ss, consind2_ss         = consind1(controls, par, shocks), consind2(controls, par, shocks)
    consstarind1_ss, consstarind2_ss = consind1(controls, par, shocks), consind2(controls, par, shocks)
    constradable_ss                  = constradable(controls, par, shocks)
    consstartradable_ss              = consstartradable(controls, par, shocks)
    conshomogeneous_ss               = conshomogeneous(controls, par, shocks)
    consstarhomogeneous_ss           = consstarhomogeneous(controls, par, shocks)

    profit1D_ss, profit2D_ss         = profit1D(controls, par, shocks), profit2D(controls, par, shocks)
    profit1Dstar_ss, profit2Dstar_ss = profit1Dstar(controls, par, shocks), profit2Dstar(controls, par, shocks)
    profit1X_ss, profit2X_ss         = profit1X(controls, par, shocks), profit2X(controls, par, shocks)
    profit1Xstar_ss, profit2Xstar_ss = profit1Xstar(controls, par, shocks), profit2Xstar(controls, par, shocks)
    profit1_ss, profit2_ss           = profit1(controls, par, shocks), profit2(controls, par, shocks)
    profit1star_ss, profit2star_ss   = profit1star(controls, par, shocks), profit2star(controls, par, shocks)

    export1_ss, export2_ss           = export1(controls, par, shocks), export2(controls, par, shocks)
    export1star_ss, export2star_ss   = export1star(controls, par, shocks), export2star(controls, par, shocks)
    exporttradable_ss                = export_tradable(controls, par, shocks)
    exportstartradable_ss            = exportstar_tradable(controls, par, shocks)

    import_pen1_ss                   = export1star(controls, par, shocks) / ( domprod1(controls, par, shocks) + export1star(controls, par, shocks) )
    import_pen2_ss                   = export2star(controls, par, shocks) / ( domprod2(controls, par, shocks) + export2star(controls, par, shocks) )
    importstar_pen1_ss               = export1(controls, par, shocks)     / ( domprod1star(controls, par, shocks) + export1(controls, par, shocks) )
    importstar_pen2_ss               = export2(controls, par, shocks)     / ( domprod2star(controls, par, shocks) + export2(controls, par, shocks) )


    # --- Output Dataframe
    df = DataFrame()
    df[:variable] = ["phi1X", "phi2X", "phi1Xstar", "phi2Xstar", "cons", "consstar",
                     "import_pen1", "import_pen2", "importstar_pen1", "importstar_pen2",
                     "zeta1", "zeta2", "zeta1star", "zeta2star"]
    df[:steady_state]  = [ phi1X, phi2X, phi1Xstar, phi2Xstar, cons, consstar,
                           import_pen1_ss, import_pen2_ss, importstar_pen1_ss, importstar_pen2_ss,
                           zeta1_ss, zeta2_ss, zeta1star_ss, zeta2star_ss ]

    return( df )


end
# end of GML2b_moments







########################################################################################################
# ----- One Functions tto generate dynare mod file
function GML2b_to_dynare(controls::Array{Float64,2},
                        par::GML2b_Parameters;
                        out_file    = "GML2b_dynare.mod",
                        header_file = "",
                        model_file  = "",
                        steady_file = "",
                        post_file   = "",
                        simul_var   = "",
                        order       = 3,
                        irf         = 100,
                        replic      = 100,
                        periods     = 10000
                        )


# debug:
    ## par = param
    ## header_file = "GML2b_header.mod"
    ## model_file  = "GML2b_model.mod"
    ## steady_file = "GML2b_steady.mod"
    ## post_file   = "GML2b_process.mod"
    ## plot_var    = "cons consstar wage wagestar fx phi1X phi2X phi1Xstar phi2Xstar profit1D rho1D Gamind1 cons zeta1star rho1Xstar export1star profit2D rho2D Gamind2 cons zeta2star rho2Xstar export2star"


# julia generated header
    julia_header = string("//------------------------------------------------------------------\n",
                          "// This files is automatically generated from julia\n//\n",
                          "// See `GML2b_routines.jl` and `GML2b_solver.jl` for more details\n//\n",
                          "// File created at ", Libc.strftime(time()), "\n",
                          "//------------------------------------------------------------------\n\n")

# load header file
    f           = open(string("./dynare_code/model_files/", header_file), "r")
    header_str  = readstring(f);
    close(f)

# write parameters
    param_str   = string("NU = ", par.NU, ";\nNUstar = ", par.NUstar, ";\nBETA = ", par.BETA, ";\nIES = ", par.IES, ";\n\n",
                         "SIGMA1 = ", par.SIGMA1, ";\nSIGMA2 = ", par.SIGMA2, ";\na0 = ", par.a0, ";\na0star = ", par.a0star, ";\n\n",
                         "alpha_rs = ", par.alpha_rs, ";\n", "xiD_rs = ", par.xiD_rs, ";\n", "xiX_rs = ", par.xiX_rs, ";\n\n",
                         "THETA = ", par.THETA, ";\n\nPHIM1 = ", par.PHIM1, ";\nPHIM2 = ", par.PHIM2,
                         ";\nPHIM1star = ", par.PHIM1star, ";\nPHIM2star = ", par.PHIM2star,
                         ";\nGAMMA1 = ", par.GAMMA1, ";\nGAMMA2 = ", par.GAMMA2,
                         ";\n\nETA1 = ", par.ETA1, ";\nETA2 = ", par.ETA2, ";\nETA1star = ", par.ETA1star, ";\nETA2star = ", par.ETA2star,
                         ";\nTAU1 = ", par.TAU1, ";\nTAU2 = ", par.TAU2, ";\nTAU1star = ", par.TAU1star, ";\nTAU2star = ", par.TAU2star,
                         ";\nF1exp = ", par.F1exp, ";\nF2exp = ", par.F2exp, ";\nF1expstar = ", par.F1expstar, ";\nF2expstar = ", par.F2expstar, ";\n\n",
                         "M1 = ", par.M1, ";\nM2 = ", par.M2, ";\nM1star = ", par.M1star, ";\nM2star = ", par.M2star, ";\n\n",
                         "L = ", par.L, ";\nLstar = ", par.Lstar, ";\n\n",
                         "pct_a = ", par.pct_a, ";\npct_b = ", par.pct_b, ";\n\n",
                         "MU_a = ", par.MU_a,         ";\nRHO_a = ", par.RHO_a,             ";\nSIGMA_a = ",  par.SIGMA_a, ";\n",
                         "MU_astar = ", par.MU_astar, ";\nRHO_astar = ", par.RHO_astar, ";\nSIGMA_astar = ", par.SIGMA_astar, ";\n",
                         "CORR_a_astar = ", par.CORR_a_astar, ";\n\n")

    param_str = string(param_str,
                       "markup1   = SIGMA1 / (SIGMA1 - 1);\nmarkup2   = SIGMA2 / (SIGMA2 - 1);\n",
                       "nu1       = ( GAMMA1 / (GAMMA1 - (SIGMA1-1)) )^(1/(SIGMA1-1));\nnu2       = ( GAMMA2 / (GAMMA2 - (SIGMA2-1)) )^(1/(SIGMA2-1));\n",
                       "phibar1     = nu1 * PHIM1;\nphibar2   = nu2 * PHIM2;\n",
                       "phibar1star = nu1 * PHIM1star;\nphibar2star   = nu2 * PHIM2star;\n",
                       "phi1Xbar  = ", par.nu1 * controls[3], ";\nphi2Xbar = ", par.nu2 * controls[4], ";\n\n",
                       "phi1q_a   = ", par.PHIM1 * ( 1 - par.pct_a)^(-1/par.GAMMA1), ";\nphi1q_b = ", par.PHIM1 * ( 1 - par.pct_b)^(-1/par.GAMMA1), ";\n",
                       "phi2q_a   = ", par.PHIM2 * ( 1 - par.pct_a)^(-1/par.GAMMA2), ";\nphi2q_b = ", par.PHIM2 * ( 1 - par.pct_b)^(-1/par.GAMMA2), ";\n",
                       "exportstatus1q_b = ", 1. * (par.PHIM1 * ( 1 - par.pct_b)^(-1/par.GAMMA1) > par.nu1 * controls[3]), ";\n",
                       "exportstatus2q_b = ", 1. * (par.PHIM2 * ( 1 - par.pct_b)^(-1/par.GAMMA2) > par.nu2 * controls[4]), ";\n",
                       "\n\n")

# load model file
    f          = open(string("./dynare_code/model_files/", model_file), "r")
    model_str  = readstring(f);
    close(f)


# load steady file
    f           = open(string("./dynare_code/model_files/", steady_file), "r")
    steady_str  = readstring(f);
    close(f)


# load post-processing file
    f          = open(string("./dynare_code/model_files/", post_file), "r")
    post_str   = readstring(f);
    close(f)

    # define what we want in simulation
    post_str   = string(post_str, "\n\n\n\n",
                        "stoch_simul(\n",
                        ## "            hp_filter = 1600,\n",
                        "            order = ", order, ",\n",
                        "            k_order_solver,\n",
                        "            irf_shocks = (epsa epsastar),\n",
                        "            irf = ", irf, ",\n",
                        "            periods = ", periods, ",\n",
                        "            replic = ", replic, ",\n",
                        "            pruning\n",
                        "            )")

    # add variables of simulation
    post_str = string(post_str, " Astarshock ", simul_var, ";", "\n\n\n", "// End of generated dynare file\n")



# write all my strings to the final model file:
    out_file = string(out_file)

    f = open(out_file, "w");
    write(f, julia_header);
    write(f, header_str);
    write(f, param_str);
    write(f, model_str);
    write(f, steady_str);
    write(f, post_str);
    close(f);



end
# end of GML2b_to_dynare













# save GML2b parameters in file
function GML2b_save_param(par::GML2b_Parameters;
                         file_name = "param_save")

  string_param = string(
    "#############################################################\n",
    "# PARAMETER FILE -- GML2b model\n\n",
    "# File created at ", Libc.strftime(time()), "\n\n\n",

    "SIGMA1   = ", par.SIGMA1, "; \n",
    "SIGMA2   = ", par.SIGMA2, "; \n\n",

    "THETA    = ", par.THETA, ";\n\n",

    "a0       = ", par.a0, ";\n",
    "a0star   = ", par.a0star, ";\n\n",

    "alpha_rs = ", par.alpha_rs, ";\n",
    "xiD_rs   = ", par.xiD_rs, ";\n",
    "xiX_rs   = ", par.xiX_rs, ";\n\n",

    "PHIM1     = ", par.PHIM1, ";         # lower bound productivity\n",
    "PHIM2     = ", par.PHIM2, "; \n",
    "PHIM1star = ", par.PHIM1star, ";         # lower bound productivity\n",
    "PHIM2star = ", par.PHIM2star, ";         \n\n",

    "GAMMA1   = ", par.GAMMA1, "; # 3.4;        # Pareto tail parameter (baseline 3.4) \n",
    "GAMMA2   = ", par.GAMMA2, "; # 3.4; \n\n",
    "ETA1     = ", par.ETA1, "; \n",
    "ETA2     = ", par.ETA2, "; \n",
    "ETA1star = ", par.ETA1star, "; \n",
    "ETA2star = ", par.ETA2star, "; \n\n",

    "NU      = ", par.NU, " ;         # risk aversion \n",
    "NUstar  = ", par.NUstar, "; #          # risk aversion foreign country \n",
    "BETA    = ", par.BETA, ";        # quarterly frequency \n",
    "IES     = ", par.IES, ";         # IES  \n\n",

    "TAU1      = ", par.TAU1, ";        # iceberg \n",
    "TAU2      = ", par.TAU2, "; \n",
    "TAU1star  = ", par.TAU1star, "; \n",
    "TAU2star  = ", par.TAU2star, "; \n",

    "F1exp     = ", par.F1exp, "; \n",
    "F2exp     = ", par.F2exp, "; \n",
    "F1expstar = ", par.F1expstar, "; \n",
    "F2expstar = ", par.F2expstar, ";\n\n",

    "M1         = ", par.M1, "; \n",
    "M2         = ", par.M2, "; \n",
    "M1star     = ", par.M1star, "; \n",
    "M2star     = ", par.M2star, "; \n\n",

    "L        = ", par.L, ";\n",
    "Lstar    = ", par.Lstar, ";\n\n",

    "pct_a    = ", par.pct_a, ";\n",
    "pct_b    = ", par.pct_b, ";\n\n",

    "MU_a        = ", par.MU_a, "; \n",
    "MU_astar    = ", par.MU_astar, "; \n",
    "RHO_a       = ", par.RHO_a, "; \n",
    "SIGMA_a     = ", par.SIGMA_a, ";  \n",
    "RHO_astar   = ", par.RHO_astar, "; \n",
    "SIGMA_astar = ", par.SIGMA_astar, "; \n",

    "\n\n\n",

    "# end of parameter definition \n"
    )

    f = open(string("./backups/",file_name, "_", Libc.strftime("%Y%m%d_%H%M", time()), ".jl"), "w");
    write(f, string_param);
    close(f)

end
# end of GML2b_save_param


















end
# end of GML2b_routines
