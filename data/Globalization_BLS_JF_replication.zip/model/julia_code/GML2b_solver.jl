#! /usr/bin/julia
#
# GML2b_solver.jl
#
#
# created           July     22nd 2016
# last modified     June          2018
#
# (c) Barrot, Loualiche & Sauvagnat
#
#
#######################################################################################





#########################################################################################
# ----- PREAMBLE
# --- add path
path_to = "/Users/loulou/Dropbox/other_projects/replication_jf"
push!(LOAD_PATH, string(path_to, "/julia_code") ) # extend the path
cd(path_to)


# --- load packages and local routines
using BlackBoxOptim
## using JuMP
## using KNITRO, Ipopt

# --- personal routines
using GML2b_constants
using GML2b_routines



#########################################################################################
# ----- PARAMETERS FOR THE MODEL

# --- notes
# we have a few constraints on coefficients: THETA < SIGMA and GAMMA > SIGMA-1

SIGMA1   = 3.8 ;        # elasticity of substitution
SIGMA2   = 3.8 ;        # elasticity of substitution

THETA    = 1.2;

a0       = 0.1;        # elasticity with the other good
a0star   = 0.6;

alpha_rs = 0.;         # degree of risk sharing (0 for no, 1 for all)

xiD_rs   = 0.5;        # quadratic cost in bond trading
xiX_rs   = 0.5;

PHIM1     = 0.7;       # lower bound productivity
PHIM2     = 0.7
PHIM1star = 1.;        # lower bound productivity
PHIM2star = 1.;

GAMMA1   = 3.4;        # Pareto tail parameter (baseline 3.4)
GAMMA2   = 3.4;

ETA1     = 0.5;
ETA2     = 0.5;
ETA1star = 0.5;
ETA2star = 0.5;

# --- intertemporal
NU      = 20. ;        # risk aversion
NUstar  = 2.  ;
BETA    = 0.99;        # quarterly frequency
IES     = 1.5 ;        # IES


# --- trade costs
TAU1      = 1.;        # iceberg
TAU2      = 1.5;
TAU1star  = 1.;
TAU2star  = 1.5;

F1exp     = 5E0;
F2exp     = 5E0;
F1expstar = 3E-05;
F2expstar = 3E-05;


# --- size
M1         = 1.
M2         = 1.
M1star     = 30.
M2star     = 16.

L        = 1.
Lstar    = 3.

# --- derivative constants
markup1     = SIGMA1 / (SIGMA1 - 1);
markup2     = SIGMA2 / (SIGMA2 - 1);
nu1         = ( GAMMA1 / (GAMMA1 - (SIGMA1-1)) )^(1/(SIGMA1-1));
nu2         = ( GAMMA2 / (GAMMA2 - (SIGMA2-1)) )^(1/(SIGMA2-1));
phibar1     = nu1 * PHIM1;
phibar2     = nu2 * PHIM2;
phibar1star = nu1 * PHIM1star;
phibar2star = nu2 * PHIM2star;


# --- shocks
# - AVERAGE PRODUCTIVITY IN EACH COUNTRY
MU_a     = 7.;
MU_astar = 1.;

RHO_a          = 0.968;
SIGMA_a        = 1.6 / 100;
RHO_astar      = 0.98;
SIGMA_astar    = 6 / 100 ;
CORR_a_astar   = 0.

# --- percentile: compute returns for firms with given percentile:
pct_a = 20 / 100;
pct_b = 80 / 100


# --- model parameter type
param = GML2b_Parameters(NU, NUstar, IES, BETA, SIGMA1, SIGMA2, THETA, a0, a0star,
                         alpha_rs, xiD_rs, xiX_rs,
                         ETA1, ETA2, ETA1star, ETA2star, PHIM1, PHIM2, PHIM1star, PHIM2star,
                         GAMMA1, GAMMA2, F1exp, F2exp, F1expstar, F2expstar,
                         TAU1, TAU2, TAU1star, TAU2star,
                         M1, M2, M1star, M2star, L, Lstar,
                         markup1, nu1, phibar1, phibar1star, markup2, nu2, phibar2, phibar2star, pct_a, pct_b,
                         MU_a, MU_astar, RHO_a, SIGMA_a, RHO_astar, SIGMA_astar, CORR_a_astar,
                         zeros(1,1), zeros(1,1) )



#---------------------------------------------------------------------------------------------------------
# --- 1. Write steady state function into matlab
search_region = [ (1., 1.), (1., 1.), (param.PHIM1, 1e01), (param.PHIM2, 1e01),
  (param.PHIM1star, 1e01), (param.PHIM2star, 1e01),
  (1e-02, 1e02), (1e-02, 1e02), (1., 1.) ];
ss_point = [MU_a MU_astar];

result = bboptimize(x -> GML2b_routines.GML2b_optimize(x[:, :], param, ss_point),
                        SearchRange = search_region, OptimizationValue = 0.0,
                        Method = :adaptive_de_rand_1_bin_radiuslimited, MaxSteps = 1e06,
                        FitnessTolerance = 1e-6,
                        OptimizationValue = 0.0, TraceMode=:compact, TraceInterval=10)


sol_ss   = best_candidate(result);
error_ss = best_fitness(result)
# --- Check some moments
GML2b_routines.GML2b_moments(sol_ss[:,:], param)

#----------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------
# --- 1. write a dynare file
sol_full = GML2b_routines.GML2b_compute_model(sol_ss[:, :], param, ss_point; # - write steady state
  write_to_matlab = string(path_to, "/dynare_code/GML2_bonds/matlab_steady_GML2b.m"))

# IRF for Ashock
str_variables = "Ashock BD BX BDstar BXstar curracct curracctstar"

GML2b_routines.GML2b_to_dynare(sol_ss[:,:], param,
                             header_file = "GML2b_header.mod", model_file = "GML2b_model.mod",
                             steady_file = "GML2b_steady.mod", post_file = "GML2b_process.mod",
                             out_file    = "./dynare_code/GML2_bonds/GML2b.mod",
                             simul_var    = str_variables,
                             order = 3, irf = 100, replic = 2000, periods = 20000)
#-------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------
