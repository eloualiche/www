# THE GLOBALIZATION RISK PREMIUM
  Barrot, Loualiche & Sauvagnat

This is the readme file for *The Globalization Risk Premium* model files.


## Simulation
The model is coded in `julia` and simulated using `dynare`.
All of the simulations and IRf from the model are generated using a main julia script file: `./julia_code/main.jl`

The script works with version `0.6.2` of julia.
Please edit the `main.jl` file to change the paths of this folder on your computer and the path of some executables (`dynare` and `matlab`).


## Analysis
The analysis of the model is done in `R`. To generate the tables and figures in the paper, run the model simulations and then the following files:

  + `moments_data.R`: generates the main moments from the data used to calibrate the model
  note that the data is included with the folder under `./R_data`.
  + `moments_simulation.R`: generates the moments reported in the calibration table from the model with no risk sharing.
  + `read_irf.R` is a routine that saves the simulations generated from the model into an R data format.
  all files are saved in the `./output/` folder.
  + `plots_main.R` generates figures 1 and 2 using no and full risk sharing IRF simulations
  + `plots_risk_sharing` generates figure 3 using simulations of the model for various degrees of risk sharing
  + `plots_appendix.R` generates plots in the appendix

### Data used for target moments_simulation
The data used to estimate the target moments (when they are not directly derived in the empirical section) are under `./model/R_data` and processed in `./model/R_code/moments_data.R`

  + From the World Bank World Development Indicators we pull:
      + GDP from the USA and China in `worldbank_gdp.rds`
	  + Working population ratio in `worldbank_age_ratio.rds`
	  + Total population in `worldbank_pop.rds`
	  + US GDP series from BEA through FRED in `gdp.rds`
	  + Consumption from NIPA through FRED in (PCE item) `cons.rds`
	  + Risk-free rate from FRED in `rf.rds`
	  + Import Penetration from Feenstra's website at the [Center for International Data at UC Davis](http://cid.econ.ucdavis.edu/)  `feestra_import_sic4.rds`
	  + Trade flows of the US from the [US Census](https://www.census.gov/foreign-trade/data/index.html) `trade_census.rds` (and its seasonality adjusted version `trade_census_sa.rds`)


## Other
We solve a slightly more complicated version of the model with bond trading. The model files are included under `GML2b`.
